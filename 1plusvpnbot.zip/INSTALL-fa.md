# نصب 1PlusVPN — راهنمای سریع (سرور جدید)

## پیش‌نیاز
- سرور با **Ubuntu 20.04+ / Debian 11+ / CentOS / Rocky**
- دسترسی **root**
- دسترسی شبکه به پنل Rebecca (آدرس + کلید API)
- یک بوت تلگرام از @BotFather و آی‌دی عددی خودت (از @userinfobot)

## نصب (یک‌بار)

```bash
# ۱) این فایل zip را روی سرور بفرست و باز کن
scp 1plusvpn-full.zip root@SERVER:~/
ssh root@SERVER
cd ~ && unzip 1plusvpn-full.zip && cd 1plusvpn

# ۲) اینستالر را اجرا کن — ازت همه‌ی ورودی‌ها را می‌پرسد
sudo bash install.sh
```

### اینستالر این ورودی‌ها را می‌گیرد
| سوال | توضیح | پیش‌فرض |
|---|---|---|
| Panel base URL | آدرس پنل Rebecca **بدون** مسیر داشبورد | `https://127.0.0.1:4177` |
| Subscription base URL | آدرس لینک‌های sub **بدون** `/sub` | همان پنل |
| Admin API key | کلید API ادمین از پنل (My Account → API Keys) | — |
| Support link | لینک پشتیبانی در پیام‌ها | — |
| Emergency data/time | مقدار شارژ اضطراری (MB / روز) | 200 MB / 1 روز |
| Allowed origins | دامنه‌های مجاز CORS (صفحه sub + فروشگاه) | — |
| Verify panel TLS | برای پنل self-signed روی `false` | `false` |
| Port | پورت API | 9443 |
| **HTTPS + مسیر گواهی** | اگر گواهی SSL نداری، با HTTP ادامه می‌دهد (بعداً `install.sh` را دوباره بزن) | — |
| Bot token | توکن بوت | — |
| Admin id(s) | آی‌دی‌های ادمین تلگرام (با کما) | — |
| Sudo id(s) | سودو (بکاپ/تنظیمات سیستم) — اختیاری | — |
| پلن وب | کاربر/پسورد پنل وب | — |

### بعد از نصب
- `emergency-backend` : سرویس API + بات (پورتی که دادی)
- `1plusvpn-panel` : پنل وب مدیریت (پورت 8088)

```bash
systemctl status emergency-backend 1plusvpn-panel
journalctl -u emergency-backend -f
```

## آپدیت بعد از این نسخه

فایل‌های Python/HTML داخل این پکیج را روی سرور کپی کن و سرویس را ری‌استارت:

```bash
sudo cp *.py *.html /opt/emergency-backend/
sudo systemctl restart emergency-backend 1plusvpn-panel
```

> ⚠️ **هرگز** `.env`، `admins.json` و `emergency.db*` روی سرور را با فایل‌های پکیج جایگزین نکن — آن‌ها داده‌ی زنده‌ی سرور هستند.

## نکات مهم

1. **`TELEGRAM_ADMIN_IDS` نباید خالی باشد** — اگر خالی باشد، هیچ‌کس ادمین نیست (امنیت fail-closed).
2. **دکمه‌ی «🔧 تنظیمات سیستم»** فقط برای آی‌دی‌های **SUDO** نمایش داده می‌شود.
3. **SSL بعداً اضافه شد؟** دوباره `sudo bash install.sh` بزن — جواب‌های قبلی `.env` حفظ می‌شود و فقط مسیر گواهی را می‌دهی.
4. **فروشگاه/وب‌اپ** روی دامنه‌ی HTTPS نیاز دارد — اینستالر گزینه‌ی تنظیم nginx برای دامنه‌ی فروشگاه را هم دارد.
5. چک‌کننده‌ی سالمی: `sudo bash verify-fix.sh`
