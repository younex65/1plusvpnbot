"""
referrals.py — referral / discount system.
==========================================

Flow (percent discount, per admin):
  1. User B tells the bot that user A referred them (referral must be enabled by
     the admin). We store the referral and give B a one-time signup discount.
  2. When B renews, the discount is applied to the price. On approval, the
     credit is marked used AND — if this was B's signup discount — the referrer
     A is granted their own one-time discount credit for their next renewal.
  3. A's credit is applied to A's next renewal the same way.

So both the new user AND the referrer get the admin-configured percent, but the
referrer only receives it after the referred user has actually paid (approved),
which prevents abuse.
"""
from __future__ import annotations

import time
import sqlite3

import dbx
import threading
from contextlib import contextmanager
from typing import Optional

_lock = threading.Lock()
_DB_PATH = None


def init(db_path: str) -> None:
    global _DB_PATH
    _DB_PATH = db_path
    with _conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS referrals (
                referred_username       TEXT PRIMARY KEY,
                referrer_username       TEXT NOT NULL,
                admin_username          TEXT,
                percent                 INTEGER NOT NULL,
                created_at              INTEGER,
                referrer_bonus_granted  INTEGER DEFAULT 0
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS discount_credits (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                username       TEXT NOT NULL,
                admin_username TEXT,
                percent        INTEGER NOT NULL,
                reason         TEXT,               -- referred_signup | referrer_bonus
                used           INTEGER DEFAULT 0,
                created_at     INTEGER
            )
            """
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_credit_user ON discount_credits(username, used)")


@contextmanager
def _conn():
    """
    PERF FIX: was `sqlite3.connect()` inside a process-wide `threading.Lock()`
    on every single call — see dbx.py for the full explanation. Now it hands
    back this thread's cached WAL connection, so reads run in parallel and
    writes autocommit with a real busy_timeout instead of raising
    "database is locked".
    """
    yield dbx.get(_DB_PATH)


# ---- registering a referral --------------------------------------------

def add_referral(referred_username: str, referrer_username: str,
                 admin_username: str, percent: int) -> tuple[bool, str]:
    """Register that `referrer` referred `referred`. Returns (ok, message)."""
    if referred_username == referrer_username:
        return False, "نمی‌توانید خودتان را معرف وارد کنید."
    with _conn() as c:
        exists = c.execute(
            "SELECT 1 FROM referrals WHERE referred_username=?", (referred_username,)
        ).fetchone()
        if exists:
            return False, "شما قبلاً یک معرف ثبت کرده‌اید."
        now = int(time.time())
        c.execute(
            """INSERT INTO referrals (referred_username, referrer_username, admin_username,
                                      percent, created_at)
               VALUES (?,?,?,?,?)""",
            (referred_username, referrer_username, admin_username, percent, now),
        )
        # give the referred user their one-time signup discount
        c.execute(
            """INSERT INTO discount_credits (username, admin_username, percent, reason, used, created_at)
               VALUES (?,?,?, 'referred_signup', 0, ?)""",
            (referred_username, admin_username, percent, now),
        )
    return True, "✅ معرف ثبت شد. تخفیف در اولین تمدید شما اعمال می‌شود."


# ---- discounts ----------------------------------------------------------

def best_credit(username: str) -> Optional[dict]:
    """Return the highest unused discount credit for a user (or None)."""
    with _conn() as c:
        row = c.execute(
            """SELECT * FROM discount_credits WHERE username=? AND used=0
               ORDER BY percent DESC, id ASC LIMIT 1""",
            (username,),
        ).fetchone()
    return dict(row) if row else None


def discount_percent_for(username: str) -> int:
    c = best_credit(username)
    return int(c["percent"]) if c else 0


def apply_discount(price: int, percent: int) -> int:
    if percent <= 0:
        return price
    return int(round(price * (100 - percent) / 100))


def consume_credit_on_approval(username: str) -> None:
    """Mark the user's best credit as used and, if it was a signup credit,
    grant the referrer their bonus credit."""
    cr = best_credit(username)
    if not cr:
        return
    with _conn() as c:
        c.execute("UPDATE discount_credits SET used=1 WHERE id=?", (cr["id"],))
        if cr["reason"] == "referred_signup":
            ref = c.execute(
                "SELECT * FROM referrals WHERE referred_username=?", (username,)
            ).fetchone()
            if ref and not ref["referrer_bonus_granted"]:
                c.execute(
                    """INSERT INTO discount_credits (username, admin_username, percent, reason, used, created_at)
                       VALUES (?,?,?, 'referrer_bonus', 0, ?)""",
                    (ref["referrer_username"], ref["admin_username"], ref["percent"], int(time.time())),
                )
                c.execute(
                    "UPDATE referrals SET referrer_bonus_granted=1 WHERE referred_username=?",
                    (username,),
                )


def referral_summary(username: str) -> dict:
    with _conn() as c:
        referred = c.execute(
            "SELECT referrer_username FROM referrals WHERE referred_username=?", (username,)
        ).fetchone()
        invited = c.execute(
            "SELECT COUNT(*) n FROM referrals WHERE referrer_username=?", (username,)
        ).fetchone()
        credit = c.execute(
            """SELECT COALESCE(MAX(percent),0) p FROM discount_credits
               WHERE username=? AND used=0""",
            (username,),
        ).fetchone()
    return {
        "referrer": referred["referrer_username"] if referred else None,
        "invited_count": int(invited["n"]) if invited else 0,
        "pending_percent": int(credit["p"]) if credit else 0,
    }
