"""
shop.py — customer shop portal backend (accounts, sessions, orders).
====================================================================

A "shop account" (username + password the customer chooses) is SEPARATE from
the VPN accounts it owns. Shop accounts are scoped PER ADMIN: the same username
may exist under two different admins independently. Login/register always carry
the `admin` from the dedicated purchase link (?admin=1plus).

Tables (in the shared emergency.db):
    shop_users      one row per (admin, username): password hash, email, phone
    shop_orders     purchase/renew orders placed from the portal
    shop_vpn        links a shop account to the VPN usernames it owns

Sessions are stateless signed cookies (HMAC), like the install panel.

Auto-naming: each admin has a PREFIX (e.g. Mt). On approval we scan that admin's
existing users, find the largest <prefix><number>, add 1, and create the user.
"""
from __future__ import annotations

import re
import os
import json
import time
import hmac
import base64
import hashlib
import sqlite3

import dbx
import secrets
import threading
from contextlib import contextmanager
from typing import Optional

_lock = threading.Lock()
_DB_PATH = None
_SECRET = None


def init(db_path: str) -> None:
    global _DB_PATH
    _DB_PATH = db_path
    with _conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS admin_backup_signing (
            id INTEGER PRIMARY KEY CHECK (id=1), secret TEXT NOT NULL)""")
        c.execute("INSERT OR IGNORE INTO admin_backup_signing VALUES (1, ?)", (secrets.token_hex(32),))
        c.execute("""
            CREATE TABLE IF NOT EXISTS shop_users (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username TEXT NOT NULL,
                username       TEXT NOT NULL,
                password_hash  TEXT NOT NULL,
                email          TEXT,
                phone          TEXT,
                created_at     INTEGER,
                UNIQUE(admin_username, username)
            )""")
        c.execute("""
            CREATE TABLE IF NOT EXISTS shop_orders (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                shop_user_id   INTEGER NOT NULL,
                admin_username TEXT NOT NULL,
                type           TEXT NOT NULL,          -- buy | renew
                target_user    TEXT,                   -- for renew: the vpn username
                plan_days      INTEGER NOT NULL,
                gb             INTEGER NOT NULL,
                price          INTEGER NOT NULL,
                status         TEXT NOT NULL DEFAULT 'pending',  -- pending|approved|rejected
                created_at     INTEGER,
                decided_at     INTEGER,
                created_user   TEXT,                   -- the vpn username created on approval
                created_sub    TEXT,                   -- its sub link
                tg_message_id  INTEGER,
                service_id     TEXT,                   -- panel service used for creation
                package_name   TEXT                    -- shop package label
            )""")
        c.execute("""
            CREATE TABLE IF NOT EXISTS shop_packages (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username TEXT NOT NULL,
                name           TEXT NOT NULL,           -- e.g. "V2Ray", "OpenVPN"
                service_id     TEXT NOT NULL,           -- panel service id it maps to
                prices         TEXT NOT NULL,           -- JSON {days: toman_per_gb}
                note           TEXT,
                sort_order     INTEGER DEFAULT 0,
                enabled        INTEGER DEFAULT 1,
                created_at     INTEGER
            )""")
        # migrate: add columns to shop_orders if the table pre-existed
        for col, ddl in (("service_id", "ALTER TABLE shop_orders ADD COLUMN service_id TEXT"),
                         ("package_name", "ALTER TABLE shop_orders ADD COLUMN package_name TEXT"),
                         ("discount_code", "ALTER TABLE shop_orders ADD COLUMN discount_code TEXT"),
                         ("discount_amount", "ALTER TABLE shop_orders ADD COLUMN discount_amount INTEGER DEFAULT 0"),
                         ("wallet_used", "ALTER TABLE shop_orders ADD COLUMN wallet_used INTEGER DEFAULT 0"),
                         ("reject_reason", "ALTER TABLE shop_orders ADD COLUMN reject_reason TEXT DEFAULT ''")):
            try:
                c.execute(ddl)
            except Exception:
                pass
        # ---- discount codes ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS discount_codes (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username  TEXT NOT NULL,
                code            TEXT NOT NULL UNIQUE,
                discount_type   TEXT NOT NULL DEFAULT 'percent',
                discount_value  INTEGER NOT NULL,
                max_uses        INTEGER DEFAULT 1,
                used_count      INTEGER DEFAULT 0,
                active          INTEGER DEFAULT 1,
                created_at      INTEGER
            )""")
        # ---- gift codes (free account) ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS gift_codes (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username  TEXT NOT NULL,
                code            TEXT NOT NULL UNIQUE,
                plan_days       INTEGER NOT NULL,
                gb              INTEGER NOT NULL,
                max_uses        INTEGER DEFAULT 1,
                used_count      INTEGER DEFAULT 0,
                active          INTEGER DEFAULT 1,
                created_at      INTEGER
            )""")
        # ---- wallet (referral credits) ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS wallet (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username  TEXT NOT NULL,
                chat_id         INTEGER NOT NULL,
                balance         INTEGER DEFAULT 0,
                UNIQUE(admin_username, chat_id)
            )""")
        # ---- trial usage tracking ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS trial_usage (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username  TEXT NOT NULL,
                chat_id         INTEGER NOT NULL,
                vpn_username    TEXT,
                used_at         INTEGER,
                UNIQUE(admin_username, chat_id)
            )""")
        # ---- admin bank cards (multiple per admin) ----
        c.execute("""
            CREATE TABLE IF NOT EXISTS admin_cards (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_username  TEXT NOT NULL,
                card_number     TEXT NOT NULL,
                card_holder     TEXT NOT NULL DEFAULT '',
                card_bank       TEXT NOT NULL DEFAULT '',
                active          INTEGER DEFAULT 1,
                created_at      INTEGER
            )""")
        c.execute("""
            CREATE TABLE IF NOT EXISTS shop_vpn (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                shop_user_id   INTEGER NOT NULL,
                vpn_username   TEXT NOT NULL,
                sub            TEXT,
                created_at     INTEGER,
                UNIQUE(shop_user_id, vpn_username)
            )""")


@contextmanager
def _conn():
    """
    PERF FIX: was `sqlite3.connect()` inside a process-wide `threading.Lock()`
    on every single call — see dbx.py for the full explanation. Now it hands
    back this thread's cached WAL connection, so reads run in parallel and
    writes autocommit with a real busy_timeout instead of raising
    "database is locked".
    """
    yield dbx.get(_DB_PATH)


# ---- password hashing (same scheme as the install panel) -----------------

def hash_password(pw: str, salt: Optional[str] = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000)
    return f"pbkdf2$200000${salt}${base64.b64encode(dk).decode()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        _, iters, salt, b64 = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), int(iters))
        return hmac.compare_digest(base64.b64encode(dk).decode(), b64)
    except Exception:
        return False


# ---- sessions (signed cookie: shopuserid.admin.exp.sig) ------------------

def _secret() -> str:
    global _SECRET
    if _SECRET:
        return _SECRET
    # reuse the install panel secret if present so restarts keep sessions valid
    try:
        conf = json.load(open(os.path.join(os.path.dirname(_DB_PATH), ".panel.json")))
        if conf.get("secret"):
            _SECRET = conf["secret"]
            return _SECRET
    except Exception:
        pass
    _SECRET = secrets.token_hex(32)
    return _SECRET


SESSION_TTL = 30 * 86400  # 30 days


def make_session(shop_user_id: int, admin: str) -> str:
    exp = int(time.time()) + SESSION_TTL
    payload = f"{shop_user_id}.{admin}.{exp}"
    sig = hmac.new(_secret().encode(), payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}.{sig}".encode()).decode()


def check_session(token: str) -> Optional[dict]:
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode()
        uid, admin, exp, sig = raw.rsplit(".", 3)
        payload = f"{uid}.{admin}.{exp}"
        good = hmac.new(_secret().encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(good, sig):
            return None
        if int(exp) < int(time.time()):
            return None
        return {"shop_user_id": int(uid), "admin": admin}
    except Exception:
        return None


# ---- shop accounts -------------------------------------------------------

def create_account(admin: str, username: str, password: str,
                   email: str = "", phone: str = "") -> int:
    with _conn() as c:
        exists = c.execute(
            "SELECT 1 FROM shop_users WHERE admin_username=? AND username=?",
            (admin, username)).fetchone()
        if exists:
            raise ValueError("username_taken")
        cur = c.execute(
            """INSERT INTO shop_users (admin_username, username, password_hash, email, phone, created_at)
               VALUES (?,?,?,?,?,?)""",
            (admin, username, hash_password(password), email, phone, int(time.time())))
        return cur.lastrowid


def authenticate(admin: str, username: str, password: str) -> Optional[dict]:
    with _conn() as c:
        row = c.execute(
            "SELECT * FROM shop_users WHERE admin_username=? AND username=?",
            (admin, username)).fetchone()
    if not row or not verify_password(password, row["password_hash"]):
        return None
    return {"id": row["id"], "username": row["username"], "admin": admin}


def get_account(shop_user_id: int) -> Optional[dict]:
    with _conn() as c:
        row = c.execute("SELECT * FROM shop_users WHERE id=?", (shop_user_id,)).fetchone()
    return dict(row) if row else None


# ---- vpn account links ---------------------------------------------------

def link_vpn(shop_user_id: int, vpn_username: str, sub: str) -> None:
    with _conn() as c:
        c.execute(
            """INSERT OR IGNORE INTO shop_vpn (shop_user_id, vpn_username, sub, created_at)
               VALUES (?,?,?,?)""",
            (shop_user_id, vpn_username, sub, int(time.time())))


def list_vpn(shop_user_id: int) -> list:
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM shop_vpn WHERE shop_user_id=? ORDER BY id DESC",
            (shop_user_id,)).fetchall()
    return [dict(r) for r in rows]


def unlink_vpn(shop_user_id: int, vpn_username: str) -> None:
    with _conn() as c:
        c.execute("DELETE FROM shop_vpn WHERE shop_user_id=? AND vpn_username=?",
                  (shop_user_id, vpn_username))


# ---- orders --------------------------------------------------------------

def create_order(shop_user_id: int, admin: str, otype: str, plan_days: int,
                 gb: int, price: int, target_user: str = "",
                 service_id: str = "", package_name: str = "") -> int:
    with _conn() as c:
        cur = c.execute(
            """INSERT INTO shop_orders (shop_user_id, admin_username, type, target_user,
                   plan_days, gb, price, status, created_at, service_id, package_name)
               VALUES (?,?,?,?,?,?,?, 'pending', ?, ?, ?)""",
            (shop_user_id, admin, otype, target_user, plan_days, gb, price,
             int(time.time()), str(service_id or ""), package_name or ""))
        return cur.lastrowid


# ---- packages ------------------------------------------------------------

def list_packages(admin: str, enabled_only: bool = False) -> list:
    with _conn() as c:
        q = "SELECT * FROM shop_packages WHERE admin_username=?"
        if enabled_only:
            q += " AND enabled=1"
        q += " ORDER BY sort_order ASC, id ASC"
        rows = c.execute(q, (admin,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["prices"] = {int(k): int(v) for k, v in json.loads(d["prices"]).items()}
        except Exception:
            d["prices"] = {}
        d["enabled"] = bool(d["enabled"])
        out.append(d)
    return out


def get_package(pkg_id: int) -> Optional[dict]:
    with _conn() as c:
        r = c.execute("SELECT * FROM shop_packages WHERE id=?", (pkg_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    try:
        d["prices"] = {int(k): int(v) for k, v in json.loads(d["prices"]).items()}
    except Exception:
        d["prices"] = {}
    d["enabled"] = bool(d["enabled"])
    return d


def add_package(admin: str, name: str, service_id: str, prices: dict,
                note: str = "", sort_order: int = 0) -> int:
    with _conn() as c:
        cur = c.execute(
            """INSERT INTO shop_packages (admin_username, name, service_id, prices, note, sort_order, enabled, created_at)
               VALUES (?,?,?,?,?,?,1,?)""",
            (admin, name, str(service_id), json.dumps({str(k): int(v) for k, v in prices.items()}),
             note or "", int(sort_order), int(time.time())))
        return cur.lastrowid


def update_package(pkg_id: int, name: str, service_id: str, prices: dict,
                   note: str = "", enabled: bool = True, sort_order: int = 0) -> None:
    with _conn() as c:
        c.execute(
            """UPDATE shop_packages SET name=?, service_id=?, prices=?, note=?, enabled=?, sort_order=?
               WHERE id=?""",
            (name, str(service_id), json.dumps({str(k): int(v) for k, v in prices.items()}),
             note or "", 1 if enabled else 0, int(sort_order), pkg_id))


def delete_package(pkg_id: int) -> None:
    with _conn() as c:
        c.execute("DELETE FROM shop_packages WHERE id=?", (pkg_id,))



def get_order(order_id: int) -> Optional[dict]:
    with _conn() as c:
        row = c.execute("SELECT * FROM shop_orders WHERE id=?", (order_id,)).fetchone()
    return dict(row) if row else None


def set_order_msg(order_id: int, msg_id: int) -> None:
    with _conn() as c:
        c.execute("UPDATE shop_orders SET tg_message_id=? WHERE id=?", (msg_id, order_id))


def set_order_status(order_id: int, status: str, created_user: str = "",
                     created_sub: str = "", reject_reason: str = "") -> None:
    with _conn() as c:
        c.execute(
            """UPDATE shop_orders SET status=?, decided_at=?, created_user=?, created_sub=?, reject_reason=?
               WHERE id=?""",
            (status, int(time.time()), created_user, created_sub, reject_reason, order_id))


def list_orders(shop_user_id: int, limit: int = 30) -> list:
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM shop_orders WHERE shop_user_id=? ORDER BY id DESC LIMIT ?",
            (shop_user_id, limit)).fetchall()
    return [dict(r) for r in rows]


# ---- DISCOUNT CODES --------------------------------------------------------

def create_discount_code(admin: str, code: str, discount_type: str,
                         discount_value: int, max_uses: int = 1) -> int:
    """Create a discount code. discount_type: 'percent' or 'toman'."""
    code = (code or "").strip().upper()
    if not code:
        raise ValueError("code_required")
    with _conn() as c:
        exists = c.execute("SELECT id FROM discount_codes WHERE code=?", (code,)).fetchone()
        if exists:
            raise ValueError("code_exists")
        cur = c.execute(
            """INSERT INTO discount_codes (admin_username, code, discount_type, discount_value, max_uses, created_at)
               VALUES (?,?,?,?,?,?)""",
            (admin, code, discount_type, int(discount_value), int(max_uses), int(time.time())))
        return cur.lastrowid


def validate_discount_code(admin: str, code: str) -> dict:
    """Validate a discount code. Returns code info dict or raises ValueError."""
    code = (code or "").strip().upper()
    with _conn() as c:
        row = c.execute(
            "SELECT * FROM discount_codes WHERE code=? AND admin_username=?",
            (code, admin)).fetchone()
    if not row:
        raise ValueError("invalid_code")
    if not row["active"]:
        raise ValueError("code_inactive")
    if row["used_count"] >= row["max_uses"]:
        raise ValueError("code_exhausted")
    return dict(row)


def use_discount_code(code: str) -> None:
    """Increment used_count for a discount code."""
    code = (code or "").strip().upper()
    with _conn() as c:
        c.execute("UPDATE discount_codes SET used_count=used_count+1 WHERE code=?", (code,))


def list_discount_codes(admin: str) -> list:
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM discount_codes WHERE admin_username=? ORDER BY id DESC",
            (admin,)).fetchall()
    return [dict(r) for r in rows]


def delete_discount_code(code_id: int) -> None:
    with _conn() as c:
        c.execute("DELETE FROM discount_codes WHERE id=?", (code_id,))


def calculate_discount(price: int, code_info: dict) -> int:
    """Calculate discount amount in toman."""
    if code_info["discount_type"] == "percent":
        return int(price * code_info["discount_value"] / 100)
    else:  # toman
        return min(code_info["discount_value"], price)


# ---- GIFT CODES ------------------------------------------------------------

def create_gift_code(admin: str, code: str, plan_days: int, gb: int,
                     max_uses: int = 1) -> int:
    code = (code or "").strip().upper()
    if not code:
        raise ValueError("code_required")
    with _conn() as c:
        exists = c.execute("SELECT id FROM gift_codes WHERE code=?", (code,)).fetchone()
        if exists:
            raise ValueError("code_exists")
        cur = c.execute(
            """INSERT INTO gift_codes (admin_username, code, plan_days, gb, max_uses, created_at)
               VALUES (?,?,?,?,?,?)""",
            (admin, code, int(plan_days), int(gb), int(max_uses), int(time.time())))
        return cur.lastrowid


def validate_gift_code(admin: str, code: str) -> dict:
    code = (code or "").strip().upper()
    print(f"[GIFT DEBUG] validate_gift_code called with admin={admin!r}, code={code!r}")
    with _conn() as c:
        row = c.execute(
            "SELECT * FROM gift_codes WHERE code=? AND admin_username=?",
            (code, admin)).fetchone()
        print(f"[GIFT DEBUG] query result: {dict(row) if row else None}")
    if not row:
        raise ValueError("invalid_code")
    if not row["active"]:
        raise ValueError("code_inactive")
    if row["used_count"] >= row["max_uses"]:
        raise ValueError("code_exhausted")
    return dict(row)


def use_gift_code(code: str) -> None:
    code = (code or "").strip().upper()
    with _conn() as c:
        c.execute("UPDATE gift_codes SET used_count=used_count+1 WHERE code=?", (code,))


# ---- WALLET ----------------------------------------------------------------

def get_wallet_balance(admin: str, chat_id: int) -> int:
    with _conn() as c:
        row = c.execute(
            "SELECT balance FROM wallet WHERE admin_username=? AND chat_id=?",
            (admin, int(chat_id))).fetchone()
    return int(row["balance"]) if row else 0


def add_wallet_credit(admin: str, chat_id: int, amount: int) -> int:
    """Add credit to wallet. Returns new balance."""
    with _conn() as c:
        c.execute(
            """INSERT INTO wallet (admin_username, chat_id, balance) VALUES (?,?,?)
               ON CONFLICT(admin_username, chat_id) DO UPDATE SET balance=balance+?""",
            (admin, int(chat_id), int(amount), int(amount)))
        row = c.execute(
            "SELECT balance FROM wallet WHERE admin_username=? AND chat_id=?",
            (admin, int(chat_id))).fetchone()
    return int(row["balance"]) if row else 0


def use_wallet_credit(admin: str, chat_id: int, amount: int) -> bool:
    """Deduct credit from wallet. Returns True if sufficient balance."""
    balance = get_wallet_balance(admin, chat_id)
    if balance < amount:
        return False
    with _conn() as c:
        c.execute(
            "UPDATE wallet SET balance=balance-? WHERE admin_username=? AND chat_id=?",
            (int(amount), admin, int(chat_id)))
    return True


# ---- TRIAL ACCOUNTS --------------------------------------------------------

def has_used_trial(admin: str, chat_id: int) -> bool:
    with _conn() as c:
        row = c.execute(
            "SELECT id FROM trial_usage WHERE admin_username=? AND chat_id=?",
            (admin, int(chat_id))).fetchone()
    return row is not None


def record_trial_usage(admin: str, chat_id: int, vpn_username: str = "") -> None:
    with _conn() as c:
        c.execute(
            """INSERT OR REPLACE INTO trial_usage (admin_username, chat_id, vpn_username, used_at)
               VALUES (?,?,?,?)""",
            (admin, int(chat_id), vpn_username, int(time.time())))


def reset_trial_users(admin: str) -> int:
    """Reset all trial usage records for an admin. Returns count of reset users."""
    with _conn() as c:
        rows = c.execute(
            "SELECT COUNT(*) as cnt FROM trial_usage WHERE admin_username=?",
            (admin,)).fetchone()
        count = int(rows["cnt"]) if rows else 0
        c.execute("DELETE FROM trial_usage WHERE admin_username=?", (admin,))
    return count


# ---- RANDOM CODE GENERATOR -------------------------------------------------

def generate_random_code(prefix: str = "VPN", length: int = 8) -> str:
    """Generate a random alphanumeric code."""
    import string
    chars = string.ascii_uppercase + string.digits
    code = prefix + "-" + "".join(secrets.choice(chars) for _ in range(length))
    return code


# ---- ADMIN BANK CARDS (multiple per admin) ---------------------------------

def add_card(admin: str, card_number: str, card_holder: str = "", card_bank: str = "") -> int:
    """Add a new bank card for an admin. Returns the card ID."""
    card_number = (card_number or "").strip()
    if not card_number:
        raise ValueError("card_number_required")
    with _conn() as c:
        cur = c.execute(
            """INSERT INTO admin_cards (admin_username, card_number, card_holder, card_bank, created_at)
               VALUES (?,?,?,?,?)""",
            (admin, card_number, (card_holder or "").strip(), (card_bank or "").strip(), int(time.time())))
        return cur.lastrowid


def update_card(card_id: int, card_number: str, card_holder: str = "", card_bank: str = "") -> None:
    """Update an existing card."""
    card_number = (card_number or "").strip()
    if not card_number:
        raise ValueError("card_number_required")
    with _conn() as c:
        c.execute(
            "UPDATE admin_cards SET card_number=?, card_holder=?, card_bank=? WHERE id=?",
            (card_number, (card_holder or "").strip(), (card_bank or "").strip(), card_id))


def delete_card(card_id: int) -> None:
    """Delete a card."""
    with _conn() as c:
        c.execute("DELETE FROM admin_cards WHERE id=?", (card_id,))


def list_cards(admin: str) -> list:
    """List all cards for an admin."""
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM admin_cards WHERE admin_username=? ORDER BY id ASC",
            (admin,)).fetchall()
    return [dict(r) for r in rows]


def get_random_card(admin: str) -> dict:
    """Get a random active card for an admin. Falls back to default config."""
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM admin_cards WHERE admin_username=? AND active=1",
            (admin,)).fetchall()
    if rows:
        import random
        card = random.choice(rows)
        return {
            "number": card["card_number"],
            "holder": card["card_holder"],
            "bank": card["card_bank"],
        }
    return None


# ---- auto-naming ---------------------------------------------------------

def next_username(api, prefix: str, *, strict: bool = False) -> str:
    """Scan the admin's users, find the largest <prefix><n>, return prefix(n+1).

    `api` is a PanelAPI bound to that admin's key, so it only sees that admin's
    users. Falls back to prefix+"1" if none exist. With strict=True a
    failed scan is reported instead of deriving a name from incomplete data.
    """
    prefix = (prefix or "ST").strip() or "ST"
    pat = re.compile(r"^" + re.escape(prefix) + r"(\d+)$", re.IGNORECASE)
    biggest = 0
    try:
        for u in api.iter_all_users():
            name = str(u.get("username") or "")
            m = pat.match(name)
            if m:
                n = int(m.group(1))
                if n > biggest:
                    biggest = n
    except Exception:
        if strict:
            raise
    return f"{prefix}{biggest + 1}"


# ==========================================================================
#  ADMIN BACKUP / RESTORE (per admin)
# ==========================================================================

# Restore parent records before children. Use this fixed set of table names only.
_BACKUP_TABLES = (
    "admin_settings", "discount_codes", "gift_codes", "admin_cards", "shop_packages",
    "wallet", "trial_usage", "bot_users", "shop_users", "shop_orders", "shop_vpn", "renewal_orders",
)
_BACKUP_MAX_JSON = 100 * 1024 * 1024


def _backup_scope(table):
    if table == "shop_vpn":
        return "shop_user_id IN (SELECT id FROM shop_users WHERE admin_username=?)"
    return "admin_username=?"


def _backup_signature(secret, raw):
    return hmac.new(bytes.fromhex(secret), raw, hashlib.sha256).hexdigest()


def _backup_secret(c):
    return c.execute("SELECT secret FROM admin_backup_signing WHERE id=1").fetchone()["secret"]


def create_admin_backup(admin: str) -> bytes:
    """Export one admin's local data from a consistent SQLite read snapshot."""
    import io
    import zipfile

    data = {"metadata": {"type": "admin_backup", "admin_username": admin,
                         "created_at": int(time.time()), "version": "2.0"}}
    with dbx.read(_DB_PATH) as c:
        c.execute("BEGIN")
        try:
            secret = _backup_secret(c)
            for table in _BACKUP_TABLES:
                scope = _backup_scope(table)
                if table == "shop_orders":
                    scope += " AND shop_user_id IN (SELECT id FROM shop_users WHERE admin_username=?)"
                params = (admin, admin) if table == "shop_orders" else (admin,)
                data[table] = [dict(row) for row in c.execute(f"SELECT * FROM {table} WHERE {scope}", params)]
        finally:
            c.execute("ROLLBACK")
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        zf.writestr("backup.json", raw)
        zf.writestr("signature.txt", _backup_signature(secret, raw))
    return out.getvalue()


def restore_admin_backup(admin: str, zip_data: bytes) -> dict:
    """Restore one admin atomically; never overwrite another admin's rows."""
    import io
    import zipfile

    try:
        with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
            if zf.getinfo("backup.json").file_size > _BACKUP_MAX_JSON:
                raise ValueError("backup_too_large")
            raw = zf.read("backup.json")
            data = json.loads(raw)
            meta = data["metadata"]
            if meta["type"] != "admin_backup" or meta["version"] not in ("1.0", "2.0"):
                raise ValueError("invalid_backup_type")
            if meta["version"] == "2.0":
                if "signature.txt" not in zf.namelist() or zf.getinfo("signature.txt").file_size != 64:
                    return {"ok": False, "error": "backup_signature_invalid"}
                signature = zf.read("signature.txt")
    except (AttributeError, KeyError, TypeError, ValueError, RuntimeError, zipfile.BadZipFile):
        return {"ok": False, "error": "invalid_backup_file"}
    if meta.get("admin_username") != admin:
        return {"ok": False, "error": "backup_belongs_to_different_admin"}

    legacy = meta["version"] == "1.0"
    sections = [table for table in _BACKUP_TABLES if table in data]
    if not sections or (not legacy and len(sections) != len(_BACKUP_TABLES)):
        return {"ok": False, "error": "invalid_backup_file"}
    try:
        with dbx.write(_DB_PATH) as c:
            if not legacy and not hmac.compare_digest(signature, _backup_signature(_backup_secret(c), raw).encode("ascii")):
                raise ValueError("backup_signature_invalid")
            # Legacy archives didn't contain shop accounts and could omit or
            # misattribute orders. Keep those live sections intact rather than
            # replace them from an incomplete/unreliable legacy snapshot.
            if legacy:
                sections = [table for table in sections if table not in
                            ("bot_users", "shop_users", "shop_orders", "shop_vpn", "renewal_orders")]
            if not sections:
                raise ValueError("invalid_backup_file")
            shop_ids = set()
            if not legacy:
                shop_ids = {row["id"] for row in data["shop_users"] if row["admin_username"] == admin}
                # Deleting a parent while an out-of-scope order references it
                # would alter the meaning of someone else's record. Fail closed.
                if c.execute("""SELECT 1 FROM shop_orders o JOIN shop_users u ON o.shop_user_id=u.id
                                 WHERE u.admin_username=? AND o.admin_username<>? LIMIT 1""", (admin, admin)).fetchone():
                    raise ValueError("backup_scope_conflict")
            inserts = {}
            for table in sections:
                rows = data[table]
                if not isinstance(rows, list):
                    raise ValueError("invalid_backup_file")
                info = list(c.execute(f"PRAGMA table_info({table})"))
                required_keys = {r['name'] for r in info if r['pk']}
                known = {r['name'] for r in info}
                inserts[table] = []
                for row in rows:
                    if not isinstance(row, dict):
                        raise ValueError("invalid_backup_file")
                    row = dict(row)
                    if table == "admin_settings" and legacy and "admin_username" not in row:
                        row["admin_username"] = admin
                    if table != "shop_vpn" and row.get("admin_username") != admin:
                        raise ValueError("backup_scope_conflict")
                    if table in ("shop_orders", "renewal_orders") and row.get("status") == "pending":
                        live = c.execute(f"SELECT * FROM {table} WHERE id=? AND admin_username=?",
                                         (row.get("id"), admin)).fetchone()
                        if live is None:
                            # The original approval may already have changed Rebecca.
                            # Recover the record without re-enabling its old buttons.
                            row["status"] = "rejected"
                            if table == "shop_orders":
                                row["reject_reason"] = "سفارش در انتظار از بکاپ بازیابی شد؛ دوباره ثبت شود."
                        else:
                            row = dict(live)
                    if table in ("shop_orders", "shop_vpn") and row.get("shop_user_id") not in shop_ids:
                        raise ValueError("backup_scope_conflict")
                    if not required_keys <= row.keys() or any(row[k] is None for k in required_keys):
                        raise ValueError("invalid_backup_file")
                    keys = sorted(known & row.keys())
                    # Columns checked against the SQLite schema, never interpolated from arbitrary input.
                    stmt = f"INSERT INTO {table} ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})"
                    inserts[table].append((stmt, [row[k] for k in keys]))
            for table in reversed(sections):
                c.execute(f"DELETE FROM {table} WHERE {_backup_scope(table)}", (admin,))
            for table in sections:
                for stmt, params in inserts[table]:
                    c.execute(stmt, params)  # Conflicts roll back; never upsert across owners.
    except sqlite3.IntegrityError:
        return {"ok": False, "error": "backup_scope_conflict"}
    except (KeyError, TypeError, sqlite3.InterfaceError, sqlite3.ProgrammingError):
        return {"ok": False, "error": "invalid_backup_file"}
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "stats": {table: len(data[table]) for table in sections}, "legacy": legacy}
