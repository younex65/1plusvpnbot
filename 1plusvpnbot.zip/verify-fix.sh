#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# verify-fix.sh — run on the SERVER to check whether the fixed bot is
# actually deployed AND actually running.
#
#   sudo bash verify-fix.sh                # assumes /opt/emergency-backend
#   sudo APP_DIR=/root/emergency-backend SERVICE=my-bot bash verify-fix.sh
# ---------------------------------------------------------------------------
APP_DIR="${APP_DIR:-/opt/emergency-backend}"
SERVICE="${SERVICE:-emergency-backend}"

echo "=========================================================="
echo " 1) برنامه کجاست؟"
echo "=========================================================="
if [ -d "$APP_DIR" ]; then
    ls -ld "$APP_DIR"
else
    echo "!!! پیدا نشد: $APP_DIR"
    echo "    با APP_DIR=/مسیر/صحیح دوباره اجرا کن"
    echo
fi

echo
echo "=========================================================="
    echo "EXPECTED (نسخه 2026-08-28 b - باگ‌فیکس منو/بازگشت/تنظیمات سیستم):"
echo "=========================================================="
if [ -d "$APP_DIR" ]; then
    cd "$APP_DIR"
    sha256sum bot.py bot_user.py 2>/dev/null || echo "!!! فایل‌ها نیستند"
    echo
    echo "EXPECTED (نسخه 2026-08-28 b - باگ‌فیکس منو/بازگشت/تنظیمات سیستم):"
    echo "301f1e5751bd36fc75319b04f2204ce34cd234ac34faed780f9b817b6bcbd610  bot.py"
    echo "cebdb4f0893c323f314e8844746842ea4674ad64e3e3047818e3df042514304c  bot_user.py"
    echo
    echo "----------------------------------------------------------"
    echo " 3) انگشت‌نمای کد جدید در داخل فایل‌ها"
    echo "----------------------------------------------------------"
    printf "bot.py     _show_sys_settings   : %s   (انتظار: 2 | نسخه قدیم: 0)\n" "$(grep -c '_show_sys_settings' bot.py 2>/dev/null)"
    printf "bot.py     safe_edit            : %s   (انتظار: 36 | نسخه قدیم: 0)\n" "$(grep -c 'safe_edit' bot.py 2>/dev/null)"
    printf "bot_user.py _safe_edit           : %s   (انتظار: 33 | نسخه قدیم: 0)\n" "$(grep -c '_safe_edit' bot_user.py 2>/dev/null)"
fi

echo
echo "=========================================================="
echo " 4) وضعیت سرویس"
echo "=========================================================="
systemctl status "$SERVICE" --no-pager 2>/dev/null | head -12 || echo "!!! سرویس پیدا نشد (نام درست را بده: SERVICE=...)"

echo
echo "=========================================================="
echo " 5) پروسه‌های در حال اجرا (پروسه قدیم و اضافه نباشد!)"
echo "=========================================================="
ps aux | grep -E "uvicorn|app:app|emergency" | grep -v grep || echo "(هیچ پروسه‌ای پیدا نشد)"

echo
echo "=========================================================="
echo " 6) آخر لاگ سرویس"
echo "=========================================================="
journalctl -u "$SERVICE" -n 25 --no-pager 2>/dev/null || echo "(journalctl خالی)"

echo
echo "=========================================================="
echo " 7) تنظیمات ادمین/سودو (برای دکمه‌ی تنظیمات سیستم)"
echo "=========================================================="
if [ -f "$APP_DIR/.env" ]; then
    grep -E "^(TELEGRAM_ADMIN_IDS|SUDO_ADMIN_IDS)=" "$APP_DIR/.env" | sed 's/=.*/= <مقدارش در فایل>/ ' || true
else
    echo "!!! .env در $APP_DIR نیست"
fi
[ -f "$APP_DIR/admins.json" ] && echo "admins.json موجود است: $(wc -c < "$APP_DIR/admins.json") بایت"

echo
    echo "EXPECTED (نسخه 2026-08-28 b - باگ‌فیکس منو/بازگشت/تنظیمات سیستم):"
echo "اگر یکی بود ولی پروسه قدیم است -> sudo systemctl restart $SERVICE"
echo "اگر همه چیز درست بود ولی هنوز خطاست -> خروجی بخش ۶ را بفرست."
