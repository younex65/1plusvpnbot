# راه‌اندازی shop.1plusnet.ir با nginx

هدف: باز شدن صفحه‌ی خرید با `https://shop.1plusnet.ir` (بدون پورت)، که پشت‌صحنه
به بک‌اند روی پورت 9443 وصل می‌شود.

پیش‌نیاز: رکورد DNS برای `shop.1plusnet.ir` باید به IP سرور اشاره کند (که کردی ✅).

═══════════════════════════════════════════════════
## گام ۱: نصب nginx و certbot
═══════════════════════════════════════════════════
```bash
sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx
```

═══════════════════════════════════════════════════
## گام ۲: مطمئن شو پورت ۸۰ و ۴۴۳ آزاد و باز است
═══════════════════════════════════════════════════
```bash
sudo ss -tlnp | grep -E ':80 |:443 ' || echo "پورت ۸۰/۴۴۳ آزاد است"
```
اگر چیزی روی پورت ۸۰ بود (مثلاً خود پنل)، باید آن را جابه‌جا کنی.

> ⚠️ فایروال ابری هتزنر: در کنسول هتزنر مطمئن شو پورت‌های ۸۰ و ۴۴۳ (Inbound TCP) باز باشند.

═══════════════════════════════════════════════════
## گام ۳: ساخت کانفیگ nginx (اول فقط HTTP برای گرفتن گواهی)
═══════════════════════════════════════════════════
```bash
sudo tee /etc/nginx/sites-available/shop.1plusnet.ir > /dev/null << 'EOF'
server {
    listen 80;
    server_name shop.1plusnet.ir;

    location / {
        proxy_pass https://127.0.0.1:9443;
        proxy_ssl_verify off;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF
```
فعال‌سازی:
```bash
sudo ln -sf /etc/nginx/sites-available/shop.1plusnet.ir /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

═══════════════════════════════════════════════════
## گام ۴: گرفتن گواهی SSL رایگان (Let's Encrypt)
═══════════════════════════════════════════════════
```bash
sudo certbot --nginx -d shop.1plusnet.ir
```
- ایمیل بده، شرایط را قبول کن (`A`).
- وقتی پرسید redirect به HTTPS، گزینه‌ی **۲ (Redirect)** را بزن.

certbot خودش کانفیگ nginx را برای HTTPS به‌روز می‌کند و گواهی را نصب می‌کند.

═══════════════════════════════════════════════════
## گام ۵: تست
═══════════════════════════════════════════════════
مرورگر → `https://shop.1plusnet.ir/shop?admin=1plus`

باید صفحه‌ی خرید باز شود (بدون پورت، با قفل سبز SSL).

> نکته: چون بک‌اند صفحه‌ی خرید را روی مسیر `/shop` سرو می‌کند، آدرس نهایی
> `https://shop.1plusnet.ir/shop?admin=1plus` است.

═══════════════════════════════════════════════════
## گام ۶ (اختیاری): ریشه‌ی دامنه مستقیم به فروشگاه برود
═══════════════════════════════════════════════════
اگر می‌خواهی `https://shop.1plusnet.ir/?admin=1plus` (بدون /shop) هم کار کند،
یا ریشه به فروشگاه هدایت شود، این را به بلوک server (بخش 443) اضافه کن:
```nginx
    location = / {
        return 301 /shop$is_args$args;
    }
```
بعد:
```bash
sudo nginx -t && sudo systemctl reload nginx
```

═══════════════════════════════════════════════════
## تمدید خودکار گواهی
═══════════════════════════════════════════════════
certbot خودکار تمدید می‌کند. برای تست:
```bash
sudo certbot renew --dry-run
```

═══════════════════════════════════════════════════
## عیب‌یابی
═══════════════════════════════════════════════════
- **502 Bad Gateway:** بک‌اند روی 9443 بالا نیست → `sudo systemctl status emergency-backend`
- **گواهی گرفته نشد:** DNS هنوز پروپاگیت نشده یا پورت ۸۰ بسته است (فایروال هتزنر).
- **لاگ nginx:** `sudo tail -f /var/log/nginx/error.log`
- **تست کانفیگ:** `sudo nginx -t`

═══════════════════════════════════════════════════
## لینک‌های نهایی خرید (برای دادن به مشتری‌ها)
═══════════════════════════════════════════════════
```
https://shop.1plusnet.ir/shop?admin=1plus
https://shop.1plusnet.ir/shop?admin=2plus
```
هر ادمین لینک خودش را به مشتری‌هایش می‌دهد.
