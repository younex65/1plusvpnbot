#!/usr/bin/env bash
#
# panel-install.sh — bootstrap the 1PlusVPN web install panel.
# Run this ONCE on the server after uploading the files. It:
#   * asks you for a panel username + password (stored hashed)
#   * creates a Python venv and installs deps
#   * installs a systemd service for the panel
#   * starts the panel so you can finish everything else in the browser
#
# After this, open  http(s)://SERVER_IP:8088  and do the rest from the web.
#
set -euo pipefail

# --- must be root (the panel controls systemd + writes /opt) ---
if [[ $EUID -ne 0 ]]; then
  echo "Please run as root:  sudo bash panel-install.sh"
  exit 1
fi

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${INSTALL_DIR:-/opt/emergency-backend}"
PANEL_PORT="${PANEL_PORT:-8088}"
PANEL_SERVICE="1plusvpn-panel"

echo "==============================================="
echo "   1PlusVPN Web Install Panel - Setup"
echo "==============================================="
echo "Install dir: $INSTALL_DIR"
echo "Panel port:  $PANEL_PORT"
echo

# --- copy files into place if we're not already there ---
if [[ "$DIR" != "$INSTALL_DIR" ]]; then
  echo "-> Copying files to $INSTALL_DIR ..."
  mkdir -p "$INSTALL_DIR"
  cp -r "$DIR"/. "$INSTALL_DIR"/
fi
cd "$INSTALL_DIR"

# --- ask for panel credentials ---
read -rp "Panel username: " PUSER
while true; do
  read -rsp "Panel password: " PPASS; echo
  read -rsp "Confirm password: " PPASS2; echo
  [[ "$PPASS" == "$PPASS2" && -n "$PPASS" ]] && break
  echo "Passwords do not match or are empty, try again."
done

# --- venv + deps ---
echo "-> Creating Python venv and installing dependencies ..."
if [[ ! -d venv ]]; then python3 -m venv venv; fi
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q -r requirements.txt

# --- write hashed panel credentials (.panel.json) ---
echo "-> Saving panel credentials (hashed) ..."
PUSER="$PUSER" PPASS="$PPASS" ./venv/bin/python - <<'PY'
import os, json, panel
conf = {
    "username": os.environ["PUSER"],
    "password_hash": panel.hash_password(os.environ["PPASS"]),
}
# keep an existing signing secret if present, else create one
try:
    old = json.load(open(panel.PANEL_CONF))
    if old.get("secret"): conf["secret"] = old["secret"]
except Exception:
    pass
import secrets
conf.setdefault("secret", secrets.token_hex(32))
json.dump(conf, open(panel.PANEL_CONF, "w"))
os.chmod(panel.PANEL_CONF, 0o600)
print("saved", panel.PANEL_CONF)
PY

# --- systemd service for the panel ---
echo "-> Installing panel systemd service ..."
cat > /etc/systemd/system/${PANEL_SERVICE}.service <<EOF
[Unit]
Description=1PlusVPN Web Install Panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
Environment=BACKEND_DIR=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/venv/bin/python -m uvicorn panel:app --host 0.0.0.0 --port ${PANEL_PORT}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ${PANEL_SERVICE}
systemctl restart ${PANEL_SERVICE}

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo
echo "==============================================="
echo "  Panel installed and running"
echo "==============================================="
echo "  Panel URL:  http://${IP:-SERVER_IP}:${PANEL_PORT}"
echo "  Username:   $PUSER"
echo
echo "  Now open the panel in your browser and finish the"
echo "  setup (settings, admins, HTTPS, install backend)."
echo
echo "  Manage the panel service:"
echo "     systemctl status  ${PANEL_SERVICE}"
echo "     systemctl restart ${PANEL_SERVICE}"
echo "==============================================="
