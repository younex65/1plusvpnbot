#!/usr/bin/env bash
#
# 1PlusVPN — Emergency Charge backend :: one-shot installer
# =========================================================
# Run this ONCE on the server that can reach your Rebecca panel.
# It installs everything, asks a few questions, and leaves a running service.
#
#   sudo bash install.sh
#
# Re-running it is safe: it updates code, keeps your existing .env answers,
# and restarts the service.
#
set -euo pipefail

# ---------- pretty output ----------
c_g(){ printf '\033[1;32m%s\033[0m\n' "$*"; }
c_y(){ printf '\033[1;33m%s\033[0m\n' "$*"; }
c_r(){ printf '\033[1;31m%s\033[0m\n' "$*"; }
c_b(){ printf '\033[1;36m%s\033[0m\n' "$*"; }
line(){ printf '\033[2m%s\033[0m\n' "------------------------------------------------------------"; }

# ---------- defaults ----------
APP_DIR="/opt/emergency-backend"
SERVICE_NAME="emergency-backend"
PANEL_SERVICE="1plusvpn-panel"
PANEL_PORT="8088"
BIND_HOST="127.0.0.1"
BIND_PORT="9443"
DEFAULT_PANEL="https://127.0.0.1:4177"
DEFAULT_SUB="https://127.0.0.1:4177"
DEFAULT_SUPPORT="https://t.me/oneplusvpn_support"
DEFAULT_DATA_MB="200"
DEFAULT_DAYS="1"
DEFAULT_BACKUP_HOURS="12"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

line
c_b " 1PlusVPN — Emergency Charge backend installer"
line

# ---------- must be root ----------
if [[ $EUID -ne 0 ]]; then
  c_r "Please run as root:  sudo bash install.sh"
  exit 1
fi

# ---------- detect package manager ----------
if command -v apt-get >/dev/null 2>&1; then PM="apt"; 
elif command -v dnf >/dev/null 2>&1; then PM="dnf";
elif command -v yum >/dev/null 2>&1; then PM="yum";
else PM=""; fi

install_pkgs(){
  local pkgs=("$@")
  case "$PM" in
    apt) apt-get update -y -qq; DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "${pkgs[@]}";;
    dnf) dnf install -y -q "${pkgs[@]}";;
    yum) yum install -y -q "${pkgs[@]}";;
    *)   c_y "Unknown package manager — make sure these are installed: ${pkgs[*]}";;
  esac
}

c_g "[1/9] Installing system dependencies (python3, venv, curl)..."
if [[ "$PM" == "apt" ]]; then
  install_pkgs python3 python3-venv python3-pip curl
else
  install_pkgs python3 python3-pip curl || true
fi

# ---------- copy app files ----------
c_g "[2/9] Installing application to ${APP_DIR}..."
mkdir -p "$APP_DIR"

# Copy ALL Python files
for f in "$SRC_DIR"/*.py; do
  [[ -f "$f" ]] && cp -f "$f" "$APP_DIR/"
done

# Copy HTML files
for f in "$SRC_DIR"/*.html; do
  [[ -f "$f" ]] && cp -f "$f" "$APP_DIR/"
done

# Copy webapp.html specifically
[[ -f "$SRC_DIR/webapp.html" ]] && cp -f "$SRC_DIR/webapp.html" "$APP_DIR/webapp.html"

# Copy other necessary files
cp -f "$SRC_DIR/requirements.txt" "$APP_DIR/requirements.txt"
[[ -f "$SRC_DIR/admins.example.json" ]] && cp -f "$SRC_DIR/admins.example.json" "$APP_DIR/admins.example.json"
# don't overwrite an existing admins.json (per-admin overrides)
[[ -f "$SRC_DIR/admins.json" && ! -f "$APP_DIR/admins.json" ]] && cp -f "$SRC_DIR/admins.json" "$APP_DIR/admins.json" || true
[[ -f "$SRC_DIR/README.md" ]] && cp -f "$SRC_DIR/README.md" "$APP_DIR/README.md" || true

# ---------- python venv ----------
c_g "[3/9] Creating Python virtual environment & installing packages..."
if [[ ! -d "$APP_DIR/venv" ]]; then
  python3 -m venv "$APP_DIR/venv"
fi
"$APP_DIR/venv/bin/pip" install --quiet --upgrade pip
"$APP_DIR/venv/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"

# ---------- gather config (keep existing answers if .env present) ----------
c_g "[4/9] Configuration"
ENV_FILE="$APP_DIR/.env"

get_existing(){ # $1 = key
  [[ -f "$ENV_FILE" ]] && grep -E "^$1=" "$ENV_FILE" | head -n1 | cut -d= -f2- || true
}

ask(){ # $1 prompt  $2 default  $3 varname  $4 secret(optional)
  local prompt="$1" def="$2" __var="$3" secret="${4:-}" ans=""
  if [[ -n "$def" ]]; then prompt="$prompt [$def]"; fi
  if [[ "$secret" == "secret" ]]; then
    read -r -s -p "  $prompt: " ans; echo
  else
    read -r -p "  $prompt: " ans
  fi
  ans="${ans:-$def}"
  printf -v "$__var" '%s' "$ans"
}

CUR_PANEL="$(get_existing PANEL_BASE_URL)";   CUR_PANEL="${CUR_PANEL:-$DEFAULT_PANEL}"
CUR_SUB="$(get_existing SUB_BASE_URL)";       CUR_SUB="${CUR_SUB:-$DEFAULT_SUB}"
CUR_KEY="$(get_existing ADMIN_API_KEY)"
CUR_SUPPORT="$(get_existing SUPPORT_URL)";    CUR_SUPPORT="${CUR_SUPPORT:-$DEFAULT_SUPPORT}"
CUR_MB="$(get_existing EMERGENCY_DATA_MB)";   CUR_MB="${CUR_MB:-$DEFAULT_DATA_MB}"
CUR_DAYS="$(get_existing EMERGENCY_DAYS)";    CUR_DAYS="${CUR_DAYS:-$DEFAULT_DAYS}"
CUR_ORIG="$(get_existing ALLOWED_ORIGINS)"
CUR_TLS="$(get_existing PANEL_VERIFY_TLS)";   CUR_TLS="${CUR_TLS:-false}"
CUR_BOT="$(get_existing TELEGRAM_BOT_TOKEN)"
CUR_ADMIN="$(get_existing TELEGRAM_ADMIN_IDS)"
CUR_SUDO="$(get_existing SUDO_ADMIN_IDS)"
CUR_BACKUP="$(get_existing BACKUP_INTERVAL_HOURS)"; CUR_BACKUP="${CUR_BACKUP:-$DEFAULT_BACKUP_HOURS}"

echo
c_y "  Panel API base URL — this is the panel origin WITHOUT the dashboard base path."
c_y "  (The Rebecca API lives at the root, e.g. .../api/user/... ; do NOT add /oneplus.)"
ask "Panel base URL" "$CUR_PANEL" PANEL_BASE_URL
echo
c_y "  Subscription host base (WITHOUT /sub). Your sub links look like:"
c_y "    https://sublink.1plusnet.ir:4177/sub/<token>   ->  enter the part before /sub"
c_y "  If your sub links are on the SAME host as the panel, just enter the panel URL."
ask "Subscription base URL" "$CUR_SUB" SUB_BASE_URL
echo
c_y "  Create an admin API key in the panel:  My Account -> API Keys -> Create."
if [[ -n "$CUR_KEY" ]]; then
  ask "Admin API key (press Enter to keep existing)" "" NEW_KEY secret
  ADMIN_API_KEY="${NEW_KEY:-$CUR_KEY}"
else
  ask "Admin API key" "" ADMIN_API_KEY secret
  while [[ -z "$ADMIN_API_KEY" ]]; do
    c_r "  API key is required."
    ask "Admin API key" "" ADMIN_API_KEY secret
  done
fi
echo
ask "Support link (Telegram)" "$CUR_SUPPORT" SUPPORT_URL
ask "Emergency data (MB)" "$CUR_MB" EMERGENCY_DATA_MB
ask "Emergency time (days)" "$CUR_DAYS" EMERGENCY_DAYS
echo
c_y "  ALLOWED_ORIGINS = the origin(s) that serve your pages (for browser CORS)."
c_y "  Include your subscription page domain AND shop domain."
DEF_ORIG="${CUR_ORIG:-$SUB_BASE_URL}"
ask "Allowed origin(s), comma separated" "$DEF_ORIG" ALLOWED_ORIGINS
echo
ask "Verify panel TLS certificate? (true/false)" "$CUR_TLS" PANEL_VERIFY_TLS
ask "Port for backend API" "$BIND_PORT" HTTPS_PORT
ask "Auto backup interval (hours, 0=disabled)" "$CUR_BACKUP" BACKUP_INTERVAL_HOURS

echo
c_y "  ----- HTTPS for the backend API -----"
c_y "  The backend API is normally served over HTTPS (needed for the"
c_y "  browser renewal/charge page). You need an SSL certificate + key"
c_y "  (e.g. from certbot). On a fresh server you may not have one yet —"
c_y "  the installer will then run plain HTTP so the install completes."
USE_HTTPS="true"
ask "Enable HTTPS now? (true/false)" "$USE_HTTPS" USE_HTTPS
SSL_ARGS=""
HEALTH_SCHEME="https"
if [[ "${USE_HTTPS,,}" == "true" ]]; then
  ask "SSL certificate path (fullchain.pem)" "/etc/letsencrypt/live/your-domain/fullchain.pem" SSL_CERTFILE
  ask "SSL key path (privkey.pem)" "/etc/letsencrypt/live/your-domain/privkey.pem" SSL_KEYFILE
  if [[ -f "$SSL_CERTFILE" && -f "$SSL_KEYFILE" ]]; then
    SSL_ARGS="--ssl-certfile $SSL_CERTFILE --ssl-keyfile $SSL_KEYFILE"
  else
    c_r "  ⚠ Certificate files not found:"
    c_r "      $SSL_CERTFILE"
    c_r "      $SSL_KEYFILE"
    USE_HTTPS="false"
    ask "Continue with plain HTTP until you add the certificates? (true/false)" "$USE_HTTPS" USE_HTTPS
  fi
fi
if [[ "${USE_HTTPS,,}" != "true" ]]; then
  HEALTH_SCHEME="http"
fi

echo
c_b "  ----- Self-service renewal (plans + Telegram approval bot) -----"
c_y "  Create a bot via @BotFather and paste its token. Leave empty to disable renewal."
if [[ -n "$CUR_BOT" ]]; then
  ask "Telegram bot token (Enter to keep existing)" "" NEW_BOT secret
  TELEGRAM_BOT_TOKEN="${NEW_BOT:-$CUR_BOT}"
else
  ask "Telegram bot token" "" TELEGRAM_BOT_TOKEN secret
fi
c_y "  Admin numeric chat id(s) that approve payments (from @userinfobot). Comma separated."
ask "Telegram admin id(s)" "$CUR_ADMIN" TELEGRAM_ADMIN_IDS
c_y "  Sudo admin id(s) for system-wide backup/restore (optional, Enter to skip)."
ask "Sudo admin id(s)" "$CUR_SUDO" SUDO_ADMIN_IDS

# ---------- write .env ----------
c_g "[5/9] Writing ${ENV_FILE}..."
umask 077
cat > "$ENV_FILE" <<EOF
PANEL_BASE_URL=$PANEL_BASE_URL
SUB_BASE_URL=$SUB_BASE_URL
ALLOWED_ORIGINS=$ALLOWED_ORIGINS
ADMIN_API_KEY=$ADMIN_API_KEY
TELEGRAM_BOT_TOKEN=$TELEGRAM_BOT_TOKEN
TELEGRAM_ADMIN_IDS=$TELEGRAM_ADMIN_IDS
SUDO_ADMIN_IDS=$SUDO_ADMIN_IDS
BACKUP_INTERVAL_HOURS=$BACKUP_INTERVAL_HOURS
PORT=$HTTPS_PORT
PANEL_VERIFY_TLS=$PANEL_VERIFY_TLS
USE_HTTPS=$USE_HTTPS
$( [[ "${USE_HTTPS,,}" == "true" ]] && echo "SSL_CERTFILE=$SSL_CERTFILE" )
$( [[ "${USE_HTTPS,,}" == "true" ]] && echo "SSL_KEYFILE=$SSL_KEYFILE" )
EOF
chmod 600 "$ENV_FILE"

# ---------- service user ----------
SERVICE_USER="emergency"
if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER" 2>/dev/null \
    || useradd --system --no-create-home "$SERVICE_USER" 2>/dev/null || true
fi
id "$SERVICE_USER" >/dev/null 2>&1 || SERVICE_USER="root"
chown -R "$SERVICE_USER":"$SERVICE_USER" "$APP_DIR" 2>/dev/null || true

# ---------- systemd service for backend ----------
c_g "[6/9] Installing backend systemd service (${SERVICE_NAME})..."
cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<EOF
[Unit]
Description=1PlusVPN Emergency Charge backend
After=network.target

[Service]
WorkingDirectory=$APP_DIR
User=root
Group=root
EnvironmentFile=$ENV_FILE
ExecStart=$APP_DIR/venv/bin/uvicorn app:app --host 0.0.0.0 --port ${HTTPS_PORT} ${SSL_ARGS}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
systemctl restart "$SERVICE_NAME"

# ---------- nginx setup ----------
c_g "[7/9] Setting up nginx..."

# Check if nginx is installed
if ! command -v nginx >/dev/null 2>&1; then
  c_y "  nginx not found. Installing..."
  install_pkgs nginx || true
fi

if command -v nginx >/dev/null 2>&1; then
  echo
  c_y "  Do you want to set up a shop domain (e.g., shop.yourdomain.com)?"
  c_y "  This will create an nginx config to proxy your shop through a custom domain."
  read -r -p "  Enter shop domain (or press Enter to skip): " SHOP_DOMAIN
  
  if [[ -n "$SHOP_DOMAIN" ]]; then
    c_y "  Setting up nginx config for $SHOP_DOMAIN..."
    
    # Create nginx config
    cat > "/etc/nginx/sites-available/$SHOP_DOMAIN" <<NGINX_EOF
server {
    server_name $SHOP_DOMAIN;

    location / {
        proxy_pass https://127.0.0.1:${HTTPS_PORT};
        proxy_ssl_verify off;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/$SHOP_DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$SHOP_DOMAIN/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
}

server {
    if (\$host = $SHOP_DOMAIN) {
        return 301 https://\$host\$request_uri;
    }
    listen 80;
    server_name $SHOP_DOMAIN;
    return 404;
}
NGINX_EOF

    # Enable the site
    ln -sf "/etc/nginx/sites-available/$SHOP_DOMAIN" "/etc/nginx/sites-enabled/" 2>/dev/null || true
    
    # Test nginx config
    if nginx -t 2>/dev/null; then
      c_g "  ✅ nginx config created for $SHOP_DOMAIN"
      c_y "  ⚠️  SSL certificate not found yet. You need to:"
      c_y "     1. Point $SHOP_DOMAIN DNS to this server IP"
      c_y "     2. Run: sudo certbot --nginx -d $SHOP_DOMAIN"
      c_y "     3. Then: sudo systemctl reload nginx"
    else
      c_r "  ⚠️  nginx config test failed. Please check manually."
    fi
    
    # Update ALLOWED_ORIGINS with shop domain
    if [[ "$ALLOWED_ORIGINS" != *"https://$SHOP_DOMAIN"* ]]; then
      ALLOWED_ORIGINS="$ALLOWED_ORIGINS,https://$SHOP_DOMAIN"
      # Update .env
      sed -i "s|^ALLOWED_ORIGINS=.*|ALLOWED_ORIGINS=$ALLOWED_ORIGINS|" "$ENV_FILE"
      systemctl restart "$SERVICE_NAME"
    fi
  else
    c_y "  Skipping shop domain setup. You can configure it later from the panel."
  fi
  
  # Reload nginx
  systemctl reload nginx 2>/dev/null || true
  c_g "  ✅ nginx configured"
else
  c_y "  ⚠️  nginx installation failed. You can install it manually later."
fi

# ---------- install panel ----------
c_g "[8/9] Installing web panel (port ${PANEL_PORT})..."

# Create panel credentials if not exist
if [[ ! -f "$APP_DIR/.panel.json" ]]; then
  echo
  c_y "  Create credentials for the web panel (port ${PANEL_PORT}):"
  read -rp "  Panel username: " PUSER
  while true; do
    read -rsp "  Panel password: " PPASS; echo
    read -rsp "  Confirm password: " PPASS2; echo
    [[ "$PPASS" == "$PPASS2" && -n "$PPASS" ]] && break
    echo "  Passwords do not match or are empty, try again."
  done
  
  # Write hashed credentials
  PUSER="$PUSER" PPASS="$PPASS" "$APP_DIR/venv/bin/python" - <<'PY'
import os, json, sys
sys.path.insert(0, os.environ.get('APP_DIR', '/opt/emergency-backend'))
import panel
conf = {
    "username": os.environ["PUSER"],
    "password_hash": panel.hash_password(os.environ["PPASS"]),
}
import secrets
conf.setdefault("secret", secrets.token_hex(32))
json.dump(conf, open(panel.PANEL_CONF, "w"))
os.chmod(panel.PANEL_CONF, 0o600)
PY
fi

# Create panel systemd service
cat > "/etc/systemd/system/${PANEL_SERVICE}.service" <<EOF
[Unit]
Description=1PlusVPN Web Install Panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${APP_DIR}
Environment=BACKEND_DIR=${APP_DIR}
ExecStart=${APP_DIR}/venv/bin/python -m uvicorn panel:app --host 0.0.0.0 --port ${PANEL_PORT}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$PANEL_SERVICE" >/dev/null 2>&1 || true
systemctl restart "$PANEL_SERVICE"

# ---------- health check ----------
c_g "[9/9] Verifying services..."
sleep 2

OK=0
for i in 1 2 3 4 5; do
  if curl -fsSk "${HEALTH_SCHEME}://127.0.0.1:${HTTPS_PORT}/api/emergency/health" >/tmp/emg_health.json 2>/dev/null; then
    OK=1; break
  fi
  sleep 1
done

PANEL_OK=0
for i in 1 2 3 4 5; do
  if curl -fsS "http://127.0.0.1:${PANEL_PORT}/api/me" >/dev/null 2>&1; then
    PANEL_OK=1; break
  fi
  sleep 1
done

line
if [[ "$OK" == "1" ]]; then
  c_g " ✅ Backend is running on port ${HTTPS_PORT}."
  echo "    Health: $(cat /tmp/emg_health.json)"
else
  c_r " ⚠ Backend did not answer yet. Check logs:"
  echo "    journalctl -u ${SERVICE_NAME} -n 40 --no-pager"
fi
rm -f /tmp/emg_health.json 2>/dev/null || true

if [[ "$PANEL_OK" == "1" ]]; then
  c_g " ✅ Web panel is running on port ${PANEL_PORT}."
else
  c_r " ⚠ Web panel did not answer yet. Check logs:"
  echo "    journalctl -u ${PANEL_SERVICE} -n 40 --no-pager"
fi
line

IP=$(hostname -I 2>/dev/null | awk '{print $1}')

cat <<EOF

$(c_b "INSTALLATION COMPLETE")

$(c_g "✅ Backend API  : ${HEALTH_SCHEME}://${IP:-SERVER_IP}:${HTTPS_PORT}")
$(c_g "✅ Web Panel    : http://${IP:-SERVER_IP}:${PANEL_PORT}")
[[ -n "${SHOP_DOMAIN:-}" ]] && c_g "✅ Shop Domain : https://${SHOP_DOMAIN} (needs SSL setup)"

$(c_b "NEXT STEPS")

1) Open the web panel in your browser:
   http://${IP:-SERVER_IP}:${PANEL_PORT}

2) From the panel, you can:
   • Configure admins and their settings
   • Manage shop packages and bank cards
   • Set up HTTPS certificates
   • Configure nginx for your shop domain
   • Monitor service status and logs

3) If you set up a shop domain:
   • Point the domain's DNS A record to this server IP
   • Run: sudo certbot --nginx -d ${SHOP_DOMAIN:-yourdomain.com}
   • The panel will automatically detect and configure it

4) For the subscription page (frontend):
   • Set EMERGENCY_API_BASE in your HTML to: https://${IP:-SERVER_IP}:${HTTPS_PORT}
   • Or use your shop domain if configured

$(c_b "USEFUL COMMANDS")
   Backend status : systemctl status ${SERVICE_NAME}
   Panel status   : systemctl status ${PANEL_SERVICE}
   Backend logs   : journalctl -u ${SERVICE_NAME} -f
   Panel logs     : journalctl -u ${PANEL_SERVICE} -f
   Restart backend: systemctl restart ${SERVICE_NAME}
   Restart panel  : systemctl restart ${PANEL_SERVICE}
   nginx status   : systemctl status nginx
   SSL cert       : sudo certbot --nginx

EOF
c_g "Done. Enjoy 1PlusVPN! 🎉"
