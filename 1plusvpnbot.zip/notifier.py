"""
notifier.py — background loop that sends low-time / low-data warnings.
=====================================================================

Every CHECK_INTERVAL seconds it walks all bot-registered users and, for each:
  * if <= warn_days days remain (and not warned for THIS expiry yet) -> send the
    admin-configured time-warning text.
  * if <= warn_gb GB remain (and not warned for this cycle yet) -> send the
    admin-configured data-warning text.

Warning texts and thresholds are per-admin and edited from inside the bot
(bot_settings). Flags in user_registry prevent duplicate warnings; they reset
automatically when the account is renewed (expiry moves / usage drops).

Helpers injected from app.py via configure().
"""
from __future__ import annotations

import os
import time
import threading

import user_registry
import bot_settings as settings

H: dict = {}
CHECK_INTERVAL = int(os.environ.get("NOTIFIER_INTERVAL", "3600"))  # seconds (hourly)
# How many users are checked in parallel. Each check is 1–2 blocking panel
# calls; 8 keeps the cycle short without overloading the panel.
NOTIFIER_WORKERS = int(os.environ.get("NOTIFIER_WORKERS", "8"))


def configure(**helpers):
    """helpers: account_from_sub, effective_cfg, send_message"""
    global H
    H = helpers


def start():
    threading.Thread(target=_loop, daemon=True).start()


def _loop():
    # small delay so the app finishes starting up
    time.sleep(15)
    while True:
        try:
            _run_once()
        except Exception as e:
            print("notifier error:", e)
        time.sleep(CHECK_INTERVAL)


def _run_once():
    """
    Walk every registered user and fire the warnings that are due.

    PERF FIX: this used to be a strictly serial loop, and `_check_user` makes
    TWO blocking panel HTTPS calls per user (sub-info + get-user). With 2000
    registered customers at ~400 ms per pair that is over 13 minutes of a
    thread hammering the panel back-to-back with zero pacing — which is also
    exactly what made the panel slow for the bot's interactive requests.

    Now: a bounded worker pool (default 8) so a cycle finishes in a couple of
    minutes, plus per-user work stays isolated. The sub-token -> username
    memo added in app._resolve_username also removes one of the two calls for
    every user after the first cycle.
    """
    from concurrent.futures import ThreadPoolExecutor

    gb = 1024 ** 3
    now = int(time.time())
    rows = list(user_registry.all_registered())
    if not rows:
        return

    def _one(row):
        try:
            _check_user(row, now, gb)
        except Exception:
            pass
        finally:
            # Worker threads get their own sqlite handle; release it so the
            # pool does not accumulate one connection per thread forever.
            try:
                import dbx
                dbx.close_thread()
            except Exception:
                pass

    with ThreadPoolExecutor(max_workers=NOTIFIER_WORKERS,
                            thread_name_prefix="notifier") as pool:
        list(pool.map(_one, rows))


def _check_user(row, now, gb):
    sub = row["sub"]
    if not sub:
        return
    try:
        acc = H["account_from_sub"](sub)
    except Exception as e:
        # if the account was deleted from the panel, unlink it so we stop
        # bothering the panel every cycle
        s = str(e)
        if "404" in s or "not_found" in s:
            try:
                user_registry.remove(row["chat_id"])
            except Exception:
                pass
        return
    admin = acc.get("admin_username") or row["admin_username"] or ""
    cfg = H["effective_cfg"](admin)
    token = cfg.get("bot_token", "")
    if not token:
        return

    warn_days = int(cfg.get("warn_days", 1) or 1)
    warn_gb = float(cfg.get("warn_gb", 1) or 1)
    chat_id = row["chat_id"]

    # ---- reset flags if the account was renewed ----
    exp = int(acc.get("expire_epoch", 0) or 0)
    dl = int(acc.get("data_limit", 0) or 0)
    used = int(acc.get("used_traffic", 0) or 0)
    remaining_gb = (dl - used) / gb if dl > 0 else -1
    days_left = ((exp - now) // 86400) if exp > 0 else -1

    prev_warned_days = int(row["warned_days"] or 0)
    prev_warned_gb = int(row["warned_gb"] or 0)

    # If expiry moved beyond the previous warned expiry -> renewed: clear time flag
    if exp != prev_warned_days:
        # a new (or changed) expiry — only clear if it grew or was renewed
        if exp == 0 or exp > prev_warned_days:
            prev_warned_days = 0
    # If plenty of data again -> clear data flag
    if remaining_gb < 0 or remaining_gb > warn_gb:
        if prev_warned_gb:
            prev_warned_gb = 0
            user_registry.set_warn_flags(chat_id, warned_gb=0)

    # ---- time warning ----
    if exp > 0 and 0 <= days_left <= warn_days and prev_warned_days != exp:
        text = (cfg.get("warn_days_text") or settings.DEFAULT_WARN_DAYS_TEXT)
        try:
            text = text.replace("{days}", str(max(days_left, 0)))
        except Exception:
            pass
        _send_warn(token, chat_id, text)
        user_registry.set_warn_flags(chat_id, warned_days=exp)

    # ---- data warning ----
    if dl > 0 and 0 <= remaining_gb <= warn_gb and not prev_warned_gb:
        text = (cfg.get("warn_gb_text") or settings.DEFAULT_WARN_GB_TEXT)
        try:
            text = text.replace("{gb}", f"{max(remaining_gb, 0):.1f}")
        except Exception:
            pass
        _send_warn(token, chat_id, text)
        user_registry.set_warn_flags(chat_id, warned_gb=1)


def _send_warn(token, chat_id, text):
    kb = {"inline_keyboard": [[{"text": "🔄 تمدید اشتراک", "callback_data": "uu:renew"}]]}
    H["send_message"](token, chat_id, text, kb)
