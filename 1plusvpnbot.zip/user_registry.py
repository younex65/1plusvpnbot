"""
user_registry.py — maps Telegram chat_id <-> panel username.
============================================================

When a (non-admin) user sends their sub link to the bot, we resolve their
username and store (chat_id, username, admin_username, sub) here. This powers:
  * admin broadcast / private messages
  * the low-data / low-time warning notifications (phase 2)
  * the user self-service side (phase 2)
"""
from __future__ import annotations

import sqlite3

import dbx
import threading
from contextlib import contextmanager
from typing import Optional

_lock = threading.Lock()
_DB_PATH = None


def init(db_path: str) -> None:
    global _DB_PATH
    _DB_PATH = db_path
    with _conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS bot_users (
                chat_id        TEXT PRIMARY KEY,
                username       TEXT NOT NULL,
                admin_username TEXT,
                sub            TEXT,
                registered_at  INTEGER,
                warned_days    INTEGER DEFAULT 0,
                warned_gb      INTEGER DEFAULT 0,
                blocked        INTEGER DEFAULT 0,
                block_reason   TEXT,
                blocked_at     INTEGER
            )
            """
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_bot_users_uname ON bot_users(username)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_bot_users_admin ON bot_users(admin_username)")
        # Add blocked column if not exists (migration)
        try:
            c.execute("ALTER TABLE bot_users ADD COLUMN blocked INTEGER DEFAULT 0")
            c.execute("ALTER TABLE bot_users ADD COLUMN block_reason TEXT")
            c.execute("ALTER TABLE bot_users ADD COLUMN blocked_at INTEGER")
        except Exception:
            pass


@contextmanager
def _conn():
    """
    PERF FIX: was `sqlite3.connect()` inside a process-wide `threading.Lock()`
    on every single call — see dbx.py for the full explanation. Now it hands
    back this thread's cached WAL connection, so reads run in parallel and
    writes autocommit with a real busy_timeout instead of raising
    "database is locked".
    """
    yield dbx.get(_DB_PATH)


def register(chat_id, username, admin_username, sub) -> None:
    import time
    with _conn() as c:
        c.execute(
            """INSERT INTO bot_users (chat_id, username, admin_username, sub, registered_at)
               VALUES (?,?,?,?,?)
               ON CONFLICT(chat_id) DO UPDATE SET
                 username=excluded.username,
                 admin_username=excluded.admin_username,
                 sub=excluded.sub""",
            (str(chat_id), username, admin_username, sub, int(time.time())),
        )


def get_chat_id_for_user(username: str) -> Optional[str]:
    with _conn() as c:
        row = c.execute(
            "SELECT chat_id FROM bot_users WHERE username=? ORDER BY registered_at DESC LIMIT 1",
            (username,),
        ).fetchone()
    return row["chat_id"] if row else None


def get_admin_chat_ids(admin_username: str) -> list:
    with _conn() as c:
        rows = c.execute(
            "SELECT chat_id FROM bot_users WHERE admin_username=?",
            (admin_username,),
        ).fetchall()
    return [r["chat_id"] for r in rows]


def is_sub_registered(sub: str) -> Optional[dict]:
    """Check if a subscription link is already registered by another user.
    Returns the existing registration info, or None if not registered."""
    with _conn() as c:
        row = c.execute(
            "SELECT chat_id, username, registered_at FROM bot_users WHERE sub=?",
            (sub,)
        ).fetchone()
    return dict(row) if row else None


def all_registered():
    with _conn() as c:
        return c.execute("SELECT * FROM bot_users").fetchall()


def remove(chat_id) -> None:
    """Unlink a chat (e.g. its VPN account was deleted from the panel)."""
    with _conn() as c:
        c.execute("DELETE FROM bot_users WHERE chat_id=?", (str(chat_id),))


def set_warn_flags(chat_id, warned_days=None, warned_gb=None) -> None:
    sets, vals = [], []
    if warned_days is not None:
        sets.append("warned_days=?")
        vals.append(int(warned_days))
    if warned_gb is not None:
        sets.append("warned_gb=?")
        vals.append(int(warned_gb))
    if not sets:
        return
    vals.append(str(chat_id))
    with _conn() as c:
        c.execute(f"UPDATE bot_users SET {', '.join(sets)} WHERE chat_id=?", vals)


# ---- block / unblock management ----

def block_user(chat_id, reason: str = "") -> None:
    import time
    with _conn() as c:
        c.execute(
            "UPDATE bot_users SET blocked=1, block_reason=?, blocked_at=? WHERE chat_id=?",
            (reason, int(time.time()), str(chat_id))
        )


def unblock_user(chat_id) -> None:
    with _conn() as c:
        c.execute(
            "UPDATE bot_users SET blocked=0, block_reason=NULL, blocked_at=NULL WHERE chat_id=?",
            (str(chat_id),)
        )


def is_blocked(chat_id) -> bool:
    with _conn() as c:
        row = c.execute(
            "SELECT blocked FROM bot_users WHERE chat_id=?",
            (str(chat_id),)
        ).fetchone()
    return bool(row and row["blocked"])


def get_user_by_chat(chat_id) -> Optional[dict]:
    with _conn() as c:
        row = c.execute(
            "SELECT * FROM bot_users WHERE chat_id=?",
            (str(chat_id),)
        ).fetchone()
    return dict(row) if row else None


def search_users(query: str, admin_username: str = "") -> list:
    """Search users by username or chat_id. Returns list of dicts."""
    with _conn() as c:
        if admin_username:
            rows = c.execute(
                "SELECT * FROM bot_users WHERE (username LIKE ? OR chat_id LIKE ?) AND admin_username=? ORDER BY registered_at DESC LIMIT 50",
                (f"%{query}%", f"%{query}%", admin_username)
            ).fetchall()
        else:
            rows = c.execute(
                "SELECT * FROM bot_users WHERE (username LIKE ? OR chat_id LIKE ?) ORDER BY registered_at DESC LIMIT 50",
                (f"%{query}%", f"%{query}%")
            ).fetchall()
    return [dict(r) for r in rows]


def get_user_stats(admin_username: str = "") -> dict:
    """Get statistics of registered/blocked users."""
    with _conn() as c:
        if admin_username:
            total = c.execute(
                "SELECT COUNT(*) as cnt FROM bot_users WHERE admin_username=?",
                (admin_username,)
            ).fetchone()["cnt"]
            blocked = c.execute(
                "SELECT COUNT(*) as cnt FROM bot_users WHERE admin_username=? AND blocked=1",
                (admin_username,)
            ).fetchone()["cnt"]
        else:
            total = c.execute(
                "SELECT COUNT(*) as cnt FROM bot_users"
            ).fetchone()["cnt"]
            blocked = c.execute(
                "SELECT COUNT(*) as cnt FROM bot_users WHERE blocked=1"
            ).fetchone()["cnt"]
    return {"total": total, "blocked": blocked, "active": total - blocked}
