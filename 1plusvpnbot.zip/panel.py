"""
panel.py — web installer + management panel for the 1PlusVPN backend.
====================================================================

A single, self-contained FastAPI app (no new dependencies beyond what the
backend already uses: fastapi + uvicorn). It runs as its OWN service (usually
as root) so it can:

    * write /opt/emergency-backend/.env and admins.json
    * install / start / stop / restart the emergency-backend systemd service
    * enable HTTPS on port 9443 with the panel certs
    * show live service status + logs

Security
--------
* Username + password login. The password is stored ONLY as a PBKDF2 hash in
  /opt/emergency-backend/.panel.json (created by panel-install.sh).
* Sessions are stateless signed cookies (HMAC-SHA256 + expiry).
* Simple in-memory login rate-limit.
* Every /api/* route (except /api/login) requires a valid session.

This file is intentionally dependency-light and defensive: it never crashes the
whole panel on a bad shell command; it returns the error text instead.
"""
from __future__ import annotations

import os
import re
import json
import hmac
import admin_config
import time
import base64
import hashlib
import secrets
import subprocess
from typing import Optional

from fastapi import FastAPI, Request, Response, HTTPException, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, Response as RawResponse
from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Paths & config
# ---------------------------------------------------------------------------
INSTALL_DIR = os.environ.get("BACKEND_DIR", "/opt/emergency-backend")
ENV_PATH = os.path.join(INSTALL_DIR, ".env")
ADMINS_PATH = os.environ.get("ADMINS_CONFIG_PATH", os.path.join(INSTALL_DIR, "admins.json"))
PANEL_CONF = os.path.join(INSTALL_DIR, ".panel.json")
SERVICE_NAME = os.environ.get("SERVICE_NAME", "emergency-backend")

SESSION_TTL = 8 * 3600           # 8 hours
COOKIE_NAME = "panel_session"

# secret fields that must be masked when sending config to the browser
SECRET_KEYS = {"ADMIN_API_KEY", "TELEGRAM_BOT_TOKEN"}


# ---------------------------------------------------------------------------
# panel auth config (username + password hash + signing secret)
# ---------------------------------------------------------------------------

def _load_panel_conf() -> dict:
    try:
        with open(PANEL_CONF, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def _save_panel_conf(conf: dict) -> None:
    with open(PANEL_CONF, "w", encoding="utf-8") as fh:
        json.dump(conf, fh)
    try:
        os.chmod(PANEL_CONF, 0o600)
    except OSError:
        pass


def hash_password(password: str, salt: Optional[str] = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000)
    return f"pbkdf2$200000${salt}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt, b64 = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(iters))
        return hmac.compare_digest(base64.b64encode(dk).decode(), b64)
    except Exception:
        return False


def _secret() -> str:
    conf = _load_panel_conf()
    s = conf.get("secret")
    if not s:
        s = secrets.token_hex(32)
        conf["secret"] = s
        _save_panel_conf(conf)
    return s


# ---------------------------------------------------------------------------
# sessions (stateless signed cookie)
# ---------------------------------------------------------------------------

def make_session(username: str) -> str:
    exp = int(time.time()) + SESSION_TTL
    payload = f"{username}:{exp}"
    sig = hmac.new(_secret().encode(), payload.encode(), hashlib.sha256).hexdigest()
    raw = f"{payload}:{sig}"
    return base64.urlsafe_b64encode(raw.encode()).decode()


def check_session(token: str) -> Optional[str]:
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode()
        username, exp, sig = raw.rsplit(":", 2)
        payload = f"{username}:{exp}"
        good = hmac.new(_secret().encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(good, sig):
            return None
        if int(exp) < int(time.time()):
            return None
        return username
    except Exception:
        return None


# ---------------------------------------------------------------------------
# login rate-limit (in-memory)
# ---------------------------------------------------------------------------
_login_attempts: dict = {}


def _rate_ok(ip: str) -> bool:
    now = time.time()
    win = _login_attempts.get(ip, [])
    win = [t for t in win if now - t < 300]  # 5-minute window
    _login_attempts[ip] = win
    return len(win) < 8


def _rate_hit(ip: str) -> None:
    _login_attempts.setdefault(ip, []).append(time.time())


# ---------------------------------------------------------------------------
# shell helpers
# ---------------------------------------------------------------------------

def run(cmd: list, timeout: int = 120) -> dict:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {"ok": p.returncode == 0, "code": p.returncode,
                "out": p.stdout.strip(), "err": p.stderr.strip()}
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": -1, "out": "", "err": "timeout"}
    except Exception as e:
        return {"ok": False, "code": -1, "out": "", "err": str(e)}


# ---------------------------------------------------------------------------
# .env read / write (order-preserving, comment-tolerant)
# ---------------------------------------------------------------------------

def read_env() -> dict:
    data = {}
    if not os.path.exists(ENV_PATH):
        return data
    with open(ENV_PATH, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            data[k.strip()] = v.strip().strip('"').strip("'")
    return data


# The 8088 service does not load the backend's EnvironmentFile itself.
try:
    ADMINS_PATH = os.environ.get("ADMINS_CONFIG_PATH") or read_env().get("ADMINS_CONFIG_PATH") or ADMINS_PATH
except OSError:
    pass
if not os.path.isabs(ADMINS_PATH):
    ADMINS_PATH = os.path.join(INSTALL_DIR, ADMINS_PATH)


def write_env(values: dict) -> None:
    lines = ["# Generated by 1PlusVPN web panel", ""]
    for k, v in values.items():
        if v is None:
            v = ""
        lines.append(f"{k}={v}")
    os.makedirs(INSTALL_DIR, exist_ok=True)
    with open(ENV_PATH, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    try:
        os.chmod(ENV_PATH, 0o600)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------
app = FastAPI(title="1PlusVPN Install Panel", version="1.0.0")

_PANEL_HTML_PATH = os.path.join(os.path.dirname(__file__), "panel.html")


def _require(request: Request) -> str:
    tok = request.cookies.get(COOKIE_NAME, "")
    user = check_session(tok)
    if not user:
        raise HTTPException(status_code=401, detail="unauthorized")
    return user


@app.get("/", response_class=HTMLResponse)
def index():
    try:
        with open(_PANEL_HTML_PATH, "r", encoding="utf-8") as fh:
            return HTMLResponse(fh.read())
    except FileNotFoundError:
        return HTMLResponse("<h1>panel.html missing</h1>", status_code=500)


class LoginBody(BaseModel):
    username: str
    password: str


@app.post("/api/login")
def login(body: LoginBody, request: Request):
    ip = request.client.host if request.client else "?"
    if not _rate_ok(ip):
        raise HTTPException(status_code=429, detail="too_many_attempts")
    conf = _load_panel_conf()
    if not conf.get("username"):
        raise HTTPException(status_code=500, detail="panel_not_initialised")
    if body.username != conf.get("username") or not verify_password(body.password, conf.get("password_hash", "")):
        _rate_hit(ip)
        raise HTTPException(status_code=401, detail="bad_credentials")
    token = make_session(body.username)
    resp = JSONResponse({"ok": True})
    resp.set_cookie(COOKIE_NAME, token, httponly=True, samesite="lax", max_age=SESSION_TTL)
    return resp


@app.post("/api/logout")
def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(COOKIE_NAME)
    return resp


@app.get("/api/me")
def me(request: Request):
    return {"user": _require(request)}


# ---- status ---------------------------------------------------------------

@app.get("/api/status")
def status(request: Request):
    _require(request)
    svc = run(["systemctl", "is-active", SERVICE_NAME])
    enabled = run(["systemctl", "is-enabled", SERVICE_NAME])
    env = read_env()
    https_on = env.get("USE_HTTPS", "").lower() in ("1", "true", "yes")
    return {
        "service_active": svc["out"] == "active",
        "service_state": svc["out"] or svc["err"],
        "service_enabled": enabled["out"] == "enabled",
        "env_exists": os.path.exists(ENV_PATH),
        "admins_exists": os.path.exists(ADMINS_PATH),
        "https": https_on,
        "install_dir": INSTALL_DIR,
        "service_name": SERVICE_NAME,
    }


# ---- config (.env) --------------------------------------------------------

@app.get("/api/config")
def get_config(request: Request):
    _require(request)
    env = read_env()
    masked = {}
    for k, v in env.items():
        if k in SECRET_KEYS and v:
            masked[k] = "••••••" + v[-4:] if len(v) > 4 else "••••••"
        else:
            masked[k] = v
    return {"env": masked, "raw_keys": list(env.keys())}


class ConfigBody(BaseModel):
    values: dict


@app.post("/api/config")
def set_config(body: ConfigBody, request: Request):
    _require(request)
    current = read_env()
    for k, v in body.values.items():
        # keep the existing secret if the field was left masked/blank
        if k in SECRET_KEYS and (v == "" or (isinstance(v, str) and v.startswith("••••••"))):
            continue
        current[k] = v
    write_env(current)
    return {"ok": True}


# ---- admins.json ----------------------------------------------------------

@app.get("/api/admins")
def get_admins(request: Request):
    _require(request)
    try:
        data, revision = admin_config.snapshot(ADMINS_PATH)
        return {"admins": data, "revision": revision}
    except (OSError, ValueError):
        raise HTTPException(500, "خواندن فایل ادمین‌ها ممکن نیست.")


class AdminsBody(BaseModel):
    admins: dict
    revision: str = ""


@app.post("/api/admins")
def set_admins(body: AdminsBody, request: Request):
    _require(request)
    try:
        os.makedirs(os.path.dirname(os.path.abspath(ADMINS_PATH)), exist_ok=True)
        revision = admin_config.replace(ADMINS_PATH, body.admins, body.revision)
    except admin_config.Conflict:
        raise HTTPException(409, "لیست ادمین‌ها تغییر کرده؛ تب را دوباره باز کنید و تغییرات را اعمال کنید.")
    except (OSError, ValueError):
        raise HTTPException(500, "ذخیرهٔ فایل ادمین‌ها ممکن نیست.")
    return {"ok": True, "revision": revision}


# ---- shop settings (per admin; stored in bot_settings DB) -----------------

def _bot_settings():
    import bot_settings as _bs
    _bs.init(_db_path())
    return _bs


@app.get("/api/shop-settings")
def get_shop_settings(request: Request):
    _require(request)
    _bs = _bot_settings()
    # list admins from admins.json
    try:
        admins = list(json.load(open(ADMINS_PATH, encoding="utf-8")).keys())
    except Exception:
        admins = []
    admins = [a for a in admins if not a.startswith("_")]
    out = {}
    for a in admins:
        s = _bs.all_settings(a)
        out[a] = {
            "shop_enabled": str(s.get("shop_enabled", "0")) == "1",
            "shop_prefix": s.get("shop_prefix") or "ST",
            "renewal_enabled": str(s.get("renewal_enabled", "1")) != "0",
            "minGB": int(s.get("minGB", 1) or 1),
            "maxGB": int(s.get("maxGB", 1000) or 1000),
            "admin_bot_theme": s.get("admin_bot_theme") or "gradient",
            "user_bot_theme": s.get("user_bot_theme") or "gradient",
            "shop_domain": s.get("shop_domain") or "",
        }
    return {"admins": out}


class ShopSettingBody(BaseModel):
    admin: str
    shop_enabled: bool
    shop_prefix: str = "ST"
    renewal_enabled: bool = True
    minGB: int = 1
    maxGB: int = 1000
    admin_bot_theme: str = "gradient"
    user_bot_theme: str = "gradient"
    shop_domain: str = ""


@app.post("/api/shop-settings")
def set_shop_settings(body: ShopSettingBody, request: Request):
    _require(request)
    _bs = _bot_settings()
    _bs.set_setting(body.admin, "shop_enabled", "1" if body.shop_enabled else "0")
    _bs.set_setting(body.admin, "shop_prefix", (body.shop_prefix or "ST").strip())
    _bs.set_setting(body.admin, "renewal_enabled", "1" if body.renewal_enabled else "0")
    _bs.set_setting(body.admin, "minGB", str(int(body.minGB)))
    _bs.set_setting(body.admin, "maxGB", str(int(body.maxGB)))
    _bs.set_setting(body.admin, "admin_bot_theme", body.admin_bot_theme or "gradient")
    _bs.set_setting(body.admin, "user_bot_theme", body.user_bot_theme or "gradient")
    _bs.set_setting(body.admin, "shop_domain", (body.shop_domain or "").strip())
    return {"ok": True}


# ---- shop packages (per-service pricing) ----------------------------------

def _shop_mod():
    import shop as _sh
    _sh.init(_db_path())
    return _sh


@app.get("/api/shop-packages")
def get_shop_packages(request: Request, admin: str):
    _require(request)
    _sh = _shop_mod()
    return {"packages": _sh.list_packages(admin)}


@app.get("/api/shop-services")
def get_shop_services(request: Request, admin: str):
    """List the admin's real panel services so packages can map to them."""
    _require(request)
    try:
        admins = json.load(open(ADMINS_PATH, encoding="utf-8"))
    except Exception:
        admins = {}
    ov = admins.get(admin) or {}
    env = read_env()
    api_key = ov.get("api_key") or env.get("ADMIN_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=400, detail="no_api_key_for_admin")
    try:
        import panel_api
        # sync the panel base url + TLS verify from the backend's .env, since
        # the install-panel service does not load that .env itself.
        if env.get("PANEL_BASE_URL"):
            panel_api.PANEL_BASE_URL = env["PANEL_BASE_URL"].rstrip("/")
        panel_api.PANEL_VERIFY_TLS = env.get("PANEL_VERIFY_TLS", "true").lower() not in ("0", "false", "no")
        svcs = panel_api.PanelAPI(api_key).list_services()
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"services_error:{str(e)[:160]}")
    out = []
    for s in svcs:
        sid = s.get("id") or s.get("service_id") or s.get("_id")
        name = s.get("name") or s.get("title") or f"سرویس {sid}"
        if sid is not None:
            out.append({"id": sid, "name": name})
    return {"services": out}



class PackageBody(BaseModel):
    id: int = 0
    admin: str
    name: str
    service_id: str
    prices: dict
    note: str = ""
    enabled: bool = True
    sort_order: int = 0


@app.post("/api/shop-packages")
def save_shop_package(body: PackageBody, request: Request):
    _require(request)
    _sh = _shop_mod()
    if not body.name or not str(body.service_id):
        raise HTTPException(status_code=400, detail="name_and_service_required")
    prices = {}
    try:
        for k, v in (body.prices or {}).items():
            prices[int(k)] = int(v)
    except Exception:
        raise HTTPException(status_code=400, detail="bad_prices")
    if not prices:
        raise HTTPException(status_code=400, detail="prices_required")
    if body.id:
        _sh.update_package(body.id, body.name, body.service_id, prices,
                           body.note, body.enabled, body.sort_order)
        return {"ok": True, "id": body.id}
    pid = _sh.add_package(body.admin, body.name, body.service_id, prices,
                          body.note, body.sort_order)
    return {"ok": True, "id": pid}


@app.delete("/api/shop-packages/{pkg_id}")
def delete_shop_package(pkg_id: int, request: Request):
    _require(request)
    _sh = _shop_mod()
    _sh.delete_package(pkg_id)
    return {"ok": True}


# ---- service control ------------------------------------------------------

class ServiceBody(BaseModel):
    action: str  # start | stop | restart | enable | disable


@app.post("/api/service")
def service(body: ServiceBody, request: Request):
    _require(request)
    if body.action not in ("start", "stop", "restart", "enable", "disable"):
        raise HTTPException(status_code=400, detail="bad_action")
    r = run(["systemctl", body.action, SERVICE_NAME])
    return {"ok": r["ok"], "out": r["out"], "err": r["err"]}


@app.get("/api/logs")
def logs(request: Request, lines: int = 120):
    _require(request)
    r = run(["journalctl", "-u", SERVICE_NAME, "-n", str(min(max(lines, 10), 500)),
             "--no-pager", "-o", "cat"])
    return {"logs": r["out"] or r["err"]}


# ---- full install ---------------------------------------------------------

@app.post("/api/install")
def install(request: Request):
    """Create venv, install requirements, install+enable systemd service."""
    _require(request)
    steps = []

    def step(name, r):
        steps.append({"name": name, "ok": r["ok"], "out": r["out"][-400:], "err": r["err"][-400:]})
        return r["ok"]

    venv = os.path.join(INSTALL_DIR, "venv")
    if not os.path.exists(venv):
        if not step("ساخت venv", run(["python3", "-m", "venv", venv])):
            return {"ok": False, "steps": steps}
    pip = os.path.join(venv, "bin", "pip")
    step("بروزرسانی pip", run([pip, "install", "-q", "--upgrade", "pip"]))
    req = os.path.join(INSTALL_DIR, "requirements.txt")
    if not step("نصب وابستگی‌ها", run([pip, "install", "-q", "-r", req], timeout=600)):
        return {"ok": False, "steps": steps}

    # write systemd unit
    unit = f"""[Unit]
Description=1PlusVPN Emergency Backend
After=network.target

[Service]
Type=simple
WorkingDirectory={INSTALL_DIR}
ExecStart={venv}/bin/python -m uvicorn app:app --host 0.0.0.0 --port {_port()}{_ssl_args()}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
"""
    unit_path = f"/etc/systemd/system/{SERVICE_NAME}.service"
    try:
        with open(unit_path, "w", encoding="utf-8") as fh:
            fh.write(unit)
        steps.append({"name": "نوشتن systemd unit", "ok": True, "out": unit_path, "err": ""})
    except Exception as e:
        steps.append({"name": "نوشتن systemd unit", "ok": False, "out": "", "err": str(e)})
        return {"ok": False, "steps": steps}

    step("reload systemd", run(["systemctl", "daemon-reload"]))
    step("enable سرویس", run(["systemctl", "enable", SERVICE_NAME]))
    ok = step("start سرویس", run(["systemctl", "restart", SERVICE_NAME]))
    return {"ok": ok, "steps": steps}


def _port() -> str:
    """Backend port; robust against an empty/blank PORT value in .env."""
    p = (read_env().get("PORT") or "").strip()
    return p if p.isdigit() else "9443"


def _ssl_args() -> str:
    env = read_env()
    if env.get("USE_HTTPS", "").lower() in ("1", "true", "yes"):
        cert = env.get("SSL_CERTFILE", "").strip()
        key = env.get("SSL_KEYFILE", "").strip()
        if cert and key:
            return f" --ssl-certfile {cert} --ssl-keyfile {key}"
    return ""


# ---- HTTPS toggle ---------------------------------------------------------

class HttpsBody(BaseModel):
    enable: bool
    certfile: str = ""
    keyfile: str = ""


@app.post("/api/https")
def https(body: HttpsBody, request: Request):
    _require(request)
    env = read_env()
    if body.enable:
        cert = body.certfile or env.get("SSL_CERTFILE", "")
        key = body.keyfile or env.get("SSL_KEYFILE", "")
        if not (cert and key):
            raise HTTPException(status_code=400, detail="missing_cert_paths")
        if not (os.path.exists(cert) and os.path.exists(key)):
            raise HTTPException(status_code=400, detail="cert_files_not_found")
        env["USE_HTTPS"] = "true"
        env["SSL_CERTFILE"] = cert
        env["SSL_KEYFILE"] = key
    else:
        env["USE_HTTPS"] = "false"
    write_env(env)
    # rewriting the unit picks up the ssl args on next install/restart
    return {"ok": True, "note": "برای اعمال، سرویس را دوباره نصب/ری‌استارت کنید."}


# ---- change panel password ------------------------------------------------

class PassBody(BaseModel):
    old_password: str
    new_password: str


@app.post("/api/panel-password")
def panel_password(body: PassBody, request: Request):
    user = _require(request)
    conf = _load_panel_conf()
    if not verify_password(body.old_password, conf.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="wrong_old_password")
    if len(body.new_password) < 6:
        raise HTTPException(status_code=400, detail="password_too_short")
    conf["password_hash"] = hash_password(body.new_password)
    _save_panel_conf(conf)
    return {"ok": True}


# ---- card management (per admin; stored in shop DB) -------------------------

@app.get("/api/cards")
def get_cards(request: Request, admin: str):
    """List all bank cards for an admin."""
    _require(request)
    import shop as _sh
    _sh.init(_db_path())
    return {"cards": _sh.list_cards(admin)}


class CardBody(BaseModel):
    admin: str
    card_number: str
    card_holder: str = ""
    card_bank: str = ""
    card_id: int = 0


@app.post("/api/cards")
def save_card(body: CardBody, request: Request):
    """Create or update a bank card."""
    _require(request)
    import shop as _sh
    _sh.init(_db_path())
    if body.card_id:
        _sh.update_card(body.card_id, body.card_number, body.card_holder, body.card_bank)
        return {"ok": True, "id": body.card_id}
    else:
        cid = _sh.add_card(body.admin, body.card_number, body.card_holder, body.card_bank)
        return {"ok": True, "id": cid}


@app.delete("/api/cards/{card_id}")
def delete_card(card_id: int, request: Request):
    """Delete a bank card."""
    _require(request)
    import shop as _sh
    _sh.init(_db_path())
    _sh.delete_card(card_id)
    return {"ok": True}


# ---- nginx & shop domain management ---------------------------------------

@app.get("/api/nginx/status")
def nginx_status(request: Request):
    """Check nginx installation and configuration status."""
    _require(request)
    
    # Check if nginx is installed
    nginx_installed = run(["nginx", "-v"])["ok"]
    
    # Check nginx service status
    nginx_active = run(["systemctl", "is-active", "nginx"])["out"] == "active"
    
    # List existing nginx configs
    configs = []
    try:
        for f in os.listdir("/etc/nginx/sites-available"):
            if not f.startswith('.'):
                enabled = os.path.exists(f"/etc/nginx/sites-enabled/{f}")
                configs.append({"name": f, "enabled": enabled})
    except Exception:
        pass
    
    return {
        "installed": nginx_installed,
        "active": nginx_active,
        "configs": configs
    }


class NginxShopBody(BaseModel):
    domain: str
    backend_port: int = 9443


@app.post("/api/nginx/shop-domain")
def setup_shop_domain(body: NginxShopBody, request: Request):
    """Create or update nginx config for shop domain."""
    _require(request)
    
    domain = body.domain.strip()
    if not domain:
        raise HTTPException(status_code=400, detail="domain_required")
    
    # Validate domain format
    import re
    if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)*$', domain):
        raise HTTPException(status_code=400, detail="invalid_domain_format")
    
    # Check if nginx is installed
    if not run(["nginx", "-v"])["ok"]:
        # Try to install nginx
        result = run(["apt-get", "update", "-y", "-qq"])
        result = run(["apt-get", "install", "-y", "-qq", "nginx"])
        if not result["ok"]:
            result = run(["dnf", "install", "-y", "-q", "nginx"])
        if not result["ok"]:
            raise HTTPException(status_code=500, detail="nginx_install_failed")
    
    # Create nginx config
    config_path = f"/etc/nginx/sites-available/{domain}"
    config_content = f"""server {{
    server_name {domain};

    location / {{
        proxy_pass https://127.0.0.1:{body.backend_port};
        proxy_ssl_verify off;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}

    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{domain}/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
}}

server {{
    if ($host = {domain}) {{
        return 301 https://$host$request_uri;
    }}
    listen 80;
    server_name {domain};
    return 404;
}}
"""
    
    with open(config_path, 'w') as f:
        f.write(config_content)
    
    # Enable the site
    try:
        os.symlink(config_path, f"/etc/nginx/sites-enabled/{domain}")
    except FileExistsError:
        pass
    
    # Test nginx config
    test_result = run(["nginx", "-t"])
    if not test_result["ok"]:
        raise HTTPException(status_code=500, detail=f"nginx_config_invalid: {test_result['err']}")
    
    # Reload nginx
    run(["systemctl", "reload", "nginx"])
    
    # Update ALLOWED_ORIGINS in .env
    env_path = os.path.join(INSTALL_DIR, ".env")
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            lines = f.readlines()
        
        origins_line = None
        for i, line in enumerate(lines):
            if line.startswith("ALLOWED_ORIGINS="):
                origins_line = i
                break
        
        if origins_line is not None:
            current_origins = lines[origins_line].strip().split("=", 1)[1]
            if f"https://{domain}" not in current_origins:
                new_origins = f"{current_origins},https://{domain}"
                lines[origins_line] = f"ALLOWED_ORIGINS={new_origins}\n"
                
                with open(env_path, 'w') as f:
                    f.writelines(lines)
                
                # Restart backend to apply new origins
                run(["systemctl", "restart", SERVICE_NAME])
    
    return {
        "ok": True,
        "domain": domain,
        "message": f"Nginx config created for {domain}. Don't forget to set up SSL: sudo certbot --nginx -d {domain}"
    }


@app.post("/api/nginx/install-certbot")
def install_certbot(request: Request):
    """Install certbot for SSL certificates."""
    _require(request)
    
    # Try to install certbot
    result = run(["apt-get", "install", "-y", "-qq", "certbot", "python3-certbot-nginx"])
    if not result["ok"]:
        result = run(["dnf", "install", "-y", "-q", "certbot", "python3-certbot-nginx"])
    
    if not result["ok"]:
        raise HTTPException(status_code=500, detail="certbot_install_failed")
    
    return {"ok": True, "message": "Certbot installed successfully"}


@app.get("/api/nginx/certbot-status")
def certbot_status(request: Request):
    """Check if certbot is installed."""
    _require(request)
    
    installed = run(["certbot", "--version"])["ok"]
    
    return {"installed": installed}


# ---- backup / restore (via the web panel) ---------------------------------

def _db_path() -> str:
    """The backend DB path (from .env, else default next to app.py)."""
    env = read_env()
    return env.get("DB_PATH") or os.path.join(INSTALL_DIR, "emergency.db")


@app.get("/api/backup")
def download_backup(request: Request):
    """Build a full backup (db + admins.json) and stream it as a .zip download."""
    _require(request)
    import backup as _bk
    db = _db_path()
    if not os.path.exists(db):
        raise HTTPException(status_code=404, detail="db_not_found")
    content = _bk.make_backup(db, ADMINS_PATH)
    import datetime as _dt
    fname = f"1plusvpn-backup-{_dt.datetime.now().strftime('%Y%m%d-%H%M')}.zip"
    return RawResponse(
        content=content,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@app.post("/api/restore")
async def upload_restore(request: Request, file: UploadFile = File(...)):
    """Restore a previously downloaded .zip backup, then restart the service."""
    _require(request)
    import backup as _bk
    data = await file.read()
    if len(data) > 64 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="file_too_large")
    db = _db_path()
    try:
        res = _bk.restore_backup(data, db, ADMINS_PATH)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    # restart the backend so it picks up the restored db/config
    r = run(["systemctl", "restart", SERVICE_NAME])
    return {"ok": True, "db": res.get("db"), "admins": res.get("admins"),
            "restarted": r["ok"], "restart_err": r["err"]}
