"""
panel_api.py — Rebecca panel API client with per-admin API keys.
============================================================

Each admin authenticates the panel with THEIR OWN api key (stored in
admins.json under "api_key"). This guarantees isolation: when admin `1plus`
lists/searches users, the panel only returns `1plus`'s users. An admin can
never touch another admin's users.

The sudo key (ADMIN_API_KEY from .env) is still used as a fallback for
operations that resolve admin ownership (e.g. sub-link -> username ->
admin_username) and for the shared emergency-charge flow.

Performance: uses connection pooling (one persistent httpx.Client per api key)
to avoid the overhead of opening a new TCP+TLS connection for every request.
"""
from __future__ import annotations

import os
import time
import threading
from typing import Optional

import httpx
from urllib.parse import quote

PANEL_BASE_URL = os.environ.get("PANEL_BASE_URL", "https://all.1plusnet.ir:4177").rstrip("/")
PANEL_VERIFY_TLS = os.environ.get("PANEL_VERIFY_TLS", "true").lower() not in ("0", "false", "no")

# ---- Connection pool: one persistent client per api key -----------------
_clients_lock = threading.Lock()
_clients: dict = {}  # api_key -> httpx.Client


def _get_client(api_key: str) -> httpx.Client:
    """Get or create a persistent httpx.Client for the given api key."""
    key = api_key or "__default__"
    with _clients_lock:
        if key not in _clients:
            _clients[key] = httpx.Client(
                # Split timeouts + an explicit keep-alive pool. With a single
                # 20 s blanket timeout an unreachable panel pinned a bot worker
                # for 20 s per call; connect now fails in 6 s.
                timeout=httpx.Timeout(connect=6.0, read=20.0, write=20.0, pool=10.0),
                limits=httpx.Limits(max_keepalive_connections=20,
                                    max_connections=50, keepalive_expiry=90.0),
                verify=PANEL_VERIFY_TLS,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Accept": "application/json",
                },
            )
        return _clients[key]


class PanelError(Exception):
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.message = message
        self.status = status


class PanelAPI:
    """Thin wrapper around the Rebecca panel REST API, bound to one api key.
    Uses connection pooling — one persistent HTTP connection per api key."""

    def __init__(self, api_key: str):
        self.api_key = (api_key or "").strip()
        self._client = _get_client(self.api_key)

    def _req(self, method: str, path: str, **kw) -> dict:
        url = f"{PANEL_BASE_URL}{path}"
        try:
            r = self._client.request(method, url, **kw)
        except httpx.HTTPError as e:
            raise PanelError(f"panel_unreachable: {e}", 502)
        if r.status_code in (401, 403):
            raise PanelError("unauthorized (کلید API نامعتبر یا بدون دسترسی)", r.status_code)
        if r.status_code == 404:
            raise PanelError("not_found", 404)
        if r.status_code >= 400:
            raise PanelError(f"api_error_{r.status_code}: {r.text[:200]}", r.status_code)
        try:
            return r.json()
        except Exception:
            return {}

    # ---- users -----------------------------------------------------------
    def list_users(self, search: str = "", offset: int = 0, limit: int = 50,
                   status: str = "") -> dict:
        """List this admin's users. Returns {users:[...], total:int} (name-tolerant)."""
        params = {"offset": offset, "limit": limit}
        if search:
            params["search"] = search
        if status:
            params["status"] = status
        data = self._req("GET", "/api/users", params=params)
        # Rebecca may return a list or {users:[...], total:n}
        if isinstance(data, list):
            return {"users": data, "total": len(data)}
        users = data.get("users") or data.get("items") or data.get("data") or []
        total = data.get("total") or data.get("count") or len(users)
        return {"users": users, "total": total}

    def iter_all_users(self, status: str = "", page: int = 500):
        """Yield every user of this admin, paging through the API.

        PERF FIX: the page size was 200 and every page was fetched serially, so
        a 3000-user admin cost 15 sequential HTTPS round trips just to render
        the stats screen. 500 is the largest page the Rebecca API accepts
        reliably and cuts the number of round trips by 60%.

        FIX (correctness): the old loop also never guarded against an API that
        ignores `offset` — it would then loop forever yielding the same page.
        A safety bound on total iterations is now in place.
        """
        off = 0
        seen = 0
        max_iterations = 1000  # 500k users; a runaway pager stops here
        for _ in range(max_iterations):
            res = self.list_users(offset=off, limit=page, status=status)
            batch = res["users"]
            if not batch:
                break
            for u in batch:
                yield u
            seen += len(batch)
            if len(batch) < page:
                break
            off += page

    def count_users(self, status: str = "") -> int:
        """Ask the panel for a count without downloading every record."""
        res = self.list_users(offset=0, limit=1, status=status)
        return int(res.get("total") or 0)

    # BUG FIX: usernames were interpolated into the path raw. Any username
    # containing "/", "?", "#", a space or a non-ASCII character produced a
    # malformed URL and a confusing 404 ("not_found") instead of working.
    # Every per-user endpoint now percent-encodes the username.
    def get_user(self, username: str) -> dict:
        return self._req("GET", f"/api/user/{quote(str(username), safe='')}")

    def update_user(self, username: str, payload: dict) -> dict:
        """PUT accepts a PARTIAL field set — send only what you are changing."""
        return self._req("PUT", f"/api/user/{quote(str(username), safe='')}", json=payload)

    def delete_user(self, username: str) -> dict:
        return self._req("DELETE", f"/api/user/{quote(str(username), safe='')}")

    def reset_usage(self, username: str) -> dict:
        return self._req("POST", f"/api/user/{quote(str(username), safe='')}/reset")

    def revoke_sub(self, username: str) -> dict:
        return self._req("POST", f"/api/user/{quote(str(username), safe='')}/revoke_sub")

    def create_user(self, payload: dict) -> dict:
        return self._req("POST", "/api/user", json=payload)

    def create_user_v2(self, payload: dict) -> dict:
        return self._req("POST", "/api/v2/users", json=payload)

    def active_next(self, username: str) -> dict:
        return self._req("POST", f"/api/user/{quote(str(username), safe='')}/active-next")

    # ---- bulk (whole admin) ---------------------------------------------
    def disable_all_users(self, admin_username: str) -> dict:
        return self._req("POST", f"/api/admin/{admin_username}/users/disable")

    def activate_all_users(self, admin_username: str) -> dict:
        return self._req("POST", f"/api/admin/{admin_username}/users/activate")

    def bulk_action(self, payload: dict) -> dict:
        """POST /api/users/actions — flexible bulk operation on selected users."""
        return self._req("POST", "/api/users/actions", json=payload)

    # ---- services / inbounds --------------------------------------------
    def list_services(self) -> list:
        data = self._req("GET", "/api/v2/services")
        if isinstance(data, list):
            return data
        return data.get("services") or data.get("items") or data.get("data") or []

    def list_inbounds(self) -> list:
        data = self._req("GET", "/api/inbounds")
        if isinstance(data, list):
            return data
        return data.get("inbounds") or data.get("items") or []

    # ---- account ---------------------------------------------------------
    def current_admin(self) -> dict:
        return self._req("GET", "/api/admin")

    def myaccount(self) -> dict:
        return self._req("GET", "/api/myaccount")


# ---- field helpers (format-tolerant) -------------------------------------

def user_field(u: dict, *names, default=None):
    for n in names:
        if n in u and u[n] is not None:
            return u[n]
    return default


def to_bytes_gb(gb: float) -> int:
    return int(round(gb * 1024 * 1024 * 1024))


def bytes_to_gb(b: int) -> float:
    return (b or 0) / (1024 * 1024 * 1024)


def now_epoch() -> int:
    return int(time.time())
