"""
bot_user.py — user (customer) side of the Telegram bot. Phase 2.
================================================================

A non-admin user sends their subscription link to the bot. We:
  * resolve their username, store (chat_id <-> username) in user_registry
  * show a menu: account stats, per-config download, sub link, renew, referral

Renewal inside the bot uses EXACTLY the same logic as the /renew page (same
plans/prices/card from the admin's effective config, same order + admin
approval flow). Referral discounts are applied automatically.

Helpers from app.py are injected via configure() to avoid a circular import.
"""
from __future__ import annotations

import time
import threading
from typing import Callable

import user_registry
import referrals
import bot_settings as settings

# ---- injected from app.py -------------------------------------------------
H: dict = {}


def configure(**helpers):
    """helpers: resolve_username, account_from_sub, effective_cfg,
    admin_username_for, fetch_configs, create_order, notify_admin_receipt"""
    global H
    H = helpers


# ---- telegram helpers (lazy import to avoid circular import) --------------

def _tg():
    import bot
    return bot


def _send(token, chat_id, text, kb=None):
    return _tg().send(token, chat_id, text, kb)


def _edit(token, chat_id, mid, text, kb=None):
    return _tg().edit(token, chat_id, mid, text, kb)


def _safe_edit(token, chat_id, mid, text, kb=None):
    """edit with guaranteed fallback — see bot.safe_edit."""
    return _tg().safe_edit(token, chat_id, mid, text, kb)


def _kb(rows):
    return {"inline_keyboard": rows}


def _btn(text, data):
    return {"text": text, "callback_data": data}


def _answer(token, cb_id, text="", alert=False):
    _tg().answer(token, cb_id, text, alert)


def _conv():
    return _tg().CONV


# ---- menus ----------------------------------------------------------------

def user_menu(has_account=True):
    """Inline keyboard for regular users."""
    if has_account:
        rows = [
            [_btn("📊 آمار اکانت", "uu:stats"), _btn("📱 کانفیگ‌ها", "uu:cfgs")],
            [_btn("🔗 لینک اشتراک", "uu:sub"), _btn("🔄 تمدید اشتراک", "uu:renew")],
            [_btn("🛒 خرید اکانت جدید", "uu:buy"), _btn("📋 اشتراک‌های من", "uu:my_subs")],
            [_btn("🎁 کد هدیه", "uu:gift"), _btn("🎟 کد تخفیف", "uu:redeem")],
            [_btn("🎁 دعوت دوستان", "uu:ref")],
            [_btn("🔁 تغییر لینک", "uu:relink")],
        ]
    else:
        rows = [
            [_btn("📝 ثبت لینک اشتراک", "uu:reg_link"), _btn("🛒 خرید اکانت جدید", "uu:buy")],
            [_btn("🎁 کد هدیه", "uu:gift"), _btn("🎟 کد تخفیف", "uu:redeem")],
            [_btn("🎁 دعوت دوستان", "uu:ref")],
        ]
    return _kb(rows)


def _register_prompt():
    """Show registration prompt for users who haven't registered yet."""
    return (
        "👋 به ربات <b>1PlusVPN</b> خوش آمدید! 🎉\n\n"
        "✅ اگر لینک اشتراک فعال دارید، از دکمه <b>ثبت لینک اشتراک</b> اقدام کنید.\n\n"
        "🛒 در غیر این صورت، از دکمه <b>خرید اکانت جدید</b> استفاده کنید."
    )


def _fmt_account(acc: dict) -> str:
    used = acc.get("used_traffic", 0) or 0
    dl = acc.get("data_limit", 0) or 0
    exp = acc.get("expire_epoch", 0) or 0
    gb = 1024 ** 3
    if dl == 0:
        vol = f"{used/gb:.2f} گیگ / نامحدود"
    else:
        rem = max(0, dl - used)
        vol = f"{used/gb:.2f} از {dl/gb:.1f} گیگ (باقی: {rem/gb:.2f})"
    if exp == 0:
        tm = "نامحدود"
    else:
        days = max(0, (exp - int(time.time())) // 86400)
        tm = f"{days} روز باقی‌مانده"
    st_map = {"active": "🟢 فعال", "disabled": "🔴 غیرفعال",
              "limited": "🟡 حجم تمام", "expired": "🟠 منقضی", "on_hold": "⏸ در انتظار"}
    st = st_map.get(str(acc.get("status", "")).lower(), acc.get("status", ""))
    return (f"📊 <b>وضعیت اکانت شما</b>\n\n"
            f"👤 {acc.get('username','')}\n"
            f"وضعیت: {st}\n"
            f"📦 حجم: {vol}\n"
            f"⏳ زمان: {tm}")


# ==========================================================================
#  entry points (called from bot.py when sender is NOT an admin)
# ==========================================================================

def handle_message(update, token):
    msg = update.get("message") or {}
    chat_id = msg.get("chat", {}).get("id")
    text = (msg.get("text") or "").strip()
    photo = msg.get("photo")
    from_id = str(msg.get("from", {}).get("id", ""))

    # Check if user is blocked.
    # PERF FIX: this did `is_blocked()` + `get_user_by_chat()` = two separate
    # connect-lock-query-close round trips before ANY message was even looked
    # at, and then `_find_user()` scanned the whole table a third time. It is
    # now a single cached, indexed lookup shared with the rest of the handler.
    row = _find_user(chat_id)
    if row and row.get("blocked"):
        reason = row.get("block_reason") or ""
        msg_text = "️ <b>شما از بات مسدود شده‌اید.</b>"
        if reason:
            msg_text += f"\n\nدلیل مسدودیت: {reason}"
        _send(token, chat_id, msg_text)
        return

    conv = _conv().get(chat_id)

    # a photo while waiting for a receipt
    if photo and conv and conv["state"] == "uu_receipt":
        _receipt_received(token, chat_id, conv["data"], photo)
        return

    # a photo while waiting for a BUY receipt
    if photo and conv and conv["state"] == "uu_buy_receipt":
        _buy_receipt_received(token, chat_id, conv["data"], photo)
        return

    # BUGFIX (دکمه منوی اصلی): the reply-keyboard "🏠 منوی اصلی" must work
    # from ANY section — including the middle of a uu_* conversation.
    # Previously this check came AFTER the conv-input check, so while the bot
    # was waiting for any input the button's text was swallowed by
    # _conv_input() as if it were user data: in "uu_gb" it caused endless
    # "یک عدد بفرستید", in "uu_ref" the label was saved as a REFERRAL
    # USERNAME, and in "uu_redeem"/"uu_gift" it was tried as a REDEEM CODE.
    # The keyboard label is a fixed string that can never be real user input,
    # so it is safe to intercept it here, before the conversation state.
    if text == "🏠 منوی اصلی":
        _conv().clear(chat_id)
        _user_shortcut(token, chat_id, "home", row)
        return

    # conversation inputs
    if conv and conv["state"].startswith("uu_"):
        _conv_input(token, chat_id, text, conv)
        return

    # ---- Force channel membership check ----
    if text in ("/start", "start", "منو", "/menu") or (text and ("/sub/" in text or text.startswith("http"))):
        if _check_force_channel(token, chat_id, from_id):
            return  # user not in channel, message already sent

    # /start or a bare sub link -> register + menu
    if text in ("/start", "start", "منو", "/menu"):
        import bot as _b
        _b.set_bot_commands(token, is_user=True)
        # PERF FIX: /start used to make TWO blocking panel HTTP calls
        # (`account_from_sub` = /sub/{id}/info + /api/user/{name}) *before*
        # drawing the menu, purely to detect a deleted account. On a slow panel
        # that is 1–4 s of dead time on the single most-used command in the bot.
        # The menu is now drawn immediately and the account is re-validated
        # lazily in the background; if it really is gone, the user is unlinked
        # and told — without ever making them wait for the menu.
        if row:
            _b.send_kb(token, chat_id,
                       f"👋 خوش آمدید <b>{row['username']}</b>!\n\n"
                       "از منوی زیر گزینه موردنظر را انتخاب کنید:",
                       _b.user_reply_kb())
            _send(token, chat_id, "📋 <b>منوی اصلی</b>", user_menu(has_account=True))
            _verify_account_async(token, chat_id, row)
        else:
            _send(token, chat_id, _register_prompt(), user_menu(has_account=False))
        return

    # persistent reply-keyboard shortcuts + slash commands
    shortcut = {
        "🏠 منوی اصلی": "home", "/menu": "home",
        "📊 آمار اکانت": "stats", "/stats": "stats",
        "🔄 تمدید": "renew", "/renew": "renew",
        "📱 کانفیگ‌ها": "cfgs", "/configs": "cfgs",
        "🔗 لینک اشتراک": "sub", "/sub": "sub",
    }.get(text)
    if shortcut:
        row = _find_user(chat_id)
        # "home" works for everyone; other shortcuts require registration
        if shortcut != "home" and not row:
            _send(token, chat_id, "ابتدا لینک اشتراک خود را ارسال کنید.")
            return
        _user_shortcut(token, chat_id, shortcut, row)
        return

    if text and ("/sub/" in text or text.startswith("http")):
        _register_from_sub(token, chat_id, text)
        return

    _send(token, chat_id, "برای شروع، لینک اشتراک خود را ارسال کنید یا /start را بزنید.")


_verify_pool = None
_verify_pool_lock = threading.Lock()


def _verify_account_async(token, chat_id, row):
    """Re-validate a linked account against the panel OFF the hot path.

    Keeps /start instant while still unlinking accounts that were deleted in
    the panel. Runs on a tiny dedicated pool so it can never starve the update
    workers.
    """
    global _verify_pool
    if _verify_pool is None:
        with _verify_pool_lock:
            if _verify_pool is None:
                from concurrent.futures import ThreadPoolExecutor
                _verify_pool = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="acct-verify")

    def _job():
        try:
            H["account_from_sub"](row["sub"])
        except Exception as exc:
            if _is_not_found(exc):
                try:
                    user_registry.remove(chat_id)
                    _invalidate_user_cache(chat_id)
                    _send(token, chat_id,
                          "⚠️ اکانت شما دیگر در سیستم وجود ندارد یا حذف شده است.\n\n"
                          "برای اتصال دوباره، <b>لینک اشتراک جدید</b> خود را ارسال کنید.",
                          user_menu(has_account=False))
                except Exception:
                    pass

    try:
        _verify_pool.submit(_job)
    except Exception:
        pass


def _user_shortcut(token, chat_id, which, row):
    """Handle a user reply-keyboard / slash shortcut by sending a fresh message."""
    if which == "home":
        has_account = row is not None
        _send(token, chat_id, "یکی از گزینه‌ها را انتخاب کنید:", user_menu(has_account=has_account))
        return
    m = _send(token, chat_id, "⏳ لطفاً صبر کنید...")
    try:
        mid = m["result"]["message_id"]
    except Exception:
        mid = None
    if mid is None:
        return
    # reuse the callback router with a fresh message to edit
    _route(token, "shortcut", chat_id, mid, which, row)


def handle_callback(update, token):
    cb = update.get("callback_query") or {}
    data = cb.get("data", "")
    cb_id = cb.get("id")
    msg = cb.get("message") or {}
    chat_id = (msg.get("chat") or {}).get("id")
    mid = msg.get("message_id")

    if not data.startswith("uu:"):
        _answer(token, cb_id)
        return
    action = data.split(":", 1)[1]
    sender = (cb.get("from") or {}).get("id")
    from_id = str(sender or "")
    if action == "home" and chat_id is None:
        if not isinstance(sender, int) or sender <= 0:
            _answer(token, cb_id)
            return
        chat_id, mid = sender, None
    row = _find_user(chat_id)

    # force channel join check
    if action == "join_check":
        _answer(token, cb_id)
        _handle_join_check(token, chat_id, from_id, mid)
        return

    # allow these actions even without a linked account
    _no_account_actions = ("home", "buy", "buy_noacc", "buy_plans", "gift", "redeem", "ref", "my_subs", "reg_link")
    _is_buy_related = action.startswith("buy_pkg:") or action.startswith("buy_plan:")
    if not row and action not in _no_account_actions and not _is_buy_related:
        _answer(token, cb_id, "ابتدا لینک اشتراک خود را ارسال کنید.", alert=True)
        return

    try:
        _route(token, cb_id, chat_id, mid, action, row)
    except Exception as e:
        import traceback
        print(f"[bot_user] callback error action={action!r}: {e}")
        traceback.print_exc()
        _answer(token, cb_id, f"خطا: {str(e)[:120]}", alert=True)


# ---- registration ---------------------------------------------------------

# In-memory cache: chat_id -> user dict (avoids scanning all rows every time)
_user_cache = {}
_user_cache_lock = threading.Lock()
_CACHE_TTL = 60  # seconds


def _find_user(chat_id):
    """Find a registered user by chat_id.

    PERF FIX: this used to do

        for r in user_registry.all_registered():      # SELECT * FROM bot_users
            if str(r["chat_id"]) == chat_id:

    i.e. **load the entire bot_users table into Python and linear-scan it** —
    while holding the old process-wide sqlite lock — on every message, every
    callback, every force-join check and every buy step. With a few thousand
    registered customers that is tens of milliseconds of lock-held work per
    update, multiplied by the 3–4 times per update it was called.

    `chat_id` is the PRIMARY KEY, so it is now a single indexed lookup.
    Negative results are cached too (they were not, so unregistered users —
    exactly the people spamming /start — re-scanned the whole table every time).
    """
    chat_id = str(chat_id)
    cached = _user_cache.get(chat_id)
    if cached is not None and (time.time() - cached.get("_ts", 0)) < _CACHE_TTL:
        return cached.get("row")

    row = user_registry.get_user_by_chat(chat_id)
    if row is not None:
        row = dict(row)
    with _user_cache_lock:
        _user_cache[chat_id] = {"row": row, "_ts": time.time()}
    return row


def _find_user_full(chat_id):
    """Row + block state in ONE query (see user_registry.get_user_by_chat)."""
    return _find_user(chat_id)


def _invalidate_user_cache(chat_id=None):
    """Remove cached user data. Call after registration or unlinking."""
    with _user_cache_lock:
        if chat_id:
            _user_cache.pop(str(chat_id), None)
        else:
            _user_cache.clear()


def _register_from_sub(token, chat_id, sub):
    try:
        username = H["resolve_username"](sub)
    except Exception:
        _send(token, chat_id, "❌ لینک اشتراک معتبر نیست. دوباره تلاش کنید.")
        return
    
    # Check if this sub link is already registered by another user
    existing = user_registry.is_sub_registered(sub)
    if existing and str(existing["chat_id"]) != str(chat_id):
        _send(token, chat_id,
              "❌ <b>این لینک اشتراک قبلاً توسط کاربر دیگری ثبت شده است.</b>\n\n"
              "هر لینک اشتراک فقط می‌تواند توسط یک کاربر ثبت شود.\n"
              "اگر این لینک متعلق به شماست، با پشتیبانی تماس بگیرید.")
        return
    
    admin_username = ""
    try:
        admin_username = H["admin_username_for"](username) or ""
    except Exception:
        pass
    user_registry.register(chat_id, username, admin_username, sub)
    _invalidate_user_cache(chat_id)
    _send(token, chat_id,
          f"✅ اکانت <b>{username}</b> با موفقیت به ربات متصل شد.\n"
          "از این پس هشدارهای نزدیک‌شدن به پایان حجم/زمان را دریافت می‌کنید.",
          user_menu())


def _account_missing(token, chat_id, mid=None):
    """The linked VPN account no longer exists in the panel -> unlink + prompt."""
    user_registry.remove(chat_id)
    _conv().clear(chat_id)
    txt = ("⚠️ اکانت شما دیگر در سیستم وجود ندارد یا حذف شده است.\n\n"
           "برای اتصال دوباره، <b>لینک اشتراک جدید</b> خود را ارسال کنید.")
    if mid is not None:
        _safe_edit(token, chat_id, mid, txt, None)
    else:
        _send(token, chat_id, txt)


def _is_not_found(err) -> bool:
    s = str(err)
    return "404" in s or "not_found" in s or "subscription_not_found" in s or "user_not_found" in s


# ---- routing --------------------------------------------------------------

def _route(token, cb_id, chat_id, mid, action, row):
    if action == "home":
        # BUGFIX (guaranteed response): same as the admin m:home — the
        # button must ALWAYS visibly respond. On any edit failure (including
        # "message is not modified") a fresh menu message is sent.
        _answer(token, cb_id)
        _conv().clear(chat_id)
        txt = "یکی از گزینه‌ها را انتخاب کنید:"
        if _safe_edit(token, chat_id, mid, txt, user_menu(has_account=bool(row))) == "same":
            _send(token, chat_id, txt, user_menu(has_account=bool(row)))
        return

    # ---- actions that don't need a linked account ----
    if action == "buy":
        _answer(token, cb_id)
        try:
            if row:
                _start_buy(token, chat_id, mid, row)
            else:
                _start_buy_no_account(token, chat_id, mid)
        except Exception as e:
            import traceback
            print(f"[BUY ERROR] {e}")
            traceback.print_exc()
            _send(token, chat_id, f"❌ خطا: {str(e)[:200]}")
        return

    if action == "buy_noacc":
        _answer(token, cb_id)
        _start_buy_no_account(token, chat_id, mid)
        return

    if action == "buy_plans":
        _answer(token, cb_id)
        admin = _get_admin_for_buy(token, chat_id)
        cfg = _shop_cfg(admin)
        _show_buy_plans(token, chat_id, mid, admin, cfg, [])
        return

    if action.startswith("buy_pkg:"):
        _answer(token, cb_id)
        pkg_id = int(action.split(":", 1)[1])
        _select_buy_pkg(token, chat_id, mid, pkg_id)
        return

    if action.startswith("buy_plan:"):
        _answer(token, cb_id)
        days = int(action.split(":", 1)[1])
        _select_buy_plan(token, chat_id, mid, days)
        return

    if action == "my_subs":
        _answer(token, cb_id)
        _show_my_subs(token, chat_id, mid)
        return

    if action == "reg_link":
        _answer(token, cb_id)
        _conv().set(chat_id, "uu_waiting_link", {})
        _safe_edit(token, chat_id, mid,
              "🔗 <b>ثبت لینک اشتراک</b>\n\n"
              "لطفاً لینک اشتراک خود را ارسال کنید.\n\n"
              "برای لغو، دکمه بازگشت را بزنید.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return

    # ---- everything below needs a linked account ----
    if not row:
        _answer(token, cb_id, "ابتدا لینک اشتراک خود را ارسال کنید.", alert=True)
        return

    sub = row["sub"]

    if action == "stats":
        _answer(token, cb_id, "در حال بروزرسانی...")
        try:
            acc = H["account_from_sub"](sub)
        except Exception as e:
            if _is_not_found(e):
                _account_missing(token, chat_id, mid)
            else:
                _safe_edit(token, chat_id, mid, "خطا در دریافت اطلاعات. بعداً تلاش کنید.",
                      _kb([[_btn("« بازگشت", "uu:home")]]))
            return
        _safe_edit(token, chat_id, mid, _fmt_account(acc),
              _kb([[_btn("🔄 بروزرسانی", "uu:stats")], [_btn("« بازگشت", "uu:home")]]))
        return

    if action == "sub":
        _answer(token, cb_id)
        _safe_edit(token, chat_id, mid,
              f"🔗 <b>لینک اشتراک شما</b>\n\n<code>{sub}</code>\n\n"
              "این لینک را در اپ خود وارد کنید.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return

    if action == "cfgs":
        _answer(token, cb_id, "در حال دریافت کانفیگ‌ها...")
        # first make sure the account still exists
        try:
            H["account_from_sub"](sub)
        except Exception as e:
            if _is_not_found(e):
                _account_missing(token, chat_id, mid)
                return
        try:
            cfgs = H["fetch_configs"](sub)
        except Exception:
            cfgs = []
        if not cfgs:
            _safe_edit(token, chat_id, mid, "کانفیگی یافت نشد.", _kb([[_btn("« بازگشت", "uu:home")]]))
            return
        # send each config as a separate copyable message
        _safe_edit(token, chat_id, mid, f"📱 <b>{len(cfgs)} کانفیگ</b> برای شما ارسال شد:",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        for name, uri in cfgs[:30]:
            _send(token, chat_id, f"<b>{name}</b>\n<code>{uri}</code>")
        return

    if action == "relink":
        _answer(token, cb_id)
        _conv().clear(chat_id)
        _safe_edit(token, chat_id, mid,
              "🔗 برای تغییر/اتصال دوباره، <b>لینک اشتراک جدید</b> خود را ارسال کنید.", None)
        return

    if action == "renew":
        _answer(token, cb_id)
        # verify the account still exists before offering renewal
        try:
            H["account_from_sub"](sub)
        except Exception as e:
            if _is_not_found(e):
                _account_missing(token, chat_id, mid)
                return
        _start_renew(token, chat_id, mid, row)
        return

    if action.startswith("plan:"):
        _answer(token, cb_id)
        days = int(action.split(":", 1)[1])
        _conv().set(chat_id, "uu_gb", {"sub": row["sub"], "username": row["username"], "days": days})
        cfg = _eff_cfg(row["username"])
        _safe_edit(token, chat_id, mid,
              f"📦 حجم موردنظر را به گیگابایت بفرستید (حداقل {cfg.get('minGB',10)}):",
              _kb([[_btn("« انصراف", "uu:home")]]))
        return

    if action == "ref":
        _answer(token, cb_id)
        _show_referral(token, chat_id, mid, row)
        return

    if action == "redeem":
        _answer(token, cb_id)
        _conv().set(chat_id, "uu_redeem", {"admin": _get_admin_for_buy(token, chat_id)})
        _safe_edit(token, chat_id, mid,
              "🎟 <b>کد تخفیف</b>\n\n"
              "کد تخفیف خود را وارد کنید:\n"
              "(مثلاً SALE20)",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return

    if action == "gift":
        _answer(token, cb_id)
        _conv().set(chat_id, "uu_gift", {"admin": _get_admin_for_buy(token, chat_id)})
        _safe_edit(token, chat_id, mid,
              "🎁 <b>کد هدیه اشتراک</b>\n\n"
              "کد هدیه خود را وارد کنید:\n"
              "(مثلاً FREE2024)\n\n"
              "با وارد کردن کد، یک اشتراک رایگان دریافت می‌کنید "
              "و به لیست اشتراک‌های شما اضافه می‌شود.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return

    if action == "trial":
        _answer(token, cb_id)
        _request_trial(token, chat_id, mid)
        return

    if action == "ref:add":
        _answer(token, cb_id)
        _conv().set(chat_id, "uu_ref", {"username": row["username"], "admin": row["admin_username"]})
        _send(token, chat_id, "👥 نام کاربری فردی که شما را معرفی کرده وارد کنید:")
        return

    _answer(token, cb_id)


# ---- renewal flow ---------------------------------------------------------

def _eff_cfg(username):
    admin = ""
    try:
        admin = H["admin_username_for"](username) or ""
    except Exception:
        pass
    cfg = H["effective_cfg"](admin)
    cfg["minGB"] = cfg.get("minGB", 10)
    return cfg


def _start_renew(token, chat_id, mid, row):
    cfg = _eff_cfg(row["username"])
    plans = cfg.get("plans") or sorted((cfg.get("prices") or {}).keys()) or [30, 60, 90]
    prices = cfg.get("prices") or {}
    rows = []
    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}
    for d in plans:
        pr = prices.get(d) or prices.get(str(d)) or 0
        rows.append([_btn(f"{label.get(d, f'{d} روز')} — {pr:,} ت/گیگ", f"uu:plan:{d}")])
    rows.append([_btn("« بازگشت", "uu:home")])
    disc = referrals.discount_percent_for(row["username"])
    extra = f"\n🎁 تخفیف فعال شما: {disc}%" if disc else ""
    _safe_edit(token, chat_id, mid, f"🔄 <b>تمدید اشتراک</b>\nپلن موردنظر را انتخاب کنید:{extra}", _kb(rows))


def _conv_input(token, chat_id, text, conv):
    state = conv["state"]
    data = conv["data"]

    # ---- waiting for subscription link (from reg_link button) ----
    if state == "uu_waiting_link":
        _conv().clear(chat_id)
        text = text.strip()
        if not text or "/sub/" not in text:
            _send(token, chat_id,
                  "❗️ لینک نامعتبر است.\n"
                  "لطفاً لینک اشتراک معتبر ارسال کنید.\n"
                  "(لینک باید شامل /sub/ باشد)",
                  _kb([[_btn("« بازگشت", "uu:home")]]))
            return
        _register_from_sub(token, chat_id, text)
        return

    if state == "uu_gb":
        try:
            gb = int(float(text.replace(",", "")))
        except ValueError:
            _send(token, chat_id, "❗️ یک عدد بفرستید.")
            return
        cfg = _eff_cfg(data["username"])
        min_gb = int(cfg.get("minGB", 10))
        if gb < min_gb:
            _send(token, chat_id, f"❗️ حداقل حجم {min_gb} گیگابایت است.")
            return
        prices = cfg.get("prices") or {}
        ppg = prices.get(data["days"]) or prices.get(str(data["days"])) or 0
        base = ppg * gb
        disc = referrals.discount_percent_for(data["username"])
        price = referrals.apply_discount(base, disc)
        data.update({"gb": gb, "price": price, "base": base, "discount": disc})
        _conv().set(chat_id, "uu_receipt", data)
        admin = data.get("admin") or ""
        # Check payment method
        if not cfg.get("pay_card_enabled", True):
            _send(token, chat_id, "❌ پرداخت کارت به کارت در حال حاضر غیرفعال است.\nلطفاً روش دیگری انتخاب کنید.", _kb([[_btn("« بازگشت", "uu:home")]]))
            return
        # Get random card from admin_cards table
        try:
            import shop as _sh
            random_card = _sh.get_random_card(admin)
        except Exception:
            random_card = None
        if not random_card:
            random_card = {"number": cfg.get("card_number",""), "holder": cfg.get("card_holder",""), "bank": cfg.get("card_bank","")}
        card = (f"💳 <b>پرداخت — کارت به کارت</b>\n\n"
                f"مبلغ قابل پرداخت: <b>{price:,} تومان</b>")
        if disc:
            card += f"\n(مبلغ اصلی {base:,} با {disc}% تخفیف)"
        card += (f"\n\n🏦 {random_card.get('bank','')}\n"
                 f"💳 <code>{random_card.get('number','')}</code>\n"
                 f"👤 {random_card.get('holder','')}\n\n"
                 "پس از واریز، <b>عکس رسید</b> را همینجا ارسال کنید.")
        _send(token, chat_id, card, _kb([[_btn("« انصراف", "uu:home")]]))
        return

    if state == "uu_ref":
        _conv().clear(chat_id)
        cfg = _eff_cfg(data["username"])
        if not cfg.get("referral_enabled"):
            _send(token, chat_id, "سیستم دعوت در حال حاضر غیرفعال است.")
            return
        pct = int(cfg.get("referral_percent", 0) or 0)
        ok, m = referrals.add_referral(data["username"], text.strip(),
                                       data.get("admin", ""), pct)
        _send(token, chat_id, m, user_menu())
        return

    # ---- redeem code (discount or gift) ----
    if state == "uu_redeem":
        _conv().clear(chat_id)
        code = text.strip().upper()
        admin = data.get("admin", "") or ""
        if not code:
            _send(token, chat_id, "❗️ کد را وارد کنید.")
            return
        _redeem_discount_code(token, chat_id, code, admin)
        return

    if state == "uu_gift":
        _conv().clear(chat_id)
        code = text.strip().upper()
        admin = data.get("admin", "") or ""
        if not code:
            _send(token, chat_id, "❗️ کد را وارد کنید.")
            return
        _redeem_gift_code(token, chat_id, code, admin, chat_id)
        return

    # ---- buy flow: GB input ----
    if state == "uu_buy_gb":
        try:
            gb = int(float(text.replace(",", "")))
        except ValueError:
            _send(token, chat_id, "❗️ یک عدد بفرستید.")
            return
        min_gb = int(data.get("min_gb", 10))
        max_gb = 1000
        if gb < min_gb:
            _send(token, chat_id, f"❗️ حداقل حجم {min_gb} گیگابایت است.")
            return
        if gb > max_gb:
            _send(token, chat_id, f"❗️ حداکثر حجم {max_gb} گیگابایت است.")
            return
        ppg = int(data.get("ppg", 0))
        price = ppg * gb
        data.update({"gb": gb, "price": price})
        _conv().set(chat_id, "uu_buy_receipt", data)
        admin = data.get("admin", "")
        cfg = _shop_cfg(admin)
        label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}
        plan_label = label.get(data["days"], str(data["days"]) + " روز")
        # Check payment method
        if not cfg.get("pay_card_enabled", True):
            _send(token, chat_id, "❌ پرداخت کارت به کارت در حال حاضر غیرفعال است.", _kb([[_btn("« بازگشت", "uu:home")]]))
            return
        # Get random card from admin_cards table
        try:
            import shop as _sh
            random_card = _sh.get_random_card(admin)
        except Exception:
            random_card = None
        if not random_card:
            random_card = {"number": cfg.get("card_number",""), "holder": cfg.get("card_holder",""), "bank": cfg.get("card_bank","")}
        card_txt = (
            f"💳 <b>پرداخت — کارت به کارت</b>\n\n"
            f"📦 پلن: {plan_label}\n"
            f"📊 حجم: {gb} گیگابایت\n"
            f"💰 مبلغ: <b>{price:,} تومان</b>\n\n"
            f"🏦 {random_card.get('bank', '')}\n"
            f"💳 <code>{random_card.get('number', '')}</code>\n"
            f"👤 {random_card.get('holder', '')}\n\n"
            "پس از واریز، <b>عکس رسید</b> را همینجا ارسال کنید."
        )
        _send(token, chat_id, card_txt, _kb([[_btn("« انصراف", "uu:home")]]))
        return


def _receipt_received(token, chat_id, data, photo):
    _conv().clear(chat_id)
    file_id = photo[-1]["file_id"]  # largest size
    username = data["username"]
    sub = data["sub"]
    days = data["days"]
    gb = data["gb"]
    price = data["price"]
    disc = data.get("discount", 0)
    admin = ""
    try:
        admin = H["admin_username_for"](username) or ""
    except Exception:
        pass
    cfg = H["effective_cfg"](admin)
    order_id = H["create_order"](username, sub, days, gb, price, admin, disc)
    sent = H["notify_admin_receipt"](order_id, username, days, gb, price, file_id, cfg, disc)
    if sent:
        _send(token, chat_id,
              "✅ رسید شما برای تایید ارسال شد.\n"
              "پس از تایید ادمین، اشتراک شما به‌صورت خودکار تمدید می‌شود.",
              user_menu())
    else:
        _send(token, chat_id, "❌ ارسال رسید ناموفق بود. با پشتیبانی تماس بگیرید.", user_menu())


# ---- referral (user view) -------------------------------------------------

def _show_referral(token, chat_id, mid, row):
    cfg = _eff_cfg(row["username"])
    if not cfg.get("referral_enabled"):
        _safe_edit(token, chat_id, mid, "🎁 سیستم دعوت در حال حاضر غیرفعال است.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return
    s = referrals.referral_summary(row["username"])
    txt = cfg.get("referral_text", "") + "\n\n"
    txt += f"👥 نام کاربری شما: <code>{row['username']}</code>\n"
    txt += "این نام کاربری را به دوستانتان بدهید تا هنگام ثبت‌نام وارد کنند.\n\n"
    if s["referrer"]:
        txt += f"معرف شما: {s['referrer']}\n"
    txt += f"تعداد دعوت‌های شما: {s['invited_count']}\n"
    if s["pending_percent"]:
        txt += f"🎁 تخفیف آماده‌ی استفاده: {s['pending_percent']}%"
    rows = []
    if not s["referrer"]:
        rows.append([_btn("➕ وارد کردن معرف", "uu:ref:add")])
    rows.append([_btn("« بازگشت", "uu:home")])
    _safe_edit(token, chat_id, mid, txt, _kb(rows))


# ==========================================================================
#  MY SUBSCRIPTIONS (show all purchased accounts from shop_vpn)
# ==========================================================================

def _show_my_subs(token, chat_id, mid):
    """Show all VPN accounts linked to this user (from shop purchases)."""
    admin = _get_admin_for_buy(token, chat_id)
    accounts = []
    try:
        import shop as _sh
        shop_username = f"tg_{chat_id}"
        with _sh._conn() as c:
            shop_user = c.execute(
                "SELECT id FROM shop_users WHERE admin_username=? AND username=?",
                (admin, shop_username)
            ).fetchone()
        if shop_user:
            links = _sh.list_vpn(shop_user["id"])
            for link in links:
                vpn_user = link.get("vpn_username", "")
                sub = link.get("sub", "")
                acc_info = None
                try:
                    cfg = _shop_cfg(admin)
                    api_key = cfg.get("api_key", "")
                    if api_key and vpn_user:
                        from panel_api import PanelAPI
                        api = PanelAPI(api_key)
                        user = api.get_user(vpn_user)
                        acc_info = _extract_shop_account(user)
                except Exception:
                    pass
                accounts.append({"username": vpn_user, "sub": sub, "info": acc_info})
    except Exception as e:
        print(f"[MY_SUBS] error: {e}")

    row = _find_user(chat_id)
    main_sub = ""
    main_username = ""
    if row:
        main_sub = row.get("sub", "")
        main_username = row.get("username", "")

    if not accounts and not main_sub:
        _safe_edit(token, chat_id, mid,
              "📋 <b>اشتراک‌های من</b>\n\n"
              "هنوز اشتراکی خریداری نکرده‌اید.\n"
              "برای خرید از دکمه «🛒 خرید اکانت جدید» استفاده کنید.",
              _kb([[_btn("🛒 خرید اکانت جدید", "uu:buy")],
                   [_btn("« بازگشت", "uu:home")]]))
        return

    txt = "📋 <b>اشتراک‌های من</b>\n\n"
    if main_sub:
        txt += f"🟢 <b>اکانت اصلی:</b> <code>{main_username}</code>\n"
        txt += f"🔗 <code>{main_sub}</code>\n\n"

    for i, acc in enumerate(accounts, 1):
        vpn_user = acc["username"]
        sub = acc["sub"]
        info = acc.get("info")
        txt += f"🔹 <b>اشتراک {i}:</b> <code>{vpn_user}</code>\n"
        if info:
            st_map = {"active": "🟢", "disabled": "🔴", "limited": "🟡", "expired": "🟠"}
            st = st_map.get(info.get("status", ""), "⚪")
            gb = 1024 ** 3
            used = info.get("used_traffic", 0) or 0
            total = info.get("data_limit", 0) or 0
            if total > 0:
                rem = max(0, total - used)
                txt += f"   {st} حجم: {rem/gb:.1f}/{total/gb:.1f} گیگ"
            exp = info.get("expire_epoch", 0) or 0
            if exp > 0:
                days = max(0, (exp - int(time.time())) // 86400)
                txt += f" | ⏳ {days} روز"
            txt += "\n"
        if sub:
            txt += f"   🔗 <code>{sub}</code>\n"
        txt += "\n"

    _safe_edit(token, chat_id, mid, txt, _kb([[_btn("« بازگشت", "uu:home")]]))


def _extract_shop_account(user: dict) -> dict:
    """Extract basic info from a panel user dict."""
    used = user.get("used_traffic", 0) or 0
    limit = user.get("data_limit", 0) or 0
    status = str(user.get("status", "")).lower()
    expire = user.get("expire", 0) or 0
    if isinstance(expire, str):
        try:
            from datetime import datetime
            expire = int(datetime.fromisoformat(expire.replace("Z", "+00:00")).timestamp())
        except Exception:
            expire = 0
    elif isinstance(expire, (int, float)) and expire > 10_000_000_000:
        expire = int(expire) // 1000
    return {
        "used_traffic": int(used),
        "data_limit": int(limit),
        "status": status,
        "expire_epoch": int(expire),
    }


# ==========================================================================
#  SHOP / BUY (user side — buy a new account from within the bot)
# ==========================================================================

# ---- Force channel membership -----------------------------------------------

# Confirmed force-join memberships: (chat_id, channel) -> epoch it expires at.
_member_cache: dict = {}
_member_cache_lock = threading.Lock()
_MEMBER_TTL = 600  # seconds


def _check_force_channel(token, chat_id, user_id):
    """Check if the user must join a channel. Returns True if blocked (not a member)."""
    # Determine which admin this user belongs to
    row = _find_user(chat_id)
    admin = ""
    if row:
        admin = row.get("admin_username", "") or ""
    if not admin:
        try:
            import bot as _b
            admin = _b._admin_username_for_token(token)
        except Exception:
            return False

    if not admin:
        return False

    cfg = _shop_cfg(admin)
    if not cfg.get("force_channel_enabled"):
        return False

    channel = cfg.get("force_channel", "")
    if not channel:
        return False

    # Check membership via Telegram API.
    # PERF FIX: this fired a getChatMember round trip on every /start and on
    # every sub-link message. Confirmed members are now cached for 10 minutes
    # (Telegram pushes no membership events to us, so a short TTL is the right
    # trade-off) — the check costs nothing for returning users.
    cached_until = _member_cache.get((str(chat_id), channel))
    if cached_until and cached_until > time.time():
        return False

    try:
        import bot as _b
        result = _b.tg("getChatMember", token, chat_id=channel, user_id=int(user_id))
        if result and result.get("ok"):
            status = result.get("result", {}).get("status", "")
            # member, administrator, creator = OK
            if status in ("member", "administrator", "creator"):
                with _member_cache_lock:
                    _member_cache[(str(chat_id), channel)] = time.time() + _MEMBER_TTL
                return False  # user is in the channel
    except Exception:
        return False  # if we can't check, let them through

    # User is NOT a member — show the forced join message
    _conv().clear(chat_id)
    invite_link = channel  # fallback
    if channel.startswith("@"):
        invite_link = f"https://t.me/{channel[1:]}"
    elif channel.startswith("-"):
        invite_link = channel  # can't create link for private without export

    msg = (
        "🔒 <b>عضویت اجباری</b>\n\n"
        "برای استفاده از ربات، ابتدا باید در کانال زیر عضو شوید:\n\n"
        f"📢 {channel}\n\n"
        "پس از عضویت، دکمه زیر را بزنید."
    )
    rows = []
    if channel.startswith("@") or channel.startswith("http"):
        rows.append([{"text": "📢 عضویت در کانال", "url": invite_link}])
    rows.append([_btn("✅ عضو شدم", "uu:join_check")])
    _send(token, chat_id, msg, _kb(rows))
    return True  # blocked


def _handle_join_check(token, chat_id, from_id, mid):
    """Handle the 'I joined' button — verify and show menu if OK."""
    row = _find_user(chat_id)
    admin = ""
    if row:
        admin = row.get("admin_username", "") or ""
    if not admin:
        try:
            import bot as _b
            admin = _b._admin_username_for_token(token)
        except Exception:
            pass

    cfg = _shop_cfg(admin) if admin else {}
    channel = cfg.get("force_channel", "")

    if channel:
        try:
            import bot as _b
            result = _b.tg("getChatMember", token, chat_id=channel, user_id=int(from_id))
            if result and result.get("ok"):
                status = result.get("result", {}).get("status", "")
                if status in ("member", "administrator", "creator"):
                    _safe_edit(token, chat_id, mid,
                          "✅ عضویت شما تایید شد!\n\nبه ربات <b>1PlusVPN</b> خوش آمدید. 🎉",
                          None)
                    import bot as _b
                    _b.send_kb(token, chat_id,
                               "👋 خوش آمدید!\n\nاز منوی زیر گزینه موردنظر را انتخاب کنید:",
                               _b.user_reply_kb())
                    _send(token, chat_id, "📋 <b>منوی اصلی</b>",
                          user_menu(has_account=bool(row)))
                    return
                else:
                    _send(token, chat_id, "❌ شما هنوز عضو کانال نشده‌اید.\nلطفاً ابتدا عضو شوید.")
                    return
        except Exception:
            pass

    # If we can't verify or channel is not set, let them through
    _safe_edit(token, chat_id, mid, "✅ خوش آمدید!", None)
    import bot as _b
    _b.send_kb(token, chat_id,
               "👋 خوش آمدید!\n\nاز منوی زیر گزینه موردنظر را انتخاب کنید:",
               _b.user_reply_kb())
    _send(token, chat_id, "📋 <b>منوی اصلی</b>",
          user_menu(has_account=bool(row)))

def _get_admin_for_buy(token, chat_id):
    """Determine which admin's shop to use for a purchase.
    If the user has a linked account, use that admin. Otherwise, use the
    admin that owns this bot (from the bot token)."""
    row = _find_user(chat_id)
    if row:
        return row.get("admin_username", "") or ""
    # no linked account — use the bot's owning admin
    try:
        return H["admin_username_for_token"](token)
    except Exception:
        return ""


def _shop_cfg(admin_username):
    """Get effective config for an admin (card, prices, shop_enabled, etc.)."""
    cfg = H["effective_cfg"](admin_username)
    cfg["minGB"] = int(cfg.get("minGB", cfg.get("warn_gb", 10)) or 10)
    cfg["maxGB"] = int(cfg.get("maxGB", 1000) or 1000)
    return cfg


def _start_buy(token, chat_id, mid, row):
    """Start the buy flow for a user with a linked account."""
    admin = row.get("admin_username", "") or ""
    try:
        admin = H["admin_username_for"](row["username"]) or admin
    except Exception:
        pass
    cfg = _shop_cfg(admin)
    if not cfg.get("shop_enabled"):
        _safe_edit(token, chat_id, mid,
              "🛒 <b>فروشگاه</b>\n\n"
              "خرید آنلاین در حال حاضر غیرفعال است.\n"
              "برای خرید با پشتیبانی تماس بگیرید.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return
    _show_buy_options(token, chat_id, mid, admin, cfg)


def _start_buy_no_account(token, chat_id, mid):
    """Start the buy flow for a user without a linked account."""
    admin = _get_admin_for_buy(token, chat_id)
    print(f"[BUY] _start_buy_no_account: chat_id={chat_id}, admin='{admin}'")
    cfg = _shop_cfg(admin)
    print(f"[BUY] shop_enabled={cfg.get('shop_enabled')}, prices={cfg.get('prices', {})}")
    if not cfg.get("shop_enabled"):
        print(f"[BUY] shop_enabled is False! Showing disabled message.")
        _safe_edit(token, chat_id, mid,
              "🛒 <b>فروشگاه</b>\n\n"
              "خرید آنلاین در حال حاضر غیرفعال است.\n"
              "برای خرید با پشتیبانی تماس بگیرید.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return
    _show_buy_options(token, chat_id, mid, admin, cfg)


def _show_buy_options(token, chat_id, mid, admin, cfg):
    """Show packages (if any) or plans for the user to buy."""
    # try to get packages for this admin
    packages = []
    try:
        packages = H["shop_list_packages"](admin, enabled_only=True)
    except Exception:
        pass

    if packages:
        rows = []
        for pk in packages:
            note = f" — {pk['note']}" if pk.get("note") else ""
            rows.append([_btn(f"🧩 {pk['name']}{note}", f"uu:buy_pkg:{pk['id']}")])
        rows.append([_btn("« بازگشت", "uu:home")])
        _safe_edit(token, chat_id, mid,
              "🛒 <b>خرید اکانت جدید</b>\n\n"
              "سرویس موردنظر خود را انتخاب کنید:",
              _kb(rows))
    else:
        # No packages — fall back to default plans (30/60/90 day)
        _show_buy_plans(token, chat_id, mid, admin, cfg, [])


def _select_buy_pkg(token, chat_id, mid, pkg_id):
    """User selected a package — show its plans."""
    admin = _get_admin_for_buy(token, chat_id)
    cfg = _shop_cfg(admin)
    try:
        pkg = H["shop_get_package"](pkg_id)
    except Exception:
        pkg = None
    if not pkg or not pkg.get("enabled"):
        _safe_edit(token, chat_id, mid, "❌ این پکیج دیگر موجود نیست.",
              _kb([[_btn("« بازگشت", "uu:buy")]]))
        return
    # build plan buttons from package prices
    prices = pkg.get("prices", {})
    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}
    rows = []
    for d in sorted(prices.keys(), key=lambda x: int(x)):
        d = int(d)
        pr = prices[d]
        rows.append([_btn(f"{label.get(d, f'{d} روز')} — {int(pr):,} ت/گیگ", f"uu:buy_plan:{d}")])
    rows.append([_btn("« بازگشت", "uu:buy")])
    _safe_edit(token, chat_id, mid,
          f"🧩 <b>{pkg['name']}</b>\n"
          f"📝 {pkg.get('note') or ''}\n\n"
          f"پلن موردنظر را انتخاب کنید:",
          _kb(rows))
    # store selected package in conversation
    _conv().set(chat_id, "uu_buy_pkg", {"pkg_id": pkg_id, "admin": admin})


def _select_buy_plan(token, chat_id, mid, days):
    """User selected a plan duration — ask for GB."""
    conv = _conv().get(chat_id)
    pkg_id = 0
    admin = _get_admin_for_buy(token, chat_id)
    if conv and conv["state"] == "uu_buy_pkg":
        pkg_id = conv["data"].get("pkg_id", 0)
        admin = conv["data"].get("admin", admin)

    cfg = _shop_cfg(admin)
    min_gb = cfg.get("minGB", 10)

    # determine price per GB
    if pkg_id:
        try:
            pkg = H["shop_get_package"](pkg_id)
            prices = pkg.get("prices", {}) if pkg else {}
        except Exception:
            prices = {}
        ppg = prices.get(days) or prices.get(str(days)) or 0
    else:
        prices = cfg.get("prices", {})
        ppg = prices.get(days) or prices.get(str(days)) or 0

    _conv().set(chat_id, "uu_buy_gb", {
        "admin": admin, "days": days, "ppg": int(ppg),
        "pkg_id": pkg_id, "min_gb": min_gb
    })
    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}
    _safe_edit(token, chat_id, mid,
          f"📦 <b>{label.get(days, f'{days} روز')}</b>\n"
          f"قیمت هر گیگ: <b>{int(ppg):,}</b> تومان\n\n"
          f"حجم موردنظر را به گیگابایت بفرستید (حداقل {min_gb}):",
          _kb([[_btn("« انصراف", "uu:home")]]))


def _show_buy_plans(token, chat_id, mid, admin, cfg, packages):
    """Show default plans (no packages)."""
    prices = cfg.get("prices", {}) or {}
    plans = cfg.get("plans") or sorted(int(k) for k in prices.keys()) or [30, 60, 90]
    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}
    rows = []
    for d in plans:
        d = int(d)
        pr = prices.get(d) or prices.get(str(d)) or 0
        rows.append([_btn(f"{label.get(d, f'{d} روز')} — {int(pr):,} ت/گیگ", f"uu:buy_plan:{d}")])
    rows.append([_btn("« بازگشت", "uu:home")])
    _safe_edit(token, chat_id, mid,
          "🛒 <b>خرید اکانت جدید</b>\n\nپلن موردنظر را انتخاب کنید:",
          _kb(rows))


# ==========================================================================
#  BUY RECEIPT (creates shop order + notifies admin)
# ==========================================================================

def _buy_receipt_received(token, chat_id, data, photo):
    """Handle a receipt photo for a buy order."""
    _conv().clear(chat_id)
    file_id = photo[-1]["file_id"]
    admin = data.get("admin", "")
    days = data["days"]
    gb = data["gb"]
    price = data["price"]
    pkg_id = data.get("pkg_id", 0)

    # create a shop account for this bot user if not exists
    shop_username = f"tg_{chat_id}"
    try:
        shop_user_id = H["shop_ensure_account"](admin, shop_username, str(chat_id))
    except Exception as e:
        _send(token, chat_id, f"❌ خطا: {str(e)[:120]}\nبا پشتیبانی تماس بگیرید.", user_menu())
        return

    # create the shop order
    try:
        order_id = H["shop_create_order"](
            shop_user_id, admin, "buy", days, gb, price,
            target_user="", service_id="", package_id=pkg_id
        )
    except Exception as e:
        _send(token, chat_id, f"❌ خطا در ثبت سفارش: {str(e)[:120]}", user_menu())
        return

    # send receipt to admin(s) via Telegram
    try:
        sent = H["shop_notify_receipt"](order_id, shop_user_id, admin, "buy",
                                        days, gb, price, file_id, pkg_id)
    except Exception:
        sent = False

    if sent:
        _send(token, chat_id,
              "✅ درخواست خرید شما ثبت شد.\n\n"
              f"📦 پلن: {days} روزه — {gb} گیگابایت\n"
              f"💰 مبلغ: {price:,} تومان\n"
              f"🆔 سفارش: #{order_id}\n\n"
              "پس از تایید ادمین، لینک اشتراک شما ارسال می‌شود. ⏳",
              user_menu(has_account=bool(_find_user(chat_id))))
    else:
        _send(token, chat_id, "❌ ارسال رسید ناموفق بود. با پشتیبانی تماس بگیرید.",
              user_menu(has_account=bool(_find_user(chat_id))))


# ==========================================================================
#  REDEEM CODE (discount or gift)
# ==========================================================================

def _redeem_discount_code(token, chat_id, code, admin):
    """Validate a discount code and show confirmation."""
    import shop as _sh
    try:
        info = _sh.validate_discount_code(admin, code)
        dtype = "درصد" if info["discount_type"] == "percent" else "تومان"
        _send(token, chat_id,
              f"✅ کد تخفیف معتبر است!\n\n"
              f"🎟 کد: <code>{code}</code>\n"
              f"💰 {info['discount_value']} {dtype} تخفیف\n\n"
              "این کد را هنگام خرید یا تمدید وارد کنید.",
              user_menu(has_account=bool(_find_user(chat_id))))
    except ValueError:
        _send(token, chat_id, "❌ کد تخفیف نامعتبر است یا قبلاً استفاده شده.",
              user_menu(has_account=bool(_find_user(chat_id))))


def _redeem_gift_code(token, chat_id, code, admin, user_chat_id):
    """Redeem a gift code — create account and link to shop user."""
    import shop as _sh

    try:
        gift = _sh.validate_gift_code(admin, code)
    except ValueError:
        _send(token, chat_id, "❌ کد هدیه نامعتبر است یا قبلاً استفاده شده.",
              user_menu(has_account=bool(_find_user(chat_id))))
        return

    # Create shop account for this user (if not exists)
    shop_username = f"tg_{user_chat_id}"
    try:
        shop_user_id = H["shop_ensure_account"](admin, shop_username, str(user_chat_id))
    except Exception as e:
        _send(token, chat_id, f"❌ خطا: {str(e)[:120]}")
        return

    # Create VPN account
    cfg = _shop_cfg(admin)
    api_key = cfg.get("api_key", "")
    if not api_key:
        _send(token, chat_id, "❌ خطا: کلید API ادمین تنظیم نشده.")
        return

    from panel_api import PanelAPI
    api = PanelAPI(api_key)
    prefix = cfg.get("shop_prefix", "ST")
    username = _sh.next_username(api, prefix)
    now = int(time.time())

    # Get service_id
    services = api.list_services()
    service_id = None
    if services and len(services) > 0:
        service_id = services[0].get("id") or services[0].get("service_id")

    payload = {
        "username": username,
        "data_limit": gift["gb"] * 1024 * 1024 * 1024 if gift["gb"] > 0 else 0,
        "expire": now + gift["plan_days"] * 86400,
        "status": "active",
    }
    if service_id:
        try:
            sid_int = int(service_id)
        except (TypeError, ValueError):
            sid_int = service_id
        payload["service_ids"] = [sid_int]
        payload["service_id"] = sid_int

    try:
        api.create_user_v2(payload)
    except Exception:
        api.create_user(payload)

    # Mark gift code as used
    _sh.use_gift_code(code)

    # Get subscription link
    user = api.get_user(username)
    sub = user.get("subscription_url") or user.get("sub") or ""

    # Link to shop user account
    try:
        _sh.link_vpn(shop_user_id, username, sub)
    except Exception:
        pass

    # Auto-register user in user_registry so menus appear
    if sub:
        existing = user_registry.get_user_by_chat(str(chat_id))
        if not existing:
            user_registry.register(chat_id, username, admin, sub)
            _invalidate_user_cache(chat_id)

    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}.get(gift["plan_days"], f"{gift['plan_days']} روز")
    _send(token, chat_id,
          f"🎁 <b>کد هدیه با موفقیت استفاده شد!</b>\n\n"
          f"👤 نام اکانت: <code>{username}</code>\n"
          f"📦 پلن: {label} | {gift['gb']} گیگابایت\n\n"
          f"🔗 <b>لینک اشتراک:</b>\n<code>{sub}</code>\n\n"
          "این اشتراک به لیست اشتراک‌های شما اضافه شد.\n"
          "از بخش «اشتراک‌های من» قابل دسترسی است.",
          user_menu(has_account=bool(_find_user(chat_id))))


# ==========================================================================
#  TRIAL ACCOUNT
# ==========================================================================

def _has_used_trial(admin, chat_id):
    """Check if user has already used trial."""
    try:
        import shop as _sh
        return _sh.has_used_trial(admin, int(chat_id))
    except Exception:
        return False


def _request_trial(token, chat_id, mid):
    """Handle trial account request."""
    admin = _get_admin_for_buy(token, chat_id)
    cfg = _shop_cfg(admin)

    if not cfg.get("trial_enabled"):
        _safe_edit(token, chat_id, mid, "🎮 اکانت تست در حال حاضر غیرفعال است.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return

    if _has_used_trial(admin, chat_id):
        _safe_edit(token, chat_id, mid,
              "⚠️ شما قبلاً از اکانت تست استفاده کرده‌اید.",
              _kb([[_btn("🛒 خرید اکانت", "uu:buy")],
                   [_btn("« بازگشت", "uu:home")]]))
        return

    # Check if user has a linked sub link
    row = _find_user(chat_id)
    if not row:
        _safe_edit(token, chat_id, mid,
              "🎮 <b>دریافت اکانت آزمایشی</b>\n\n"
              f"📦 حجم: {cfg.get('trial_data_mb', 100)} مگابایت\n"
              f"⏰ زمان: {cfg.get('trial_hours', 24)} ساعت\n\n"
              "برای دریافت اکانت تست، ابتدا <b>لینک اشتراک</b> خود را ارسال کنید.",
              _kb([[_btn("« بازگشت", "uu:home")]]))
        return

    # Create trial account
    try:
        import shop as _sh
        api_key = cfg.get("api_key", "")
        if not api_key:
            _safe_edit(token, chat_id, mid, "❌ خطا: کلید API تنظیم نشده.",
                  _kb([[_btn("« بازگشت", "uu:home")]]))
            return
        from panel_api import PanelAPI
        api = PanelAPI(api_key)
        prefix = cfg.get("shop_prefix", "TR")
        trial_username = _sh.next_username(api, prefix)
        data_mb = int(cfg.get("trial_data_mb", 100))
        hours = int(cfg.get("trial_hours", 24))
        now = int(time.time())
        payload = {
            "username": trial_username,
            "data_limit": data_mb * 1024 * 1024,
            "expire": now + hours * 3600,
            "status": "active",
        }
        try:
            api.create_user_v2(payload)
        except Exception:
            api.create_user(payload)
        _sh.record_trial_usage(admin, int(chat_id), trial_username)
        user = api.get_user(trial_username)
        sub = user.get("subscription_url") or user.get("sub") or ""
        _safe_edit(token, chat_id, mid,
              f"🎮 <b>اکانت آزمایشی شما ساخته شد!</b>\n\n"
              f"👤 نام: <code>{trial_username}</code>\n"
              f"📦 حجم: {data_mb} مگابایت\n"
              f"⏰ زمان: {hours} ساعت\n\n"
              f"🔗 <b>لینک اشتراک:</b>\n<code>{sub}</code>\n\n"
              "این لینک را در اپ VPN خود وارد کنید.",
              _kb([[_btn("📋 منوی اصلی", "uu:home")]]))
    except Exception as e:
        _safe_edit(token, chat_id, mid, f"❌ خطا: {str(e)[:150]}",
              _kb([[_btn("« بازگشت", "uu:home")]]))
