"""
bot_settings.py — per-admin, bot-editable settings shared by the bot AND the
renewal page.
=======================================================================

Precedence when reading a setting for an admin:
    1. value saved in SQLite via the bot   (highest — admin edited it in Telegram)
    2. value in admins.json                 (file override)
    3. .env default                         (lowest)

So when an admin changes the card number / prices / warning texts from inside
the bot, it is stored here and instantly reflected in BOTH the bot and the
public /renew page (which reads through get_effective_config()).

Stored settings (per admin_username):
    card_number, card_holder, card_bank
    prices           -> {days: toman_per_gb}
    plans            -> [30,60,90]  (list of selectable durations)
    warn_days_text   -> low-time warning message
    warn_gb_text     -> low-data warning message
    warn_days        -> threshold (days left) to fire the time warning   (default 1)
    warn_gb          -> threshold (GB left) to fire the data warning      (default 1)
    referral_enabled -> "1"/"0"
    referral_percent -> int (discount %)
    referral_text    -> message shown in the referral section
"""
from __future__ import annotations

import json
import sqlite3

import dbx
import threading
from contextlib import contextmanager
from typing import Any, Optional

_lock = threading.Lock()
_DB_PATH = None  # set by init()


def _to_int(v, default=0) -> int:
    """Robustly coerce any stored value (e.g. '1', '1.0', 1.0) to int."""
    if v is None or v == "":
        return default
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def _to_float(v, default=0.0) -> float:
    if v is None or v == "":
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def init(db_path: str) -> None:
    global _DB_PATH
    _DB_PATH = db_path
    with _conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS admin_settings (
                admin_username TEXT NOT NULL,
                key            TEXT NOT NULL,
                value          TEXT,
                PRIMARY KEY (admin_username, key)
            )
            """
        )


@contextmanager
def _conn():
    """
    PERF FIX: was `sqlite3.connect()` inside a process-wide `threading.Lock()`
    on every single call — see dbx.py for the full explanation. Now it hands
    back this thread's cached WAL connection, so reads run in parallel and
    writes autocommit with a real busy_timeout instead of raising
    "database is locked".
    """
    yield dbx.get(_DB_PATH)


def set_setting(admin_username: str, key: str, value: Any) -> None:
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    else:
        value = str(value)
    with _conn() as c:
        c.execute(
            """INSERT INTO admin_settings (admin_username, key, value)
               VALUES (?,?,?)
               ON CONFLICT(admin_username, key) DO UPDATE SET value=excluded.value""",
            (admin_username, key, value),
        )
    invalidate_settings_cache(admin_username)


def get_setting(admin_username: str, key: str, default=None):
    """
    PERF FIX: every call was its own connect + lock + query + close. Screens
    like the settings menu, the shop menu and the trial menu read 6–12 settings
    each, so one menu render was a dozen serialised round trips to SQLite.
    It now reads through the same 30 s `all_settings` cache that
    `get_effective_config` already used, so a menu render is one query at most.
    """
    values = all_settings(admin_username)
    if key not in values:
        return default
    v = values[key]
    return default if v is None else v


def all_settings(admin_username: str) -> dict:
    """Get all settings for an admin with in-memory cache (TTL=30s)."""
    import time
    now = time.time()
    cache_key = admin_username or "__default__"
    if hasattr(all_settings, "_cache") and cache_key in all_settings._cache:
        cached, ts = all_settings._cache[cache_key]
        if now - ts < 30:
            return cached

    with _conn() as c:
        rows = c.execute(
            "SELECT key, value FROM admin_settings WHERE admin_username=?",
            (admin_username,),
        ).fetchall()
    out = {}
    for r in rows:
        v = r["value"]
        if v and v[0] in "[{":
            try:
                v = json.loads(v)
            except Exception:
                pass
        out[r["key"]] = v

    if not hasattr(all_settings, "_cache"):
        all_settings._cache = {}
    all_settings._cache[cache_key] = (out, now)
    return out


def invalidate_settings_cache(admin_username: str = None):
    """Clear settings cache. Call after set_setting()."""
    if not hasattr(all_settings, "_cache"):
        return
    if admin_username:
        all_settings._cache.pop(admin_username or "__default__", None)
        all_settings._cache.pop("", None)
    else:
        all_settings._cache.clear()


# ---- default warning / referral texts -----------------------------------

DEFAULT_WARN_DAYS_TEXT = (
    "⏰ کاربر گرامی، تنها {days} روز تا پایان اشتراک شما باقی مانده است.\n"
    "برای جلوگیری از قطعی، همین حالا از طریق همین ربات تمدید کنید."
)
DEFAULT_WARN_GB_TEXT = (
    "📉 کاربر گرامی، تنها {gb} گیگابایت از حجم اشتراک شما باقی مانده است.\n"
    "برای ادامه‌ی استفاده، از طریق همین ربات تمدید کنید."
)
DEFAULT_REFERRAL_TEXT = (
    "🎁 با معرفی دوستان خود تخفیف بگیرید!\n"
    "اگر کسی شما را معرفی کرده، نام کاربری او را وارد کنید تا تخفیف برای شما اعمال شود."
)


def get_effective_config(admin_username: str, base_cfg: dict) -> dict:
    """
    Merge bot-saved settings OVER the file/.env base config (base_cfg comes from
    _resolve_admin_cfg in app.py). Returns a dict the renew page and bot both use.
    """
    cfg = dict(base_cfg)
    s = all_settings(admin_username)

    for k in ("card_number", "card_holder", "card_bank"):
        if s.get(k):
            cfg[k] = s[k]

    if isinstance(s.get("prices"), dict) and s["prices"]:
        cfg["prices"] = {int(kk): int(vv) for kk, vv in s["prices"].items()}

    if isinstance(s.get("plans"), list) and s["plans"]:
        cfg["plans"] = [int(x) for x in s["plans"]]
    else:
        cfg.setdefault("plans", sorted(cfg.get("prices", {}).keys()) or [30, 60, 90])

    cfg["warn_days"] = _to_int(s.get("warn_days"), 1)
    cfg["warn_gb"] = _to_float(s.get("warn_gb"), 1)
    cfg["warn_days_text"] = s.get("warn_days_text") or DEFAULT_WARN_DAYS_TEXT
    cfg["warn_gb_text"] = s.get("warn_gb_text") or DEFAULT_WARN_GB_TEXT

    cfg["referral_enabled"] = str(s.get("referral_enabled", "0")) == "1"
    cfg["referral_percent"] = _to_int(s.get("referral_percent"), 0)
    cfg["referral_text"] = s.get("referral_text") or DEFAULT_REFERRAL_TEXT

    # shop / purchase portal
    cfg["shop_enabled"] = str(s.get("shop_enabled", "1")) == "1"
    cfg["shop_prefix"] = (s.get("shop_prefix") or "ST").strip()

    # min/max GB for purchases
    cfg["minGB"] = _to_int(s.get("minGB"), 1)
    cfg["maxGB"] = _to_int(s.get("maxGB"), 1000)

    # renewal section on the subscription frontend page
    cfg["renewal_enabled"] = str(s.get("renewal_enabled", "1")) == "1"

    # force channel membership for bot users
    cfg["force_channel"] = s.get("force_channel") or ""
    cfg["force_channel_enabled"] = str(s.get("force_channel_enabled", "0")) == "1"

    # trial account settings
    cfg["trial_enabled"] = str(s.get("trial_enabled", "0")) == "1"
    cfg["trial_data_mb"] = _to_int(s.get("trial_data_mb"), 100)
    cfg["trial_hours"] = _to_int(s.get("trial_hours"), 24)
    cfg["trial_max_per_user"] = _to_int(s.get("trial_max_per_user"), 1)
    cfg["trial_text"] = s.get("trial_text") or (
        "🎁 <b>اکانت آزمایشی رایگان!</b>\n\n"
        "می‌توانید یک اکانت تست رایگان دریافت کنید.\n"
        "این اکانت محدود است و برای تست کیفیت سرویس طراحی شده."
    )

    # payment methods
    cfg["pay_card_enabled"] = str(s.get("pay_card_enabled", "1")) == "1"
    cfg["pay_rial_gateway_enabled"] = str(s.get("pay_rial_gateway_enabled", "0")) == "1"
    cfg["pay_crypto_gateway_enabled"] = str(s.get("pay_crypto_gateway_enabled", "0")) == "1"

    # bot web app themes (separate for admin and user menus)
    cfg["admin_bot_theme"] = s.get("admin_bot_theme") or "gradient"
    cfg["user_bot_theme"] = s.get("user_bot_theme") or "gradient"

    # shop domain for Web App URLs (must be HTTPS)
    cfg["shop_domain"] = s.get("shop_domain") or ""

    # backup settings
    cfg["backup_auto_enabled"] = str(s.get("backup_auto_enabled", "0")) == "1"
    cfg["backup_interval_hours"] = _to_int(s.get("backup_interval_hours"), 24)

    # referral reward settings
    cfg["referral_reward_type"] = s.get("referral_reward_type") or "wallet"  # wallet | code
    cfg["referral_reward_value"] = _to_int(s.get("referral_reward_value"), 5000)
    cfg["referral_reward_percent"] = _to_int(s.get("referral_reward_percent"), 10)
    cfg["referral_code_prefix"] = s.get("referral_code_prefix") or "REF"
    cfg["referral_reward_text"] = s.get("referral_reward_text") or (
        "🎉 تبریک! یکی از دوستان شما خرید انجام داد.\n"
        "کد تخفیف شما: <code>{code}</code>\n"
        "در خرید بعدی از این کد استفاده کنید."
    )
    cfg["referral_wallet_text"] = s.get("referral_wallet_text") or (
        "🎉 تبریک! یکی از دوستان شما خرید انجام داد.\n"
        "{amount:,} تومان به کیف پول شما اضافه شد."
    )

    return cfg
