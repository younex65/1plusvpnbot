"""Persistent per-recipient backup schedule; independent of sudo backups."""
import time

import dbx


def init(path):
    dbx.get(path).execute('''CREATE TABLE IF NOT EXISTS admin_backup_schedule (
        admin TEXT NOT NULL, chat_id TEXT NOT NULL, seconds INTEGER NOT NULL,
        next_at INTEGER NOT NULL, PRIMARY KEY(admin, chat_id))''')


def reset(path, admin):
    with dbx.write(path) as db:
        db.execute('DELETE FROM admin_backup_schedule WHERE admin=?', (admin,))


def tick(path, jobs, create, send, *, now=None, report=lambda *a: None):
    """jobs: {admin: (interval seconds, token, [private chat ids])}."""
    now = int(time.time()) if now is None else now
    wanted = {(admin, cid): seconds for admin, (seconds, _, ids) in jobs.items() for cid in ids}
    due = {}
    with dbx.write(path) as db:
        previous = {(r['admin'], r['chat_id']): (r['seconds'], r['next_at']) for r in
                    db.execute('SELECT * FROM admin_backup_schedule')}
        for admin, cid in previous.keys() - wanted.keys():
            db.execute('DELETE FROM admin_backup_schedule WHERE admin=? AND chat_id=?', (admin, cid))
        for (admin, cid), seconds in wanted.items():
            old_seconds, next_at = previous.get((admin, cid), (None, None))
            if old_seconds != seconds:
                db.execute('INSERT OR REPLACE INTO admin_backup_schedule VALUES (?,?,?,?)',
                           (admin, cid, seconds, now + seconds))
            elif next_at <= now:
                # Claim before sending, use a short retry deadline on failure.
                db.execute('UPDATE admin_backup_schedule SET next_at=? WHERE admin=? AND chat_id=?',
                           (now + 300, admin, cid))
                due.setdefault(admin, []).append(cid)

    for admin, ids in due.items():
        seconds, token, _ = jobs[admin]
        try:
            content = create(admin)
        except Exception as e:
            report(admin, 'build', type(e).__name__)
            continue
        for cid in ids:
            try:
                ok = send(token, cid, admin, content)
            except Exception:
                ok = False
            if ok:
                with dbx.write(path) as db:
                    db.execute('''UPDATE admin_backup_schedule SET next_at=?
                        WHERE admin=? AND chat_id=? AND seconds=? AND next_at=?''',
                               (now + seconds, admin, cid, seconds, now + 300))
            else:
                report(admin, 'send', 'telegram_delivery_failed')
