"""Shared admins.json storage for the backend and the 8088 web panel."""
import fcntl
import hashlib
import json
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path


class Conflict(ValueError):
    pass


def snapshot(path):
    try:
        raw = Path(path).read_bytes()
    except FileNotFoundError:
        raw = b'{}'
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError('invalid_admins_json')
    return data, hashlib.sha256(raw).hexdigest()


@contextmanager
def _locked(path):
    with open(f'{path}.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        yield


def _write(path, data):
    path = Path(path)
    old = path.stat() if path.exists() else None
    fd, temp = tempfile.mkstemp(prefix='.admins-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            # Preserve ownership when the root web service writes for a non-root bot.
            if old and (old.st_uid, old.st_gid) != (os.geteuid(), os.getegid()):
                os.fchown(f.fileno(), old.st_uid, old.st_gid)
            os.fchmod(f.fileno(), 0o600)
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        Path(temp).unlink(missing_ok=True)


def entries(data):
    return ((name, cfg) for name, cfg in data.items()
            if name and not name.startswith('_') and isinstance(cfg, dict))


def add(path, name, cfg, *, default_token='', default_key=''):
    with _locked(path):
        data, _ = snapshot(path)
        if any(n.casefold() == name.casefold() for n in data):
            raise Conflict('duplicate_admin')
        if cfg['bot_token'] == default_token or any(
                str(old.get('bot_token') or '').strip() == cfg['bot_token'] for _, old in entries(data)):
            raise Conflict('duplicate_bot_token')
        if cfg['api_key'] == default_key or any(
                str(old.get('api_key') or '').strip() == cfg['api_key'] for _, old in entries(data)):
            raise Conflict('duplicate_api_key')
        data[name] = cfg
        _write(path, data)


def replace(path, data, revision):
    with _locked(path):
        _, current = snapshot(path)
        if revision != current:
            raise Conflict('admins_changed')
        _write(path, data)
        return snapshot(path)[1]
