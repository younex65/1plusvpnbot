"""
bot.py — 1PlusVPN full management bot (multi-admin).
====================================================

This module turns the Telegram bot from a simple approve/reject tool into a
full management panel INSIDE Telegram. Phase 1 = ADMIN side.

Design
------
* One long-polling thread per distinct bot token (started from app.py).
* Each panel admin uses their OWN api key (admins.json -> "api_key"), so the
  bot only ever sees / touches that admin's users.  -> real isolation.
* A tiny in-memory conversation state machine (admin flow scoped per bot/chat/sender) drives multi-step
  flows like "search user", "reset data -> how many GB?", "create user", etc.
* All bot-editable settings (card, prices, plans, warning texts, referral) are
  stored via bot_settings.py and are shared with the /renew page.

app.py wires the callbacks: it passes helper functions in via configure().
"""
from __future__ import annotations

import json
import math
from contextlib import contextmanager
from contextvars import ContextVar
from html import escape
import os
import re
import time
import threading
from typing import Callable, Optional
from urllib.parse import quote, urlencode, urlsplit

import httpx

import tg_client
from panel_api import PanelAPI, PanelError, bytes_to_gb, to_bytes_gb, user_field, now_epoch
import bot_settings as settings

_TG_API = "https://api.telegram.org/bot{token}/{method}"

# ---- injected from app.py via configure() --------------------------------
_resolve_admin_cfg: Callable[[str], dict] = lambda a: {}
_admin_username_for_token: Callable[[str], str] = lambda t: ""   # token -> admin_username
_sales_stats: Callable[[str], dict] = lambda a: {}
_list_orders: Callable[[str, int], list] = lambda a, n: []
_is_sudo: Callable[[str, object], bool] = lambda t, i: False
_make_backup: Callable[[], bytes] = lambda: b""
_restore_backup: Callable[[bytes], dict] = lambda b: {}
_send_document: Callable = lambda *a, **k: False
_download_file: Callable[[str, str], object] = lambda t, f: None
_subscription_base_url = ""
_can_add_admin = lambda token, sender: False
_add_admin = lambda *args: "ثبت ادمین فعال نیست."
_reset_backup_schedule = lambda admin: None


def configure(*, resolve_admin_cfg, admin_username_for_token, sales_stats, list_orders,
              is_sudo=None, make_backup=None, restore_backup=None,
              send_document=None, download_file=None, subscription_base_url="",
              can_add_admin=None, add_admin=None, reset_backup_schedule=None):
    global _resolve_admin_cfg, _admin_username_for_token, _sales_stats, _list_orders
    global _is_sudo, _make_backup, _restore_backup, _send_document, _download_file
    global _subscription_base_url, _can_add_admin, _add_admin, _reset_backup_schedule
    if can_add_admin is not None:
        _can_add_admin = can_add_admin
    if add_admin is not None:
        _add_admin = add_admin
    if reset_backup_schedule is not None:
        _reset_backup_schedule = reset_backup_schedule
    _subscription_base_url = subscription_base_url.rstrip("/")
    _resolve_admin_cfg = resolve_admin_cfg
    _admin_username_for_token = admin_username_for_token
    _sales_stats = sales_stats
    _list_orders = list_orders
    if is_sudo:
        _is_sudo = is_sudo
    if make_backup:
        _make_backup = make_backup
    if restore_backup:
        _restore_backup = restore_backup
    if send_document:
        _send_document = send_document
    if download_file:
        _download_file = download_file


# ---- low-level telegram --------------------------------------------------

def tg(method: str, token: str, **kw):
    """
    PERF FIX — THE BIG ONE.

    This used to be:

        with httpx.Client(timeout=30.0) as c:
            r = c.post(url, json=kw)

    i.e. a fresh TCP connection + TLS handshake to api.telegram.org for EVERY
    call, then immediately discarded. A single button tap costs 2–3 calls
    (answerCallbackQuery + editMessageText + sendChatAction), so users paid
    1.5–4 seconds of pure handshake latency per tap.

    It now goes through tg_client, which keeps one warm keep-alive pool per
    bot token and also handles 429 flood control and transient retries.
    """
    files = kw.pop("_files", None)
    return tg_client.call(method, token, _files=files, **kw)


def send(token, chat_id, text, kb=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode,
               "disable_web_page_preview": True}
    if kb is not None:
        payload["reply_markup"] = json.dumps(kb)
    return tg("sendMessage", token, **payload)


def edit(token, chat_id, message_id, text, kb=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "message_id": message_id, "text": text,
               "parse_mode": parse_mode, "disable_web_page_preview": True}
    if kb is not None:
        payload["reply_markup"] = json.dumps(kb)
    return tg("editMessageText", token, **payload)


def safe_edit(token, chat_id, message_id, text, kb=None, parse_mode="HTML"):
    """
    edit() with a guaranteed outcome.

    BUGFIX (دکمه‌های «بازگشت / منوی اصلی» در بعضی بخش‌ها ساکت می‌مردند):
    Telegram — و به‌ویژه هنگام زدن سریع دکمه‌ها (429 flood limit) — ویرایش را
    بدون استثنا رد می‌کند و tg_client به‌جای raise، None یا dict با ok=False
    برمی‌گرداند. نتیجه: دکمه «خاموش» می‌شد؛ نه منو، نه خطا. safe_edit() در
    این حالت همان صفحه را به‌صورت پیام جدید می‌فرستد.

    Returns:
      "edited" — the message was edited in place
      "sent"   — edit failed or no message context; screen re-sent as a new message
      "same"   — Telegram answered "message is not modified": the target screen
                 is already on display. Callers that must show a visible
                 confirmation (the main-menu buttons) re-send; plain
                 navigation no-ops (the user is already where they went).
    """
    if chat_id is None or message_id is None:
        send(token, chat_id, text, kb, parse_mode)
        return "sent"
    r = edit(token, chat_id, message_id, text, kb, parse_mode)
    if isinstance(r, dict) and r.get("ok"):
        return "edited"
    if isinstance(r, dict) and "not modified" in str(r.get("description", "")):
        return "same"
    send(token, chat_id, text, kb, parse_mode)
    return "sent"


def answer(token, cb_id, text="", alert=False):
    tg("answerCallbackQuery", token, callback_query_id=cb_id, text=text, show_alert=alert)


def typing(token, chat_id):
    """Show the 'typing...' status so slow operations feel responsive."""
    try:
        tg("sendChatAction", token, chat_id=chat_id, action="typing")
    except Exception:
        pass


# ---- keyboards -----------------------------------------------------------

def kb(rows):
    return {"inline_keyboard": rows}


def btn(text, data):
    return {"text": text, "callback_data": data}


def send_kb(token, chat_id, text, reply_kb, parse_mode="HTML"):
    """Send a message with a persistent (reply) keyboard shown under the input."""
    payload = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode,
               "disable_web_page_preview": True,
               "reply_markup": json.dumps(reply_kb)}
    return tg("sendMessage", token, **payload)


def admin_reply_kb():
    """Persistent bottom keyboard for admins — simple shortcuts only."""
    return {
        "keyboard": [
            [{"text": "🏠 منوی اصلی"}, {"text": "👥 کاربران"}],
            [{"text": "📊 آمار"}, {"text": "🛠 تنظیمات"}],
        ],
        "resize_keyboard": True,
        "is_persistent": True,
    }


def user_reply_kb():
    """Persistent bottom keyboard for customers — minimal."""
    return {
        "keyboard": [
            [{"text": "🏠 منوی اصلی"}],
        ],
        "resize_keyboard": True,
        "is_persistent": True,
    }


_commands_set: set = set()
_commands_lock = threading.Lock()


def set_bot_commands(token, is_user=False):
    """Register the ☰ command menu next to the input box.

    PERF FIX: this fired a `setMyCommands` API call on EVERY /start. The
    command list is global per bot and never changes at runtime, so it was one
    guaranteed extra Telegram round trip (previously a full TLS handshake)
    added to the latency of every single /start. Now sent once per token
    per process.
    """
    key = (token, bool(is_user))
    with _commands_lock:
        if key in _commands_set:
            return
        _commands_set.add(key)

    if is_user:
        cmds = [
            {"command": "start", "description": "منوی اصلی"},
            {"command": "stats", "description": "آمار اکانت"},
            {"command": "renew", "description": "تمدید اشتراک"},
            {"command": "configs", "description": "دریافت کانفیگ‌ها"},
        ]
    else:
        cmds = [
            {"command": "start", "description": "منوی اصلی"},
            {"command": "users", "description": "مدیریت کاربران"},
            {"command": "create", "description": "ساخت کاربر"},
            {"command": "stats", "description": "آمار"},
            {"command": "settings", "description": "تنظیمات"},
            {"command": "backup", "description": "بکاپ و بازیابی (سودو)"},
        ]
    tg("setMyCommands", token, commands=json.dumps(cmds))


def main_menu(is_sudo=False, shop_enabled=False):
    """Inline keyboard for admin users — organized by category."""
    rows = [
        [btn("👥 کاربران", "m:users"), btn("➕ ساخت کاربر", "m:create")],
        [btn("📊 آمار", "m:stats"), btn("📢 پیام همگانی", "m:broadcast")],
        [btn("⚙️ عملیات دسته‌جمعی", "m:bulk")],
    ]
    if shop_enabled:
        rows.append([btn("🛍 فروشگاه", "m:shop")])
    rows.extend([
        [btn("🎟 کد تخفیف", "m:discounts"), btn("🎁 هدیه اشتراک", "m:gifts")],
        [btn("🎮 اکانت تست", "m:trial"), btn("💰 پاداش رفرال", "m:ref_reward")],
        [btn("💳 روش‌های پرداخت", "m:pay_methods")],
        [btn("💾 بکاپ/بازیابی", "m:backup"), btn("🎁 دعوت دوستان", "m:ref")],
        [btn(" مدیریت کاربران بات", "m:bot_users"), btn("🛠 تنظیمات", "m:settings")],
    ])
    if is_sudo:
        rows.append([btn("🔧 تنظیمات سیستم", "m:sys_settings")])
    return kb(rows)

def _admin_home_keyboard(admin_username, cfg, is_sudo, *, private):
    """Return the normal menu and an optional private-chat Web App variant."""
    plain = main_menu(is_sudo, cfg.get("shop_enabled", False))
    domain = cfg.get("shop_domain")
    if not private or not admin_username or not isinstance(domain, str):
        return plain, None
    domain = domain.strip().rstrip("/")
    if any(c.isspace() or c == "\\" for c in domain):
        return plain, None
    try:
        base = urlsplit(domain)
        if (base.scheme != "https" or not base.hostname or base.username is not None
                or base.query or base.fragment):
            return plain, None
        _ = base.port  # Invalid port syntax also makes this unsuitable for Telegram.
    except ValueError:
        return plain, None
    theme = urlencode({"theme": cfg.get("admin_bot_theme") or "gradient"})
    url = f"{domain}/webapp/{quote(admin_username, safe='')}/admin?{theme}"
    web_app = {"text": "🎨 منوی گرافیکی", "web_app": {"url": url}}
    return plain, kb(plain["inline_keyboard"] + [[web_app]])


def _show_admin_home(token, chat_id, message_id, from_id, admin_username, cfg):
    txt = "🛠 <b>پنل مدیریت 1PlusVPN</b>\nیکی از گزینه‌ها را انتخاب کنید:"
    plain, enhanced = _admin_home_keyboard(admin_username, cfg, _is_sudo(token, from_id),
                                          private=str(chat_id) == from_id)
    # Telegram may reject even a syntactically valid Web App button. Never
    # reuse that markup in the fallback message, or both attempts can fail.
    if enhanced is not None and message_id is not None:
        r = edit(token, chat_id, message_id, txt, enhanced)
        if isinstance(r, dict) and r.get("ok"):
            return
        if isinstance(r, dict) and "not modified" in str(r.get("description", "")):
            send(token, chat_id, txt, plain)
            return
    if safe_edit(token, chat_id, message_id, txt, plain) == "same":
        send(token, chat_id, txt, plain)


def back_btn(to="m:home"):
    """Bottom row: back to a page + always a shortcut to the home menu."""
    if to == "m:home":
        return [btn("🏠 منوی اصلی", "m:home")]
    return [btn("« بازگشت", to), btn("🏠 منوی اصلی", "m:home")]


# ---- conversation state (per chat) ---------------------------------------

class Conv:
    """In-memory conversation state; admin handlers bind their own scope."""
    def __init__(self):
        self._d: dict = {}
        self._lock = threading.Lock()
        self._scope = ContextVar("admin_conv_scope", default=None)

    @contextmanager
    def admin_scope(self, token, admin, from_id):
        reset = self._scope.set((token, admin, str(from_id)))
        try:
            yield
        finally:
            self._scope.reset(reset)

    def _key(self, chat_id):
        scope = self._scope.get()
        return (scope, chat_id) if scope is not None else chat_id

    def set(self, chat_id, state, data=None):
        with self._lock:
            self._d[self._key(chat_id)] = {"state": state, "data": data or {}}

    def get(self, chat_id):
        with self._lock:
            return self._d.get(self._key(chat_id))

    def clear(self, chat_id):
        with self._lock:
            self._d.pop(self._key(chat_id), None)


CONV = Conv()


# ---- context resolution --------------------------------------------------

def _ctx(token: str, from_id: str):
    """
    Resolve which panel admin this Telegram user is acting as, and build an
    authenticated PanelAPI with THAT admin's api key.
    Returns (admin_username, cfg, api) or (None, None, None) if not authorized.

    SECURITY FIX: the old check was

        allowed = [str(x) for x in cfg.get("admin_ids", [])]
        if allowed and str(from_id) not in allowed:
            return None, None, None

    — note the `allowed and`. If `TELEGRAM_ADMIN_IDS` was empty in .env and the
    admin had no `admin_ids` in admins.json (a very easy misconfiguration, and
    the default in config.example.env), the list was empty, the guard was
    skipped, and **every Telegram user who messaged the bot was handed the full
    admin panel** with the sudo API key — able to list, edit and delete every
    customer. It also meant real customers never reached the bot_user side, so
    the shop looked "broken".

    It now fails CLOSED: no configured admin ids => nobody is an admin.
    """
    admin_username = _admin_username_for_token(token)
    cfg = _resolve_admin_cfg(admin_username)
    allowed = {str(x).strip() for x in cfg.get("admin_ids", []) if str(x).strip()}
    if not allowed or str(from_id) not in allowed:
        return None, None, None
    api_key = cfg.get("api_key", "")
    api = PanelAPI(api_key) if api_key else None
    return admin_username, cfg, api


# ---- rendering helpers ---------------------------------------------------

def fmt_user_card(u: dict) -> str:
    uname = user_field(u, "username", default="?")
    status = str(user_field(u, "status", default="")).lower()
    dl = int(user_field(u, "data_limit", "dataLimit", default=0) or 0)
    used = int(user_field(u, "used_traffic", "usedTraffic", "used", default=0) or 0)
    expire = user_field(u, "expire", "expire_date", default=0)
    note = user_field(u, "note", default="") or ""

    st_map = {"active": "🟢 فعال", "disabled": "🔴 غیرفعال",
              "limited": "🟡 حجم تمام", "expired": "🟠 منقضی",
              "on_hold": "⏸ در انتظار (onhold)"}
    st = st_map.get(status, status or "?")

    if dl == 0:
        vol = f"{bytes_to_gb(used):.2f} / نامحدود"
    else:
        vol = f"{bytes_to_gb(used):.2f} / {bytes_to_gb(dl):.1f} گیگ"

    hold_duration = user_field(u, "on_hold_expire_duration", default=0)
    if status == "on_hold" and isinstance(hold_duration, (int, float)) and hold_duration > 0:
        exp = f"{hold_duration / 86400:g} روز پس از فعال‌سازی"
    elif not expire:
        exp = "—" if status == "on_hold" else "نامحدود"
    else:
        try:
            ev = int(float(expire))
            if ev > 10_000_000_000:
                ev //= 1000
            days = max(0, (ev - now_epoch()) // 86400)
            exp = f"{days} روز باقی‌مانده"
        except Exception:
            exp = str(expire)

    lines = [
        f"👤 <b>{escape(str(uname))}</b>",
        f"وضعیت: {escape(st)}",
        f"📊 حجم: {vol}",
        f"⏳ زمان: {escape(exp)}",
    ]
    if note:
        lines.append(f"📝 یادداشت: {escape(str(note))}")
    return "\n".join(lines)


def user_actions_kb(uname: str):
    return kb([
        [btn("♻️ ریست حجم", f"u:rdata:{uname}"), btn("⏱ ریست زمان", f"u:rtime:{uname}")],
        [btn("➕ افزودن حجم", f"u:adddata:{uname}"), btn("➕ افزودن زمان", f"u:addtime:{uname}")],
        [btn("🔄 تمدید کامل", f"u:renew:{uname}")],
        [btn("🔴 غیرفعال", f"u:disable:{uname}"), btn("🟢 فعال", f"u:enable:{uname}")],
        [btn("🔗 لینک اشتراک", f"u:sub:{uname}"), btn("📱 دریافت کانفیگ‌ها", f"u:cfgs:{uname}")],
        [btn("🔗 نوکردن لینک", f"u:revoke:{uname}"), btn("🗑 حذف", f"u:del:{uname}")],
        [btn("📈 مصرف", f"u:usage:{uname}")],
        back_btn("m:users"),
    ])


# ==========================================================================
#  MESSAGE (text) handler
# ==========================================================================

def handle_message(update: dict, token: str):
    msg = update.get("message") or {}
    chat = msg.get("chat", {})
    chat_id = chat.get("id")
    from_id = str(msg.get("from", {}).get("id", ""))
    text = (msg.get("text") or "").strip()
    photo = msg.get("photo")

    admin_username, cfg, api = _ctx(token, from_id)
    is_admin = admin_username is not None and cfg is not None

    # non-admin sender -> user (customer) side
    if not is_admin:
        try:
            import bot_user
            bot_user.handle_message(update, token)
        except Exception as e:
            send(token, chat_id, f"خطا: {str(e)[:120]}")
        return

    with CONV.admin_scope(token, admin_username, from_id):
        _handle_admin_message(msg, token, chat_id, from_id, text, photo, admin_username, cfg, api)


def _handle_admin_message(msg, token, chat_id, from_id, text, photo, admin_username, cfg, api):
    # a document from a SUDO admin -> treat as a restore archive
    document = msg.get("document")
    if document and str(chat_id) == from_id:
        # Check if admin is in backup restore mode
        conv = CONV.get(chat_id)
        if conv and conv["state"] == "backup_restore":
            admin_uname = conv["data"].get("admin", "")
            _handle_backup_restore(token, chat_id, admin_uname, document)
            return
        # Sudo admin -> system-wide restore
        if _is_sudo(token, from_id):
            _handle_restore_upload(token, chat_id, document)
            return

    # /start -> main menu + persistent keyboard + command menu
    if text in ("/start", "/menu", "start", "منو"):
        CONV.clear(chat_id)
        set_bot_commands(token, is_user=False)
        send_kb(token, chat_id, "🛠 <b>پنل مدیریت 1PlusVPN</b>", admin_reply_kb())
        shop_en = cfg.get("shop_enabled", False) if cfg else False
        send(token, chat_id, "یکی از گزینه‌ها را انتخاب کنید:",
             main_menu(_is_sudo(token, from_id), shop_en))
        return

    # persistent reply-keyboard shortcuts + slash commands (work anytime)
    _shortcut = {
        "🏠 منوی اصلی": "home", "/menu": "home",
        "👥 کاربران": "users", "/users": "users",
        "➕ ساخت کاربر": "create", "/create": "create",
        "📊 آمار": "stats", "/stats": "stats",
        "🛠 تنظیمات": "settings", "/settings": "settings",
        "💾 بکاپ": "backup", "/backup": "backup",
    }.get(text)
    if _shortcut:
        CONV.clear(chat_id)
        _admin_shortcut(token, chat_id, from_id, _shortcut, api, cfg, admin_username)
        return

    # is there an active conversation waiting for input?
    conv = CONV.get(chat_id)
    if conv and conv["state"].startswith("onboard_admin_"):
        _admin_onboard_input(token, chat_id, from_id, msg.get("message_id"), text, conv)
        return
    if conv and api is not None:
        _handle_conv_input(token, chat_id, from_id, text, photo, conv,
                           admin_username, cfg, api)
        return


def _admin_shortcut(token, chat_id, from_id, which, api, cfg, admin_username):
    """Handle a reply-keyboard / slash shortcut by sending the matching menu."""
    if which == "home":
        shop_en = cfg.get("shop_enabled", False) if cfg else False
        send(token, chat_id, "🛠 <b>پنل مدیریت 1PlusVPN</b>\nیکی از گزینه‌ها را انتخاب کنید:",
             main_menu(_is_sudo(token, from_id), shop_en))
    elif which == "users":
        CONV.set(chat_id, "search", {})
        send(token, chat_id, "👥 <b>مدیریت کاربران</b>\n\nنام کاربری (یا بخشی از آن) را برای جستجو بفرستید:",
             kb([back_btn()]))
    elif which == "create":
        _show_create_menu(token, chat_id)
    elif which == "stats":
        m = send(token, chat_id, "⏳ در حال محاسبه آمار...")
        try:
            mid = m["result"]["message_id"]
            _show_stats(token, chat_id, mid, api, admin_username)
        except Exception:
            pass
    elif which == "settings":
        m = send(token, chat_id, "🛠 در حال بارگذاری تنظیمات...")
        try:
            mid = m["result"]["message_id"]
            _show_settings(token, chat_id, mid, admin_username, cfg)
        except Exception:
            pass
    elif which == "backup":
        if str(chat_id) != str(from_id):
            send(token, chat_id, "بکاپ فقط در چت خصوصی بات قابل استفاده است.")
            return
        _show_backup_menu(token, chat_id, None, admin_username, cfg)


def _handle_conv_input(token, chat_id, from_id, text, photo, conv,
                       admin_username, cfg, api: PanelAPI):
    state = conv["state"]
    data = conv["data"]

    # ---- user search ----
    if state == "search":
        CONV.clear(chat_id)
        _do_search(token, chat_id, api, text)
        return

    # ---- numeric inputs for a target user ----
    if state in ("rdata", "rtime", "adddata", "addtime"):
        uname = data["uname"]
        try:
            val = float(text.replace(",", "").strip())
        except ValueError:
            send(token, chat_id, "❗️ لطفاً یک عدد معتبر بفرستید.")
            return
        CONV.clear(chat_id)
        _apply_user_number(token, chat_id, api, state, uname, val)
        return

    # ---- full renewal flow: gb -> days -> service ----
    if state == "renew_gb":
        try:
            gb = float(text.replace(",", "").strip())
        except ValueError:
            send(token, chat_id, "❗️ لطفاً یک عدد معتبر بفرستید.")
            return
        data["gb"] = gb
        CONV.set(chat_id, "renew_days", data)
        send(token, chat_id, "⏳ مدت جدید (روز) را بفرستید (برای نامحدود عدد 0):")
        return
    if state == "renew_days":
        try:
            days = int(float(text.replace(",", "").strip()))
        except ValueError:
            send(token, chat_id, "❗️ لطفاً یک عدد معتبر بفرستید.")
            return
        data["days"] = days
        rows, svcs = _service_buttons(api, "rsvc")
        if not svcs:
            CONV.clear(chat_id)
            _do_full_renew(token, chat_id, api, data["uname"], data["gb"], data["days"], None)
            return
        CONV.set(chat_id, "renew_service", data)
        send(token, chat_id, "🧩 سرویس این کاربر را انتخاب کنید:", kb(rows + [back_btn()]))
        return

    # ---- create user flow ----
    if state == "create_name":
        if not text or any(c.isspace() for c in text):
            send(token, chat_id, "❗️ نام کاربری نامعتبر است. یک نام بدون فاصله بفرستید.")
            return
        data["uname"] = text
        _prompt_create_gb(token, chat_id, data)
        return
    if state == "create_gb":
        try:
            gb = float(text.replace(",", ""))
        except ValueError:
            gb = -1
        if not math.isfinite(gb) or not 0 <= gb < 2**33:
            send(token, chat_id, "❗️ حجم معتبر و غیرمنفی به گیگابایت وارد کنید.")
            return
        data["gb"] = gb
        CONV.set(chat_id, "create_days", data)
        prompt = ("⏳ مدت اکانت پس از فعال‌سازی را به روز بفرستید (مثلاً 30؛ حداقل ۱ روز)."
                  if data["onhold"] else
                  "⏳ مدت اکانت را به روز بفرستید (مثلاً 30). برای نامحدود عدد 0 را بفرستید.")
        send(token, chat_id, prompt, kb([back_btn("m:create")]))
        return
    if state == "create_days":
        try:
            days = int(text.replace(",", ""))
        except ValueError:
            days = -1
        if days < (1 if data["onhold"] else 0):
            send(token, chat_id, "❗️ برای onhold یک عدد صحیح مثبت به روز بفرستید."
                 if data["onhold"] else "❗️ تعداد روز باید یک عدد صحیح غیرمنفی باشد.")
            return
        data["days"] = days
        rows, _ = _service_buttons(api, "csvc")
        if not rows:
            CONV.clear(chat_id)
            _do_create_user(token, chat_id, api, data, admin_username, cfg)
            return
        CONV.set(chat_id, "create_service", data)
        send(token, chat_id, "🧩 سرویس این کاربر را انتخاب کنید:", kb(rows + [back_btn("m:create")]))
        return

    # ---- broadcast ----
    if state == "broadcast":
        CONV.clear(chat_id)
        _do_broadcast(token, chat_id, api, admin_username, text)
        return

    # ---- private message to one user ----
    if state == "pm_target":
        data["target"] = text.strip()
        CONV.set(chat_id, "pm_text", data)
        send(token, chat_id, "✍️ متن پیام را بفرستید:")
        return
    if state == "pm_text":
        CONV.clear(chat_id)
        _do_private_message(token, chat_id, data.get("target", ""), text)
        return

    # ---- bulk add data/time ----
    if state in ("bulk_adddata", "bulk_addtime"):
        try:
            val = float(text.replace(",", ""))
        except ValueError:
            send(token, chat_id, "❗️ یک عدد بفرستید.")
            return
        CONV.clear(chat_id)
        _do_bulk_add(token, chat_id, api, admin_username, state, val)
        return

    # ---- settings edits (card/prices/texts) ----
    if state.startswith("set_"):
        CONV.clear(chat_id)
        _apply_setting_input(token, chat_id, admin_username, state, text)
        return

    # ---- system settings edits (sudo) ----
    if state.startswith("sysset_"):
        CONV.clear(chat_id)
        _apply_sys_setting_input(token, chat_id, admin_username, state, text)
        return

    # ---- shop prefix input ----
    if state == "shop_prefix":
        CONV.clear(chat_id)
        prefix = text.strip()[:10]
        if not prefix or " " in prefix:
            send(token, chat_id, "❗️ پیشوند نامعتبر. یک کلمه بدون فاصله بفرستید (مثلاً Mt):")
            return
        settings.set_setting(admin_username, "shop_prefix", prefix)
        send(token, chat_id, f"✅ پیشوند روی <b>{prefix}</b> تنظیم شد.",
             kb([[btn("« فروشگاه", "m:shop")], back_btn()]))
        return

    # ---- package creation/edit flow ----
    if state == "pkg_name":
        name = text.strip()
        if not name:
            send(token, chat_id, "❗️ نام پکیج نمی‌تواند خالی باشد.")
            return
        data["name"] = name
        CONV.set(chat_id, "pkg_p30", data)
        send(token, chat_id, "💰 قیمت هر گیگ برای <b>۳۰ روز</b> را به تومان بفرستید:\n(مثلاً 10000)")
        return
    if state == "pkg_p30":
        try:
            val = int(float(text.replace(",", "")))
            if val < 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["p30"] = val
        CONV.set(chat_id, "pkg_p60", data)
        send(token, chat_id, "💰 قیمت هر گیگ برای <b>۶۰ روز</b> را به تومان بفرستید:\n(یا 0 برای رد کردن)")
        return
    if state == "pkg_p60":
        try:
            val = int(float(text.replace(",", "")))
            if val < 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["p60"] = val
        CONV.set(chat_id, "pkg_p90", data)
        send(token, chat_id, "💰 قیمت هر گیگ برای <b>۹۰ روز</b> را به تومان بفرستید:\n(یا 0 برای رد کردن)")
        return
    if state == "pkg_p90":
        try:
            val = int(float(text.replace(",", "")))
            if val < 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["p90"] = val
        CONV.set(chat_id, "pkg_note", data)
        send(token, chat_id, "📝 توضیح اختیاری برای پکیج بفرستید (یا «-» برای رد کردن):")
        return
    if state == "pkg_note":
        note = text.strip() if text.strip() != "-" else ""
        data["note"] = note
        CONV.clear(chat_id)
        _do_save_package(token, chat_id, admin_username, api, data)
        return

    # ---- package edit sub-flows ----
    if state in ("pkg_ename", "pkg_eprice", "pkg_enote"):
        CONV.clear(chat_id)
        _handle_pkg_edit_input(token, chat_id, admin_username, state, text, data)
        return

    # ---- service selection for new package ----
    if state == "pkg_service":
        # this state waits for a callback, not text input
        # but if user sends text, ignore
        return

    # ---- discount code creation flow ----
    if state == "disc_code":
        code = text.strip().upper()
        if code == "AUTO" or not code:
            import shop as _sh
            code = _sh.generate_random_code("DC")
        data["code"] = code
        CONV.set(chat_id, "disc_type", data)
        send(token, chat_id,
             "نوع تخفیف را انتخاب کنید:\n\n"
             "• <b>percent</b> — درصدی از مبلغ کل\n"
             "• <b>toman</b> — مبلغ ثابت به تومان\n\n"
             "یکی از این دو را بفرستید:")
        return

    if state == "disc_type":
        dtype = text.strip().lower()
        if dtype not in ("percent", "toman"):
            send(token, chat_id, "❗️ لطفاً <code>percent</code> یا <code>toman</code> بفرستید.")
            return
        data["discount_type"] = dtype
        CONV.set(chat_id, "disc_value", data)
        if dtype == "percent":
            send(token, chat_id, "درصد تخفیف را بفرستید (مثلاً 10 یا 20):")
        else:
            send(token, chat_id, "مبلغ تخفیف را به تومان بفرستید (مثلاً 5000):")
        return

    if state == "disc_value":
        try:
            val = int(float(text.replace(",", "")))
            if val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["discount_value"] = val
        CONV.set(chat_id, "disc_uses", data)
        send(token, chat_id, "حداکثر تعداد استفاده را بفرستید (مثلاً 1):")
        return

    if state == "disc_uses":
        try:
            uses = int(float(text.replace(",", "")))
            if uses <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["max_uses"] = uses
        CONV.clear(chat_id)
        import shop as _sh
        try:
            _sh.create_discount_code(admin_username, data["code"], data["discount_type"],
                                     data["discount_value"], uses)
            dtype_label = "درصد" if data["discount_type"] == "percent" else "تومان"
            send(token, chat_id,
                 f"✅ کد تخفیف ساخته شد!\n\n"
                 f"🎟 کد: <code>{data['code']}</code>\n"
                 f"💰 {data['discount_value']} {dtype_label}\n"
                 f"🔢 حداکثر استفاده: {uses}",
                 kb([[btn("« کدهای تخفیف", "m:discounts")]]))
        except ValueError as e:
            send(token, chat_id, f"❌ خطا: {str(e)}", kb([[btn("« کدهای تخفیف", "m:discounts")]]))
        return

    # ---- gift code creation flow ----
    if state == "gift_code":
        code = text.strip().upper()
        if code == "AUTO" or not code:
            import shop as _sh
            code = _sh.generate_random_code("GIFT")
        data["code"] = code
        CONV.set(chat_id, "gift_days", data)
        send(token, chat_id, "مدت اشتراک هدیه را به روز بفرستید (مثلاً 30):")
        return

    if state == "gift_days":
        try:
            days = int(float(text.replace(",", "")))
            if days <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["plan_days"] = days
        CONV.set(chat_id, "gift_gb", data)
        send(token, chat_id, "حجم اشتراک هدیه را به گیگابایت بفرستید (مثلاً 50):")
        return

    if state == "gift_gb":
        try:
            gb = int(float(text.replace(",", "")))
            if gb <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        data["gb"] = gb
        CONV.set(chat_id, "gift_uses", data)
        send(token, chat_id, "حداکثر تعداد استفاده را بفرستید (مثلاً 1):")
        return

    if state == "gift_uses":
        try:
            uses = int(float(text.replace(",", "")))
            if uses <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        CONV.clear(chat_id)
        import shop as _sh
        try:
            _sh.create_gift_code(admin_username, data["code"], data["plan_days"],
                                 data["gb"], uses)
            label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}.get(data["plan_days"], f"{data['plan_days']} روز")
            send(token, chat_id,
                 f"✅ کد هدیه ساخته شد!\n\n"
                 f"🎁 کد: <code>{data['code']}</code>\n"
                 f"📦 پلن: {label} | {data['gb']} گیگ\n"
                 f"🔢 حداکثر استفاده: {uses}\n"
                 f"👤 ادمین: <code>{admin_username}</code>\n\n"
                 f"⚠️ برای استفاده، URL فروشگاه باید شامل "
                 f"<code>?admin={admin_username}</code> باشد.",
                 kb([[btn("« کدهای هدیه", "m:gifts")]]))
        except ValueError as e:
            send(token, chat_id, f"❌ خطا: {str(e)}", kb([[btn("« کدهای هدیه", "m:gifts")]]))
        return

    # ---- trial settings inputs ----
    if state == "trial_data":
        try:
            val = int(float(text.replace(",", "")))
            if val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        settings.set_setting(admin_username, "trial_data_mb", val)
        send(token, chat_id, f"✅ حجم اکانت تست روی <b>{val} مگابایت</b> تنظیم شد.",
             kb([[btn("« اکانت تست", "m:trial")]]))
        return

    if state == "trial_time":
        try:
            val = int(float(text.replace(",", "")))
            if val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        settings.set_setting(admin_username, "trial_hours", val)
        send(token, chat_id, f"✅ زمان اکانت تست روی <b>{val} ساعت</b> تنظیم شد.",
             kb([[btn("« اکانت تست", "m:trial")]]))
        return

    # ---- backup interval input ----
    if state == "backup_interval":
        try:
            val = int(float(text.replace(",", "")))
            if val < 1 or val > 168:  # between 1 hour and 7 days
                raise ValueError
        except (ValueError, TypeError, OverflowError):
            send(token, chat_id, "❗️ عدد بین ۱ تا ۱۶۸ (ساعت) بفرستید.")
            return
        settings.set_setting(admin_username, "backup_interval_hours", val)
        _reset_backup_schedule(admin_username)
        CONV.clear(chat_id)
        send(token, chat_id, f"✅ فاصله زمانی بکاپ خودکار روی <b>{val} ساعت</b> تنظیم شد.",
             kb([[btn("« بکاپ", "m:backup")]]))
        return

    # ---- referral reward settings inputs ----
    if state == "refr_wallet":
        try:
            val = int(float(text.replace(",", "")))
            if val <= 0:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ یک عدد معتبر بفرستید.")
            return
        settings.set_setting(admin_username, "referral_reward_value", val)
        send(token, chat_id, f"✅ مبلغ کیف پول روی <b>{val:,} تومان</b> تنظیم شد.",
             kb([[btn("« پاداش رفرال", "m:ref_reward")]]))
        return

    if state == "refr_percent":
        try:
            val = int(float(text.replace(",", "")))
            if val <= 0 or val > 100:
                raise ValueError
        except (ValueError, TypeError):
            send(token, chat_id, "❗️ عدد بین ۱ تا ۱۰۰ بفرستید.")
            return
        settings.set_setting(admin_username, "referral_reward_percent", val)
        send(token, chat_id, f"✅ درصد تخفیف روی <b>{val}%</b> تنظیم شد.",
             kb([[btn("« پاداش رفرال", "m:ref_reward")]]))
        return

    if state == "refr_text":
        settings.set_setting(admin_username, "referral_reward_text", text)
        settings.set_setting(admin_username, "referral_wallet_text", text)
        send(token, chat_id, "✅ متن پاداش ذخیره شد.",
             kb([[btn("« پاداش رفرال", "m:ref_reward")]]))
        return

    # ---- bot user search ----
    if state == "botuser_search":
        CONV.clear(chat_id)
        import user_registry as _ur
        results = _ur.search_users(text, admin_username)
        
        if not results:
            send(token, chat_id, f" کاربری با «{text}» یافت نشد.",
                 kb([[btn("« بازگشت", "m:bot_users")]]))
            return
        
        txt = f"🔎 <b>نتایج جستجو ({len(results)})</b>\n\n"
        for u in results[:10]:  # Show max 10
            status = "🚫 مسدود" if u.get("blocked") else "✅ فعال"
            txt += f"• <code>{u['username']}</code> — {status}\n"
            txt += f"  chat_id: {u['chat_id']}\n\n"
        
        rows = []
        for u in results[:5]:  # Add block/unblock/delete buttons for first 5
            if u.get("blocked"):
                rows.append([btn(f"🟢 آزاد کردن {u['username'][:12]}", f"botuser:unblock:{u['chat_id']}"),
                             btn(f"🗑 حذف {u['username'][:10]}", f"botuser:delete:{u['chat_id']}")])
            else:
                rows.append([btn(f"🚫 مسدود کردن {u['username'][:12]}", f"botuser:block:{u['chat_id']}"),
                             btn(f"🗑 حذف {u['username'][:10]}", f"botuser:delete:{u['chat_id']}")])
        rows.append([btn("« بازگشت", "m:bot_users")])
        
        send(token, chat_id, txt, kb(rows))
        return

    # ---- bot user block reason ----
    if state == "botuser_block_reason":
        CONV.clear(chat_id)
        import user_registry as _ur
        target_chat = data.get("target_chat", "")
        reason = text.strip() if text.strip() != "بدون دلیل" else ""
        
        _ur.block_user(target_chat, reason)
        
        # Notify the blocked user
        msg_text = "⛔️ <b>شما از بات مسدود شدید.</b>"
        if reason:
            msg_text += f"\n\nدلیل: {reason}"
        try:
            send(token, int(target_chat), msg_text)
        except Exception:
            pass  # User might have blocked the bot
        
        send(token, chat_id, "✅ کاربر مسدود شد.",
             kb([[btn("« بازگشت", "m:bot_users")]]))
        return

    # ---- bot user delete confirmation ----
    if state == "botuser_delete_confirm":
        CONV.clear(chat_id)
        import user_registry as _ur
        target_chat = data.get("target_chat", "")
        uname = data.get("username", "")
        if text.strip() == "1":
            _ur.remove(target_chat)
            send(token, chat_id,
                 f"✅ کاربر <code>{uname}</code> (chat_id: <code>{target_chat}</code>) حذف شد.",
                 kb([[btn("« بازگشت", "m:bot_users")]]))
        else:
            send(token, chat_id, "❌ لغو شد.",
                 kb([[btn("« بازگشت", "m:bot_users")]]))
        return


# ==========================================================================
#  CALLBACK (button) handler
# ==========================================================================

def handle_callback(update: dict, token: str, legacy_order_handler=None):
    cb = update.get("callback_query")
    if not cb:
        return
    data = cb.get("data", "")
    cb_id = cb.get("id")
    msg = cb.get("message") or {}
    chat_id = (msg.get("chat") or {}).get("id")
    message_id = msg.get("message_id")
    sender = (cb.get("from") or {}).get("id")
    from_id = str(sender or "")
    if data == "m:home" and chat_id is None and isinstance(sender, int) and sender > 0:
        chat_id, message_id = sender, None

    # legacy approve/reject:<order_id> still handled by app.py
    if data.startswith("approve:") or data.startswith("reject:"):
        if legacy_order_handler:
            legacy_order_handler(update, token)
        return

    # user (customer) side callbacks
    if data.startswith("uu:"):
        try:
            import bot_user
            bot_user.handle_callback(update, token)
        except Exception as e:
            import traceback
            print(f"[bot_user callback error] {e}")
            traceback.print_exc()
            try:
                answer(token, cb_id, f"خطا: {str(e)[:150]}", alert=True)
            except Exception:
                pass
        return

    admin_username, cfg, api = _ctx(token, from_id)
    if admin_username is None:
        answer(token, cb_id, "شما مجاز نیستید", alert=True)
        return

    try:
        with CONV.admin_scope(token, admin_username, from_id):
            _route_callback(token, cb_id, chat_id, message_id, from_id, data,
                            admin_username, cfg, api)
    except PanelError as e:
        answer(token, cb_id, f"خطا: {e.message[:150]}", alert=True)
    except KeyError as e:
        import traceback
        print(f"[CALLBACK KEYERROR] key={e}, data={data!r}, chat={chat_id}")
        traceback.print_exc()
        answer(token, cb_id, f"خطا: کلید {e} پیدا نشد (data={data[:30]})", alert=True)
    except Exception as e:
        import traceback
        print(f"[CALLBACK ERROR] {e}, data={data!r}, chat={chat_id}")
        traceback.print_exc()
        answer(token, cb_id, f"خطای غیرمنتظره: {str(e)[:120]}", alert=True)


def _route_callback(token, cb_id, chat_id, message_id, from_id, data,
                    admin_username, cfg, api):
    # ----- main menu navigation -----
    if data == "m:home":
        CONV.clear(chat_id)
        answer(token, cb_id)
        if chat_id is not None:
            _show_admin_home(token, chat_id, message_id, from_id, admin_username, cfg)
        return

    if (data == "m:backup" or data.startswith("backup:")) and str(chat_id) != from_id:
        answer(token, cb_id, "بکاپ فقط در چت خصوصی بات قابل استفاده است.", alert=True)
        return

    if data == "m:backup":
        answer(token, cb_id)
        # Per-admin backup/restore
        _show_backup_menu(token, chat_id, message_id, admin_username, cfg)
        return

    # NOTE: `backup:get` must be tested BEFORE the generic `backup:` prefix —
    # the original code had the generic branch first, which made the whole
    # sudo `backup:get` block below unreachable dead code.
    if data.startswith("backup:"):
        _backup_action(token, cb_id, chat_id, message_id, admin_username, cfg, data.split(":", 1)[1])
        return

    if data == "m:users":
        answer(token, cb_id)
        CONV.set(chat_id, "search", {})
        safe_edit(token, chat_id, message_id,
             "👥 <b>مدیریت کاربران</b>\n\nنام کاربری (یا بخشی از آن) را برای جستجو بفرستید:",
             kb([back_btn()]))
        return

    if data == "m:create":
        answer(token, cb_id)
        _show_create_menu(token, chat_id, message_id)
        return

    if data in ("create:normal", "create:onhold"):
        if api is None:
            answer(token, cb_id, "کلید API این ادمین تنظیم نشده است.", alert=True)
            return
        answer(token, cb_id)
        onhold = data.endswith("onhold")
        kind = "onhold" if onhold else "normal"
        CONV.set(chat_id, "create_name", {"onhold": onhold})
        prefix = escape(cfg.get("shop_prefix") or "ST")
        safe_edit(token, chat_id, message_id,
             f"➕ <b>ساخت کاربر {'onhold' if onhold else 'عادی'}</b>\n\n"
             f"نام دلخواه را بفرستید یا نام خودکار با پیشوند <code>{prefix}</code> را انتخاب کنید:",
             kb([[btn("🔢 نام خودکار", f"create:auto:{kind}")], back_btn("m:create")]))
        return

    if data in ("create:auto:normal", "create:auto:onhold"):
        conv = CONV.get(chat_id)
        if (api is None or not conv or conv["state"] != "create_name"
                or conv["data"]["onhold"] != data.endswith(":onhold")):
            answer(token, cb_id, "ابتدا دوباره نوع اکانت را انتخاب کنید.", alert=True)
            return
        answer(token, cb_id)
        _prompt_create_gb(token, chat_id, {**conv["data"], "auto_name": True})
        return

    if data in ("m:stats", "m:stats_force"):
        # "m:stats_force" is the 🔄 بروزرسانی button: it bypasses the 60 s
        # stats cache so a refresh really refreshes, while a plain menu tap
        # stays instant.
        answer(token, cb_id, "در حال بروزرسانی..." if data == "m:stats_force" else "")
        if data == "m:stats_force":
            _invalidate_stats(admin_username)
        _show_stats(token, chat_id, message_id, api, admin_username)
        return

    if data == "m:broadcast":
        answer(token, cb_id)
        CONV.set(chat_id, "broadcast", {})
        safe_edit(token, chat_id, message_id,
             "📢 <b>پیام همگانی</b>\n\nمتنی که می‌خواهید برای همه‌ی کاربران (که در ربات ثبت‌نام کرده‌اند) ارسال شود را بفرستید:",
             kb([back_btn()]))
        return

    if data == "m:bulk":
        answer(token, cb_id)
        safe_edit(token, chat_id, message_id,
             "⚙️ <b>عملیات دسته‌جمعی</b>\nاحتیاط: روی همه‌ی کاربران شما اعمال می‌شود.",
             kb([[btn("🟢 فعال‌کردن همه", "bulk:enableall"),
                  btn("🔴 غیرفعال‌کردن همه", "bulk:disableall")],
                 [btn("➕ افزودن حجم به همه", "bulk:adddata"),
                  btn("➕ افزودن زمان به همه", "bulk:addtime")],
                 back_btn()]))
        return

    if data == "m:ref":
        answer(token, cb_id)
        _show_referral_admin(token, chat_id, message_id, admin_username)
        return

    if data == "m:settings":
        answer(token, cb_id)
        _show_settings(token, chat_id, message_id, admin_username, cfg)
        return

    # BUGFIX: this button (data="m:sys_settings") had NO handler in the original
    # code — pressing it just hit the final answer() and nothing happened.
    if data == "m:sys_settings":
        if not _is_sudo(token, from_id):
            answer(token, cb_id, "فقط ادمین سودو", alert=True)
            return
        answer(token, cb_id)
        _show_sys_settings(token, chat_id, message_id, admin_username, cfg,
                           show_add=str(chat_id) == from_id and _can_add_admin(token, from_id))
        return

    # ----- bot users management -----
    if data == "m:bot_users":
        answer(token, cb_id)
        _show_bot_users_menu(token, chat_id, message_id, admin_username)
        return

    if data.startswith("botuser:"):
        _bot_user_action(token, cb_id, chat_id, message_id, admin_username, data.split(":", 1)[1])
        return

    # ----- discount codes -----
    if data == "m:discounts":
        answer(token, cb_id)
        _show_discounts_menu(token, chat_id, message_id, admin_username)
        return

    if data.startswith("disc:"):
        _discount_action(token, cb_id, chat_id, message_id, admin_username, data.split(":", 1)[1])
        return

    # ----- gift codes -----
    if data == "m:gifts":
        answer(token, cb_id)
        _show_gifts_menu(token, chat_id, message_id, admin_username)
        return

    if data.startswith("gift:"):
        _gift_action(token, cb_id, chat_id, message_id, admin_username, data.split(":", 1)[1])
        return

    # ----- trial account -----
    if data == "m:trial":
        answer(token, cb_id)
        _show_trial_menu(token, chat_id, message_id, admin_username, cfg)
        return

    if data.startswith("trial:"):
        _trial_action(token, cb_id, chat_id, message_id, admin_username, cfg, data.split(":", 1)[1])
        return

    # ----- referral rewards -----
    if data == "m:ref_reward":
        answer(token, cb_id)
        _show_ref_reward_menu(token, chat_id, message_id, admin_username, cfg)
        return

    if data.startswith("refr:"):
        _ref_reward_action(token, cb_id, chat_id, message_id, admin_username, cfg, data.split(":", 1)[1])
        return

    # ----- payment methods -----
    if data == "m:pay_methods":
        answer(token, cb_id)
        _show_pay_methods_menu(token, chat_id, message_id, admin_username, cfg)
        return

    if data.startswith("pay:"):
        _pay_methods_action(token, cb_id, chat_id, message_id, admin_username, cfg, data.split(":", 1)[1])
        return

    # ----- shop management -----
    if data == "m:shop":
        answer(token, cb_id)
        if not cfg.get("shop_enabled", False):
            answer(token, cb_id, "فروشگاه برای شما غیرفعال است. از پنل فعال کنید.", alert=True)
            return
        _show_shop_menu(token, chat_id, message_id, admin_username, cfg, api)
        return

    if data.startswith("shop:"):
        answer(token, cb_id)
        if not cfg.get("shop_enabled", False):
            answer(token, cb_id, "فروشگاه غیرفعال است", alert=True)
            return
        _shop_action(token, cb_id, chat_id, message_id, admin_username, cfg, api, data.split(":", 1)[1])
        return

    if data.startswith("pkg:"):
        answer(token, cb_id)
        if not cfg.get("shop_enabled", False):
            answer(token, cb_id, "فروشگاه غیرفعال است", alert=True)
            return
        _pkg_action(token, cb_id, chat_id, message_id, admin_username, cfg, api, data)
        return

    # ----- service chosen (create or renew) -----
    if data.startswith("csvc:"):
        answer(token, cb_id)
        sid = data.split(":", 1)[1]
        conv = CONV.get(chat_id)
        if api is None or not conv or conv["state"] != "create_service":
            return
        d = conv["data"]
        CONV.clear(chat_id)
        _do_create_user(token, chat_id, api, d, admin_username, cfg, service_id=sid)
        return
    if data.startswith("rsvc:"):
        answer(token, cb_id)
        sid = data.split(":", 1)[1]
        conv = CONV.get(chat_id)
        if not conv or conv["state"] != "renew_service":
            return
        d = conv["data"]
        CONV.clear(chat_id)
        _do_full_renew(token, chat_id, api, d["uname"], d["gb"], d["days"], sid)
        return

    # ----- user selected from search results -----
    if data.startswith("open:"):
        if api is None:
            answer(token, cb_id, "کلید API این ادمین تنظیم نشده است.", alert=True)
            return
        uname = data.split(":", 1)[1]
        answer(token, cb_id)
        try:
            u = api.get_user(uname)
        except PanelError:
            safe_edit(token, chat_id, message_id, "کاربر یافت نشد.", kb([back_btn("m:users")]))
            return
        safe_edit(token, chat_id, message_id, fmt_user_card(u), user_actions_kb(uname))
        return

    # ----- per-user actions -----
    if data.startswith("u:"):
        _, action, uname = data.split(":", 2)
        if api is None:
            answer(token, cb_id, "کلید API این ادمین تنظیم نشده است.", alert=True)
            return
        if action in ("sub", "cfgs") and str(chat_id) != from_id:
            answer(token, cb_id, "لینک و کانفیگ فقط در چت خصوصی ربات نمایش داده می‌شود.", alert=True)
            return
        _user_action(token, cb_id, chat_id, message_id, api, admin_username, action, uname)
        return

    # ----- bulk actions -----
    if data.startswith("bulk:"):
        _bulk_action(token, cb_id, chat_id, message_id, api, admin_username, data.split(":", 1)[1])
        return

    # ----- settings actions -----
    if data.startswith("set:"):
        _settings_action(token, cb_id, chat_id, message_id, admin_username, cfg, data.split(":", 1)[1])
        return

    # ----- system settings actions (sudo only) -----
    if data in ("onboard:add", "onboard:cancel"):
        if str(chat_id) != from_id or not _can_add_admin(token, from_id):
            answer(token, cb_id, "فقط سودو در چت خصوصی بات اصلی مجاز است.", alert=True)
            return
        CONV.clear(chat_id)
        answer(token, cb_id)
        if data == "onboard:cancel":
            _show_sys_settings(token, chat_id, message_id, admin_username, cfg, show_add=True)
            return
        CONV.set(chat_id, "onboard_admin_name", {"until": time.monotonic() + 600})
        safe_edit(token, chat_id, message_id,
                  "➕ <b>افزودن ادمین پنل فعلی Rebecca</b>\nنام حساب موجود در Rebecca را بفرستید.",
                  _admin_onboard_kb())
        return

    if data.startswith("sys:"):
        if not _is_sudo(token, from_id):
            answer(token, cb_id, "فقط ادمین سودو", alert=True)
            return
        _sys_settings_action(token, cb_id, chat_id, message_id, admin_username, data.split(":", 1)[1])
        return

    # ----- referral toggle -----
    if data.startswith("ref:"):
        _referral_action(token, cb_id, chat_id, message_id, admin_username, data.split(":", 1)[1])
        return

    answer(token, cb_id)


# ==========================================================================
#  ACTION IMPLEMENTATIONS
# ==========================================================================

def _do_search(token, chat_id, api: PanelAPI, query: str):
    typing(token, chat_id)
    try:
        res = api.list_users(search=query, limit=20)
    except PanelError as e:
        send(token, chat_id, f"خطا در جستجو: {e.message}", kb([back_btn()]))
        return
    users = res["users"]
    if not users:
        send(token, chat_id, f"کاربری با «{query}» یافت نشد.",
             kb([[btn("🔎 جستجوی دوباره", "m:users")], back_btn()]))
        return
    rows = []
    for u in users[:20]:
        uname = user_field(u, "username", default="?")
        st = str(user_field(u, "status", default="")).lower()
        dot = {"active": "🟢", "disabled": "🔴", "limited": "🟡",
               "expired": "🟠", "on_hold": "⏸"}.get(st, "▫️")
        rows.append([btn(f"{dot} {uname}", f"open:{uname}")])
    rows.append(back_btn())
    send(token, chat_id, f"🔎 نتایج جستجو برای «{query}» ({len(users)}):", kb(rows))


def _user_action(token, cb_id, chat_id, message_id, api, admin_username, action, uname):
    if action in ("sub", "cfgs"):
        # Look up fresh data with the acting admin's key, never the sudo client.
        user = api.get_user(uname)
        answer(token, cb_id)
        _show_user_credentials(token, chat_id, user, uname, action)
        return

    # actions that need a number -> start a conversation
    prompts = {
        "rdata": "♻️ حجم جدید را به گیگابایت بفرستید (مثلاً 50):",
        "rtime": "⏱ مدت جدید را به روز بفرستید (مثلاً 30):",
        "adddata": "➕ چند گیگابایت به حجم فعلی اضافه شود؟",
        "addtime": "➕ چند روز به زمان فعلی اضافه شود؟",
    }
    if action in prompts:
        answer(token, cb_id)
        CONV.set(chat_id, action, {"uname": uname})
        send(token, chat_id, prompts[action])
        return

    if action == "renew":
        answer(token, cb_id)
        CONV.set(chat_id, "renew_gb", {"uname": uname})
        send(token, chat_id, "🔄 <b>تمدید کامل</b>\nحجم جدید (گیگابایت) را بفرستید (برای نامحدود عدد 0):")
        return

    if action == "disable":
        api.update_user(uname, {**api.get_user(uname), "status": "disabled"})
        answer(token, cb_id, "کاربر غیرفعال شد ✅")
        _refresh_card(token, chat_id, message_id, api, uname)
        return
    if action == "enable":
        api.update_user(uname, {**api.get_user(uname), "status": "active"})
        answer(token, cb_id, "کاربر فعال شد ✅")
        _refresh_card(token, chat_id, message_id, api, uname)
        return
    if action == "revoke":
        api.revoke_sub(uname)
        answer(token, cb_id, "لینک اشتراک نو شد ✅", alert=True)
        return
    if action == "del":
        answer(token, cb_id)
        safe_edit(token, chat_id, message_id,
             f"🗑 آیا از حذف کاربر <b>{uname}</b> مطمئن هستید؟ این عمل برگشت‌ناپذیر است.",
             kb([[btn("✅ بله، حذف کن", f"u:delconfirm:{uname}"),
                  btn("« انصراف", f"open:{uname}")]]))
        return
    if action == "delconfirm":
        api.delete_user(uname)
        answer(token, cb_id, "کاربر حذف شد ✅", alert=True)
        safe_edit(token, chat_id, message_id, f"🗑 کاربر <b>{uname}</b> حذف شد.", kb([back_btn("m:users")]))
        return
    if action == "usage":
        answer(token, cb_id)
        u = api.get_user(uname)
        used = int(user_field(u, "used_traffic", "usedTraffic", "used", default=0) or 0)
        dl = int(user_field(u, "data_limit", "dataLimit", default=0) or 0)
        pct = (used / dl * 100) if dl else 0
        txt = (f"📈 <b>مصرف کاربر {uname}</b>\n\n"
               f"مصرف‌شده: {bytes_to_gb(used):.2f} گیگ\n"
               f"کل: {'نامحدود' if dl == 0 else f'{bytes_to_gb(dl):.1f} گیگ'}\n"
               f"درصد مصرف: {pct:.0f}%")
        safe_edit(token, chat_id, message_id, txt, kb([[btn("« بازگشت", f"open:{uname}")]]))
        return

    answer(token, cb_id)


def _refresh_card(token, chat_id, message_id, api, uname):
    try:
        u = api.get_user(uname)
        safe_edit(token, chat_id, message_id, fmt_user_card(u), user_actions_kb(uname))
    except Exception:
        pass


def _apply_user_number(token, chat_id, api: PanelAPI, state, uname, val):
    try:
        u = api.get_user(uname)
    except PanelError as e:
        send(token, chat_id, f"خطا: {e.message}")
        return
    # BUG FIX: was `payload = dict(u)` — the whole user object (including
    # server-owned fields like used_traffic / online_at / links / admin) was
    # echoed back on every PUT. Rebecca's PUT takes a partial field set, so we
    # now send only what actually changes.
    payload = {}
    now = now_epoch()

    def cur_expire_epoch():
        e = user_field(u, "expire", "expire_date", default=0) or 0
        try:
            e = int(float(e))
            if e > 10_000_000_000:
                e //= 1000
            return e
        except Exception:
            return 0

    if state == "rdata":
        # Reset usage FIRST, then arm the new limit (the old order wrote
        # used_traffic=0 in the PUT and then raced the /reset call).
        try:
            api.reset_usage(uname)
        except Exception:
            pass
        payload["data_limit"] = to_bytes_gb(val)
        payload["status"] = "active"
        api.update_user(uname, payload)
        send(token, chat_id, f"✅ حجم کاربر <b>{uname}</b> روی {val:g} گیگ تنظیم و مصرف صفر شد.",
             kb([[btn("مشاهده کاربر", f"open:{uname}")]]))
        return

    if state == "rtime":
        payload["expire"] = now + int(val) * 86400
        payload["status"] = "active"
        api.update_user(uname, payload)
        send(token, chat_id, f"✅ زمان کاربر <b>{uname}</b> روی {int(val)} روز از حالا تنظیم شد.",
             kb([[btn("مشاهده کاربر", f"open:{uname}")]]))
        return

    if state == "adddata":
        cur = int(user_field(u, "data_limit", "dataLimit", default=0) or 0)
        payload["data_limit"] = cur + to_bytes_gb(val)
        api.update_user(uname, payload)
        send(token, chat_id, f"✅ {val:g} گیگ به حجم کاربر <b>{uname}</b> اضافه شد.",
             kb([[btn("مشاهده کاربر", f"open:{uname}")]]))
        return

    if state == "addtime":
        base = max(cur_expire_epoch(), now)
        payload["expire"] = base + int(val) * 86400
        api.update_user(uname, payload)
        send(token, chat_id, f"✅ {int(val)} روز به زمان کاربر <b>{uname}</b> اضافه شد.",
             kb([[btn("مشاهده کاربر", f"open:{uname}")]]))
        return


def _service_buttons(api: PanelAPI, prefix: str):
    """Build inline buttons for the admin's services. Returns (rows, services)."""
    try:
        svcs = api.list_services() or []
    except Exception:
        svcs = []
    rows = []
    for s in svcs:
        sid = s.get("id") or s.get("service_id") or s.get("_id")
        name = s.get("name") or s.get("title") or f"سرویس {sid}"
        if sid is None:
            continue
        rows.append([btn(f"🧩 {name}", f"{prefix}:{sid}")])
    return rows, svcs


def _subscription_url(user):
    sub = str(user.get("subscription_url") or user.get("sub") or "").strip()
    if not sub:
        return ""
    if sub.startswith("/") and not sub.startswith("//") and _subscription_base_url:
        return _subscription_base_url + sub
    return sub


def _show_user_credentials(token, chat_id, user, uname, action):
    nav = kb([[btn("« بازگشت به کاربر", f"open:{uname}")]])
    name = escape(uname)
    if action == "sub":
        sub = _subscription_url(user)
        text = (f"🔗 <b>لینک اشتراک {name}</b>\n<code>{escape(sub)}</code>" if sub
                else "لینک اشتراک برای این کاربر در پنل موجود نیست.")
        send(token, chat_id, text, nav)
        return

    # Rebecca returns share URIs as links[] in GET /api/user/{username}.
    # Reading these doesn't request/import the user's subscription profile.
    raw_links = user.get("links")
    links = list(dict.fromkeys(link.strip() for link in raw_links
                               if isinstance(link, str) and "://" in link)) if isinstance(raw_links, list) else []
    if not links:
        send(token, chat_id, "کانفیگی برای این کاربر در پنل موجود نیست.", nav)
        return
    title = f"📱 <b>کانفیگ‌های {name} ({len(links)})</b>"
    text = title + "\n\n" + "\n\n".join(f"<code>{escape(link)}</code>" for link in links)
    if len(text.encode("utf-16-le")) // 2 <= 3900:
        send(token, chat_id, text, nav)
    elif not _send_document(token, chat_id, "vpn-configs.txt",
                            ("\n".join(links) + "\n").encode("utf-8"), title):
        send(token, chat_id, "❌ ارسال فایل کانفیگ‌ها ناموفق بود. دوباره تلاش کنید.", nav)


def _show_create_menu(token, chat_id, message_id=None):
    CONV.clear(chat_id)
    safe_edit(token, chat_id, message_id,
              "➕ <b>ساخت کاربر جدید</b>\nنوع اکانت را انتخاب کنید:",
              kb([[btn("عادی", "create:normal"), btn("در انتظار (onhold)", "create:onhold")], back_btn()]))


def _prompt_create_gb(token, chat_id, data):
    CONV.set(chat_id, "create_gb", data)
    send(token, chat_id,
         "📊 حجم اکانت را به گیگابایت بفرستید (مثلاً 50). برای نامحدود عدد 0 را بفرستید.",
         kb([back_btn("m:create")]))


def _create_in_panel(api: PanelAPI, payload, service_id):
    if service_id is not None:
        try:
            sid = int(service_id)
        except (TypeError, ValueError):
            sid = service_id
        payload = {**payload, "service_ids": [sid], "service_id": sid}
        try:
            return api.create_user_v2(payload)
        except PanelError as e:
            # Don't switch endpoints on validation errors, conflicts or uncertain writes.
            if e.status not in (404, 405, 501):
                raise
    return api.create_user(payload)


def _do_create_user(token, chat_id, api: PanelAPI, data, admin_username, cfg, service_id=None):
    gb, days, onhold = data["gb"], data["days"], data["onhold"]
    if onhold and days <= 0:
        send(token, chat_id, "❗️ مدت اکانت onhold باید بیشتر از صفر باشد.", kb([back_btn("m:create")]))
        return
    payload = {"data_limit": to_bytes_gb(gb) if gb > 0 else 0,
               "status": "on_hold" if onhold else "active"}
    if onhold:
        payload.update(expire=0, on_hold_expire_duration=days * 86400)
    else:
        payload["expire"] = now_epoch() + days * 86400 if days > 0 else 0

    try:
        if data.get("auto_name"):
            # Use the shop's allocator with this bot admin's effective prefix/key.
            # Select at submit time; a customer or another admin chat may create
            # between the scan and POST, so handle Rebecca's duplicate response.
            from shop import next_username
            prefix = (cfg.get("shop_prefix") or "ST").strip() or "ST"
            uname = next_username(api, prefix, strict=True)
            number = int(uname[len(prefix):])
            for attempt in range(10):
                uname = f"{prefix}{number + attempt}"
                try:
                    res = _create_in_panel(api, {**payload, "username": uname}, service_id)
                    break
                except PanelError as e:
                    if e.status != 409 or attempt == 9:
                        raise
        else:
            uname = data["uname"]
            res = _create_in_panel(api, {**payload, "username": uname}, service_id)
    except PanelError as e:
        send(token, chat_id, f"❌ خطا در ساخت کاربر: {escape(e.message)}", kb([back_btn("m:create")]))
        return

    _invalidate_stats(admin_username)
    duration = "نامحدود" if days == 0 else f"{days} روز" + (" پس از فعال‌سازی" if onhold else "")
    txt = (f"✅ کاربر <b>{escape(uname)}</b> ساخته شد.\n"
           f"📊 حجم: {'نامحدود' if gb == 0 else f'{gb:g} گیگ'}\n"
           f"⏳ زمان: {duration}\n"
           f"نوع: {'در انتظار (onhold)' if onhold else 'عادی'}")
    if int(chat_id) > 0:  # Telegram private chat IDs are positive.
        sub = _subscription_url(res)
        if not sub:
            try:
                sub = _subscription_url(api.get_user(uname))
            except PanelError:
                pass  # The user was created even if the immediate read failed.
        if sub:
            txt += f"\n🔗 لینک:\n<code>{escape(sub)}</code>"
    send(token, chat_id, txt, kb([[btn("مشاهده کاربر", f"open:{uname}")], back_btn()]))


def _do_full_renew(token, chat_id, api: PanelAPI, uname, gb, days, service_id):
    """Full renewal: reset usage, set new data limit, new expiry, optional service.

    BUG FIX: this did `payload = dict(u)` and PUT the ENTIRE user object back,
    including server-owned fields (`used_traffic`, `online_at`, `links`,
    `subscription_url`, `lifetime_used_traffic`, `admin`, `created_at`, …).
    The Rebecca PUT endpoint takes a partial field set, so echoing the whole
    object back could overwrite server state and, in particular, writing
    `used_traffic: 0` in the same request as the reset raced with the
    `/reset` call. Only the fields being changed are sent now, and the usage
    reset is issued FIRST so the new limit is never applied to stale usage.
    """
    now = now_epoch()
    payload = {
        "data_limit": to_bytes_gb(gb) if gb > 0 else 0,
        "expire": (now + int(days) * 86400) if days > 0 else 0,
        "status": "active",
    }
    if service_id is not None:
        try:
            sid_int = int(service_id)
        except (TypeError, ValueError):
            sid_int = service_id
        payload["service_ids"] = [sid_int]
        payload["service_id"] = sid_int

    try:
        # Reset usage before re-arming the limit, not after.
        try:
            api.reset_usage(uname)
        except PanelError:
            pass
        api.update_user(uname, payload)
    except PanelError as e:
        send(token, chat_id, f"❌ خطا در تمدید: {e.message}", kb([back_btn("m:users")]))
        return
    _invalidate_stats(None)
    send(token, chat_id,
         f"✅ کاربر <b>{uname}</b> کامل تمدید شد.\n"
         f"📊 حجم: {'نامحدود' if gb == 0 else f'{gb:g} گیگ'}\n"
         f"⏳ زمان: {'نامحدود' if days == 0 else f'{int(days)} روز'} از حالا\n"
         f"♻️ مصرف صفر شد.",
         kb([[btn("مشاهده کاربر", f"open:{uname}")], back_btn()]))


# ---- stats ---------------------------------------------------------------

_stats_cache: dict = {}
_stats_cache_lock = threading.Lock()
_STATS_TTL = int(os.environ.get("STATS_CACHE_TTL", "60"))


def _collect_stats(api: PanelAPI, admin_username: str) -> dict:
    """Walk the admin's users once and tally them (cached for _STATS_TTL)."""
    now = time.time()
    hit = _stats_cache.get(admin_username)
    if hit and hit[1] > now:
        return hit[0]

    counters = {"total": 0, "active": 0, "disabled": 0, "limited": 0,
                "expired": 0, "onhold": 0, "used_total": 0}
    key_by_status = {"active": "active", "disabled": "disabled",
                     "limited": "limited", "expired": "expired",
                     "on_hold": "onhold"}
    for u in api.iter_all_users():
        counters["total"] += 1
        st = str(user_field(u, "status", default="")).lower()
        k = key_by_status.get(st)
        if k:
            counters[k] += 1
        counters["used_total"] += int(
            user_field(u, "used_traffic", "usedTraffic", "used", default=0) or 0)

    with _stats_cache_lock:
        _stats_cache[admin_username] = (counters, now + _STATS_TTL)
    return counters


def _show_stats(token, chat_id, message_id, api: PanelAPI, admin_username):
    """Render the admin stats screen.

    PERF FIX: this downloaded EVERY user of the admin from the panel, page by
    page, on every tap of 📊 آمار *and* on every tap of 🔄 بروزرسانی — with the
    old 200-per-page limit that is 15+ sequential HTTPS calls for a 3000-user
    admin, all on one blocking worker thread. Admins hammering refresh could
    single-handedly exhaust the (then 8-slot) worker pool and freeze the bot
    for every customer.

    The tally is now cached per admin for 60 s (override with STATS_CACHE_TTL)
    and the "typing…" indicator is only sent when we actually have to go to the
    network.
    """
    cached = _stats_cache.get(admin_username)
    fresh = bool(cached and cached[1] > time.time())
    if not fresh:
        typing(token, chat_id)

    try:
        c = _collect_stats(api, admin_username)
    except PanelError as e:
        safe_edit(token, chat_id, message_id, f"خطا در دریافت آمار: {e.message}", kb([back_btn()]))
        return

    sales = _sales_stats(admin_username) or {}
    txt = (
        "📊 <b>آمار شما</b>\n\n"
        f"👥 کل کاربران: <b>{c['total']}</b>\n"
        f"🟢 فعال: {c['active']}\n"
        f"🔴 غیرفعال: {c['disabled']}\n"
        f"🟡 حجم‌تمام: {c['limited']}\n"
        f"🟠 منقضی: {c['expired']}\n"
        f"⏸ در انتظار: {c['onhold']}\n"
        f"📦 مجموع مصرف: {bytes_to_gb(c['used_total']):.1f} گیگ\n\n"
        "💰 <b>فروش (از طریق ربات/صفحه تمدید)</b>\n"
        f"امروز: {sales.get('today_amount', 0):,} ت ({sales.get('today_count', 0)} سفارش)\n"
        f"این ماه: {sales.get('month_amount', 0):,} ت ({sales.get('month_count', 0)} سفارش)\n"
        f"کل: {sales.get('total_amount', 0):,} ت ({sales.get('total_count', 0)} سفارش)"
    )
    safe_edit(token, chat_id, message_id, txt, kb([[btn("🔄 بروزرسانی", "m:stats_force")], back_btn()]))


def _invalidate_stats(admin_username: str = None):
    with _stats_cache_lock:
        if admin_username:
            _stats_cache.pop(admin_username, None)
        else:
            _stats_cache.clear()


# ---- broadcast / private message ----------------------------------------

_background = None
_background_lock = threading.Lock()


def run_background(fn, *args, **kwargs):
    """Run a long job (broadcast, bulk edit, backup) OFF the update workers.

    PERF FIX: `_do_broadcast` and `_do_bulk_add` ran inline on the thread that
    was handling the admin's Telegram update. A broadcast to 2000 customers
    (2000 sendMessage calls + a 50 ms sleep each) occupied that worker for
    ~4 minutes; a bulk "add data to all users" ran one PUT per user with a
    30 ms sleep and could hold it for far longer. With only 8 workers, two or
    three of those froze the bot for everyone. They now run on a dedicated
    small pool and report progress back to the admin.
    """
    global _background
    if _background is None:
        with _background_lock:
            if _background is None:
                from concurrent.futures import ThreadPoolExecutor
                _background = ThreadPoolExecutor(max_workers=4,
                                                 thread_name_prefix="bot-bg")
    return _background.submit(_guard, fn, *args, **kwargs)


def _guard(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except Exception as exc:
        import traceback
        print(f"[bot-bg] {getattr(fn, '__name__', fn)} failed: {exc}")
        traceback.print_exc()


def _do_broadcast(token, chat_id, api, admin_username, text):
    """Queue a broadcast; the actual sending happens in the background."""
    from user_registry import get_admin_chat_ids
    ids = get_admin_chat_ids(admin_username)
    if not ids:
        send(token, chat_id,
             "هنوز هیچ کاربری در ربات ثبت‌نام نکرده است. (کاربران با ارسال لینک ساب ثبت می‌شوند.)",
             kb([back_btn()]))
        return
    send(token, chat_id, f"⏳ ارسال پیام همگانی برای {len(ids)} کاربر آغاز شد...")
    run_background(_broadcast_worker, token, chat_id, ids, text)


def _broadcast_worker(token, admin_chat_id, ids, text):
    """
    Send to every registered user.

    FIX: the old loop slept a flat 0.05 s (=20 msg/s) and ignored Telegram's
    429 replies entirely, so long broadcasts got throttled and silently
    dropped messages. tg_client now honours `retry_after`, and the pacing is
    set to Telegram's documented ~25 messages/second ceiling for bulk sends.
    Users who have blocked the bot (403) are counted separately instead of
    being reported as generic failures.
    """
    ok = blocked = failed = 0
    body = f"📢 <b>اطلاعیه</b>\n\n{text}"
    for i, cid in enumerate(ids, 1):
        r = send(token, cid, body)
        if r and r.get("ok"):
            ok += 1
        elif r and r.get("error_code") == 403:
            blocked += 1
        else:
            failed += 1
        if i % 200 == 0:
            send(token, admin_chat_id, f"… {i}/{len(ids)} ارسال شد")
        time.sleep(0.04)
    send(token, admin_chat_id,
         f"✅ پیام همگانی تمام شد.\n"
         f"موفق: {ok} | مسدودکرده ربات: {blocked} | ناموفق: {failed} | کل: {len(ids)}",
         kb([back_btn()]))


def _do_private_message(token, chat_id, target_username, text):
    from user_registry import get_chat_id_for_user
    cid = get_chat_id_for_user(target_username)
    if not cid:
        send(token, chat_id, f"کاربر «{target_username}» در ربات ثبت‌نام نکرده است.", kb([back_btn()]))
        return
    r = send(token, cid, f"✉️ <b>پیام از پشتیبانی</b>\n\n{text}")
    if r and r.get("ok"):
        send(token, chat_id, "✅ پیام ارسال شد.", kb([back_btn()]))
    else:
        send(token, chat_id, "❌ ارسال ناموفق بود.", kb([back_btn()]))


# ---- bulk ----------------------------------------------------------------

def _bulk_action(token, cb_id, chat_id, message_id, api, admin_username, action):
    if action == "enableall":
        api.activate_all_users(admin_username)
        answer(token, cb_id, "همه فعال شدند ✅", alert=True)
        return
    if action == "disableall":
        answer(token, cb_id)
        safe_edit(token, chat_id, message_id,
             "⚠️ آیا از غیرفعال‌کردن <b>همه‌ی</b> کاربران خود مطمئن هستید؟",
             kb([[btn("✅ بله", "bulk:disableconfirm"), btn("« انصراف", "m:bulk")]]))
        return
    if action == "disableconfirm":
        api.disable_all_users(admin_username)
        answer(token, cb_id, "همه غیرفعال شدند ✅", alert=True)
        safe_edit(token, chat_id, message_id, "🔴 همه‌ی کاربران غیرفعال شدند.", kb([back_btn()]))
        return
    if action == "adddata":
        answer(token, cb_id)
        CONV.set(chat_id, "bulk_adddata", {})
        send(token, chat_id, "➕ چند گیگابایت به حجم <b>همه‌ی</b> کاربران اضافه شود؟")
        return
    if action == "addtime":
        answer(token, cb_id)
        CONV.set(chat_id, "bulk_addtime", {})
        send(token, chat_id, "➕ چند روز به زمان <b>همه‌ی</b> کاربران اضافه شود؟")
        return
    answer(token, cb_id)


def _do_bulk_add(token, chat_id, api: PanelAPI, admin_username, state, val):
    """Queue a bulk add-data / add-time; the work runs in the background."""
    send(token, chat_id, "⏳ در حال اعمال روی همه‌ی کاربران... (نتیجه را همینجا اعلام می‌کنم)")
    run_background(_bulk_add_worker, token, chat_id, api, admin_username, state, val)


def _bulk_add_worker(token, chat_id, api: PanelAPI, admin_username, state, val):
    """
    FIXES
    -----
    * Ran inline on a bot worker thread for minutes (see run_background).
    * `payload = dict(u)` PUT the *entire* user object back — including
      server-computed fields like `used_traffic`, `online_at`, `sub_updated_at`
      and `links`. On the Rebecca API that can reset counters or clobber state.
      Only the field being changed is sent now.
    * `time.sleep(0.03)` between every user regardless of how long the PUT took;
      with 3000 users that alone is 90 s of pure sleeping. Updates now run
      through a small thread pool (8 concurrent PUTs) instead.
    * Users are collected up front so the pager is not held open across
      thousands of mutating writes (the old code paged and wrote at the same
      time, so users created/moved mid-run were silently skipped or hit twice).
    """
    from concurrent.futures import ThreadPoolExecutor

    now = now_epoch()
    try:
        users = list(api.iter_all_users())
    except PanelError as e:
        send(token, chat_id, f"❌ خطا در دریافت کاربران: {e.message}", kb([back_btn()]))
        return

    def _apply(u):
        uname = user_field(u, "username", default="")
        if not uname:
            return None
        payload = {}
        if state == "bulk_adddata":
            cur = int(user_field(u, "data_limit", "dataLimit", default=0) or 0)
            if cur <= 0:      # unlimited accounts are skipped by design
                return None
            payload["data_limit"] = cur + to_bytes_gb(val)
        else:
            e = user_field(u, "expire", "expire_date", default=0) or 0
            try:
                e = int(float(e))
                if e > 10_000_000_000:
                    e //= 1000
            except Exception:
                e = 0
            if e <= 0:        # never-expiring accounts are skipped by design
                return None
            payload["expire"] = max(e, now) + int(val) * 86400
        api.update_user(uname, payload)
        return uname

    ok = fail = skipped = 0
    with ThreadPoolExecutor(max_workers=8, thread_name_prefix="bulk") as pool:
        for result in pool.map(lambda u: _safe_apply(_apply, u), users):
            if result is _SKIPPED:
                skipped += 1
            elif result is _FAILED:
                fail += 1
            else:
                ok += 1

    unit = "گیگ" if state == "bulk_adddata" else "روز"
    send(token, chat_id,
         f"✅ {val:g} {unit} اضافه شد.\n"
         f"موفق: {ok} | رد شده (نامحدود): {skipped} | ناموفق: {fail} | کل: {len(users)}",
         kb([back_btn()]))


_SKIPPED = object()
_FAILED = object()


def _safe_apply(fn, u):
    try:
        r = fn(u)
    except Exception:
        return _FAILED
    return _SKIPPED if r is None else r


# ---- referral (admin view) ----------------------------------------------

def _show_referral_admin(token, chat_id, message_id, admin_username):
    enabled = str(settings.get_setting(admin_username, "referral_enabled", "0")) == "1"
    pct = int(settings.get_setting(admin_username, "referral_percent", 0) or 0)
    txt = (
        "🎁 <b>سیستم دعوت دوستان</b>\n\n"
        f"وضعیت: {'🟢 فعال' if enabled else '🔴 غیرفعال'}\n"
        f"درصد تخفیف: {pct}%\n\n"
        "با فعال‌کردن این بخش، کاربر جدید با وارد کردن نام کاربری معرف، تخفیف می‌گیرد "
        "و معرف هم در تمدید بعدی همان درصد تخفیف را دریافت می‌کند."
    )
    safe_edit(token, chat_id, message_id, txt, kb([
        [btn("🔴 غیرفعال کن" if enabled else "🟢 فعال کن", "ref:toggle")],
        [btn("✏️ تنظیم درصد تخفیف", "ref:percent")],
        [btn("✏️ تنظیم متن", "ref:text")],
        back_btn(),
    ]))


def _referral_action(token, cb_id, chat_id, message_id, admin_username, action):
    if action == "toggle":
        cur = str(settings.get_setting(admin_username, "referral_enabled", "0")) == "1"
        settings.set_setting(admin_username, "referral_enabled", "0" if cur else "1")
        answer(token, cb_id, "تغییر کرد ✅")
        _show_referral_admin(token, chat_id, message_id, admin_username)
        return
    if action == "percent":
        answer(token, cb_id)
        CONV.set(chat_id, "set_ref_percent", {})
        send(token, chat_id, "✏️ درصد تخفیف را بفرستید (فقط عدد، مثلاً 10):")
        return
    if action == "text":
        answer(token, cb_id)
        CONV.set(chat_id, "set_ref_text", {})
        send(token, chat_id, "✏️ متن بخش دعوت را بفرستید:")
        return
    answer(token, cb_id)


# ---- settings (card / prices / plans / warning texts) --------------------

def _show_settings(token, chat_id, message_id, admin_username, cfg):
    eff = settings.get_effective_config(admin_username, cfg)
    prices = eff.get("prices", {})
    price_str = " | ".join(f"{d}روز:{p:,}" for d, p in sorted(prices.items()))
    force_ch = eff.get("force_channel") or ""
    force_enabled = eff.get("force_channel_enabled", False)
    txt = (
        "🛠 <b>تنظیمات</b>\n\n"
        f"💳 کارت: <code>{eff.get('card_number', '-')}</code>\n"
        f"👤 صاحب کارت: {eff.get('card_holder', '-')}\n"
        f"🏦 بانک: {eff.get('card_bank', '-')}\n"
        f"💰 قیمت هر گیگ: {price_str or '-'}\n"
        f"📅 پلن‌ها: {', '.join(str(x) for x in eff.get('plans', []))} روز\n\n"
        f"⏰ آستانه هشدار زمان: {eff.get('warn_days')} روز\n"
        f"📉 آستانه هشدار حجم: {eff.get('warn_gb')} گیگ\n\n"
        f"🔒 عضویت اجباری کانال: {'🟢 فعال' if force_enabled else '🔴 غیرفعال'}\n"
        + (f"   کانال: <code>{force_ch}</code>\n" if force_ch else "")
        + "\nاین تنظیمات هم در ربات و هم در صفحه‌ی تمدید اعمال می‌شوند."
    )
    safe_edit(token, chat_id, message_id, txt, kb([
        [btn("💳 شماره کارت", "set:card_number"), btn("👤 صاحب کارت", "set:card_holder")],
        [btn("🏦 بانک", "set:card_bank"), btn("💰 قیمت‌ها", "set:prices")],
        [btn("📅 پلن‌ها", "set:plans")],
        [btn("⏰ متن هشدار زمان", "set:warn_days_text"), btn("📉 متن هشدار حجم", "set:warn_gb_text")],
        [btn("⏰ آستانه زمان", "set:warn_days"), btn("📉 آستانه حجم", "set:warn_gb")],
        [btn("🔒 عضویت اجباری کانال", "set:force_channel")],
        back_btn(),
    ]))


_SET_PROMPTS = {
    "card_number": "💳 شماره کارت جدید را بفرستید:",
    "card_holder": "👤 نام صاحب کارت را بفرستید:",
    "card_bank": "🏦 نام بانک را بفرستید:",
    "prices": "💰 قیمت هر گیگ را برای هر پلن بفرستید، به این شکل:\n<code>30:10000, 60:11000, 90:12000</code>",
    "plans": "📅 پلن‌ها را به روز بفرستید، با کاما جدا کنید:\n<code>30, 60, 90</code>",
    "warn_days_text": "⏰ متن هشدار «نزدیک اتمام زمان» را بفرستید.\nاز {days} برای تعداد روز استفاده کنید.",
    "warn_gb_text": "📉 متن هشدار «نزدیک اتمام حجم» را بفرستید.\nاز {gb} برای مقدار گیگ استفاده کنید.",
    "warn_days": "⏰ آستانه‌ی هشدار زمان را به روز بفرستید (مثلاً 1):",
    "warn_gb": "📉 آستانه‌ی هشدار حجم را به گیگ بفرستید (مثلاً 1):",
    "force_channel": "🔒 <b>عضویت اجباری کانال</b>\n\n"
                     "آیدی کانال را بفرستید. مثال:\n"
                     "<code>@mychannel</code> یا <code>-1001234567890</code>\n\n"
                     "برای غیرفعال‌کردن، عدد <code>0</code> را بفرستید.",
}


def _settings_action(token, cb_id, chat_id, message_id, admin_username, cfg, key):
    if key not in _SET_PROMPTS:
        answer(token, cb_id)
        return
    answer(token, cb_id)
    CONV.set(chat_id, f"set_{key}", {})
    send(token, chat_id, _SET_PROMPTS[key])


def _apply_setting_input(token, chat_id, admin_username, state, text):
    key = state[len("set_"):]
    try:
        if key == "prices":
            prices = {}
            for part in text.replace("،", ",").split(","):
                if ":" in part:
                    d, p = part.split(":")
                    prices[int(d.strip())] = int(p.strip().replace(",", ""))
            if not prices:
                raise ValueError
            settings.set_setting(admin_username, "prices", prices)
            msg = "✅ قیمت‌ها ذخیره شد."
        elif key == "plans":
            plans = [int(x.strip()) for x in text.replace("،", ",").split(",") if x.strip()]
            if not plans:
                raise ValueError
            settings.set_setting(admin_username, "plans", plans)
            msg = "✅ پلن‌ها ذخیره شد."
        elif key in ("warn_days", "warn_gb"):
            val = float(text.replace(",", ""))
            settings.set_setting(admin_username, key, val)
            msg = "✅ آستانه ذخیره شد."
        elif key == "ref_percent":
            val = int(float(text.replace(",", "")))
            settings.set_setting(admin_username, "referral_percent", val)
            msg = f"✅ درصد تخفیف روی {val}% تنظیم شد."
        elif key == "ref_text":
            settings.set_setting(admin_username, "referral_text", text)
            msg = "✅ متن دعوت ذخیره شد."
        elif key == "force_channel":
            text = text.strip()
            if text == "0" or text == "":
                settings.set_setting(admin_username, "force_channel_enabled", "0")
                msg = "🔒 عضویت اجباری کانال <b>غیرفعال</b> شد."
            else:
                # Normalize channel ID
                if not text.startswith("@") and not text.startswith("-"):
                    text = "@" + text
                settings.set_setting(admin_username, "force_channel", text)
                settings.set_setting(admin_username, "force_channel_enabled", "1")
                msg = f"✅ عضویت اجباری کانال <b>فعال</b> شد.\nکانال: <code>{text}</code>\n\nاز این پس کاربران باید عضو این کانال باشند."
        else:  # card_number, card_holder, card_bank, warn_*_text
            settings.set_setting(admin_username, key, text)
            msg = "✅ ذخیره شد. (در ربات و صفحه تمدید اعمال شد.)"
    except Exception:
        send(token, chat_id, "❗️ ورودی نامعتبر بود. دوباره تلاش کنید.", kb([back_btn("m:settings")]))
        return
    send(token, chat_id, msg, kb([[btn("« تنظیمات", "m:settings")], back_btn()]))


# ==========================================================================
#  SYSTEM SETTINGS (sudo only) — "🔧 تنظیمات سیستم"
# ==========================================================================

_SYS_THEMES = ("gradient", "matte", "happy", "dark", "minimal")


def is_admin_onboarding_input(msg, token):
    """Keep credential prompts ahead of legacy free-text handlers."""
    sender = str((msg.get("from") or {}).get("id", ""))
    chat_id = (msg.get("chat") or {}).get("id")
    if str(chat_id) != sender or not _can_add_admin(token, sender):
        return False
    with CONV.admin_scope(token, _admin_username_for_token(token), sender):
        conv = CONV.get(chat_id)
        return bool(conv and conv["state"].startswith("onboard_admin_"))


def _admin_onboard_kb():
    return kb([[btn("لغو", "onboard:cancel")]])


def _admin_onboard_input(token, chat_id, from_id, message_id, text, conv):
    state, data = conv["state"], conv["data"]
    if str(chat_id) != from_id or not _can_add_admin(token, from_id):
        CONV.clear(chat_id)
        return
    if state in ("onboard_admin_key", "onboard_admin_token") and text and message_id:
        # Best effort: bot chats are not end-to-end encrypted. Never echo either secret.
        tg("deleteMessage", token, chat_id=chat_id, message_id=message_id)
    if time.monotonic() > data["until"]:
        CONV.clear(chat_id)
        send(token, chat_id, "مهلت ثبت ادمین تمام شد. دوباره شروع کنید.", _admin_onboard_kb())
        return
    if state == "onboard_admin_name":
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", text):
            send(token, chat_id, "نام دقیق حساب Rebecca را بفرستید.", _admin_onboard_kb())
            return
        data["name"] = text
        CONV.set(chat_id, "onboard_admin_ids", data)
        send(token, chat_id, "آیدی عددی تلگرام ادمین را بفرستید. چند آیدی را با کاما جدا کنید.", _admin_onboard_kb())
    elif state == "onboard_admin_ids":
        ids = list(dict.fromkeys(text.replace("،", " ").replace(",", " ").split()))
        if not ids or any(not re.fullmatch(r"[1-9][0-9]{0,15}", cid) for cid in ids):
            send(token, chat_id, "آیدی عددی معتبر بفرستید.", _admin_onboard_kb())
            return
        data["ids"] = ids
        CONV.set(chat_id, "onboard_admin_key", data)
        send(token, chat_id,
             "کلید API اختصاصی حساب Rebecca را بفرستید، نه رمز حساب. چت بات رمزگذاری سرتاسری ندارد؛ "
             "در صورت ترجیح، از فرم پنل ۸۰۸۸ استفاده کنید.", _admin_onboard_kb())
    elif state == "onboard_admin_key":
        if not text or len(text) > 2048 or any(c.isspace() for c in text):
            send(token, chat_id, "یک کلید API معتبر بفرستید.", _admin_onboard_kb())
            return
        data["key"] = text
        CONV.set(chat_id, "onboard_admin_token", data)
        send(token, chat_id, "توکن اختصاصی بات این ادمین از BotFather را بفرستید.", _admin_onboard_kb())
    elif state == "onboard_admin_token":
        if not re.fullmatch(r"[1-9][0-9]*:[A-Za-z0-9_-]{20,100}", text):
            send(token, chat_id, "فرمت توکن بات معتبر نیست.", _admin_onboard_kb())
            return
        CONV.clear(chat_id)
        error = _add_admin(data["name"], data["key"], text, data["ids"])
        nav = kb([[btn("➕ ثبت ادمین دیگر", "onboard:add")], back_btn("m:sys_settings")])
        if error:
            send(token, chat_id, f"❌ {escape(error)}", nav)
        else:
            send(token, chat_id, f"✅ ادمین <b>{escape(data['name'])}</b> ثبت شد. "
                 "تا چند ثانیه دیگر در بات جدید /start بزنید.", nav)


def _show_sys_settings(token, chat_id, message_id, admin_username, cfg, show_add=False):
    eff = settings.get_effective_config(admin_username, cfg)
    domain = (eff.get("shop_domain") or "").rstrip("/")
    txt = (
        "🔧 <b>تنظیمات سیستم</b> (فقط سودو)\n\n"
        f"🌐 دامنه وب‌اپ: <code>{domain or '— تنظیم نشده —'}</code>\n"
        f"🎨 تم پنل ادمین: <code>{eff.get('admin_bot_theme', 'gradient')}</code>\n"
        f"🎨 تم پنل کاربر: <code>{eff.get('user_bot_theme', 'gradient')}</code>\n"
        f"📏 حداقل خرید: <code>{eff.get('minGB', 1)} گیگ</code>\n"
        f"📏 حداکثر خرید: <code>{eff.get('maxGB', 1000)} گیگ</code>\n\n"
        "این مقادیر روی آدرس وب‌اپ و صفحات خرید اعمال می‌شوند."
    )
    rows = [
        [btn("🌐 دامنه وب‌اپ", "sys:shop_domain")],
        [btn("🎨 تم پنل ادمین", "sys:admin_bot_theme"),
         btn("🎨 تم پنل کاربر", "sys:user_bot_theme")],
        [btn("📏 حداقل خرید (گیگ)", "sys:min_gb"),
         btn("📏 حداکثر خرید (گیگ)", "sys:max_gb")],
    ]
    if show_add:
        rows.append([btn("➕ افزودن ادمین", "onboard:add")])
    safe_edit(token, chat_id, message_id, txt, kb(rows + [back_btn()]))


_SYS_PROMPTS = {
    "shop_domain": "🌐 دامنه وب‌اپ را بفرستید. (فقط HTTPS و بدون / در انتها)\n"
                   "مثال:\n<code>https://sublink.1plusnet.ir</code>\n\n"
                   "برای پاک‌کردن، عدد <code>0</code> را بفرستید.",
    "admin_bot_theme": "🎨 تم پنل ادمین را بفرستید:\n"
                       "<code>gradient | matte | happy | dark | minimal</code>",
    "user_bot_theme": "🎨 تم پنل کاربر را بفرستید:\n"
                      "<code>gradient | matte | happy | dark | minimal</code>",
    "min_gb": "📏 حداقل حجم قابل خرید را به گیگ بفرستید (مثلاً 10):",
    "max_gb": "📏 حداکثر حجم قابل خرید را به گیگ بفرستید (مثلاً 1000):",
}


def _sys_settings_action(token, cb_id, chat_id, message_id, admin_username, key):
    if key not in _SYS_PROMPTS:
        answer(token, cb_id)
        return
    answer(token, cb_id)
    CONV.set(chat_id, f"sysset_{key}", {})
    send(token, chat_id, _SYS_PROMPTS[key])


def _apply_sys_setting_input(token, chat_id, admin_username, state, text):
    key = state[len("sysset_"):]
    text = (text or "").strip()
    try:
        if key == "shop_domain":
            if text in ("0", ""):
                settings.set_setting(admin_username, "shop_domain", "")
                msg = "✅ دامنه وب‌اپ پاک شد."
            else:
                text = text.rstrip("/")
                if text.lower().startswith("http://"):
                    text = "https://" + text[7:]
                elif "://" not in text:
                    text = "https://" + text
                if not text.lower().startswith("https://"):
                    raise ValueError("must be https")
                settings.set_setting(admin_username, "shop_domain", text)
                msg = f"✅ دامنه وب‌اپ ذخیره شد: <code>{text}</code>"
        elif key in ("admin_bot_theme", "user_bot_theme"):
            if text not in _SYS_THEMES:
                raise ValueError("bad theme")
            settings.set_setting(admin_username, key, text)
            msg = f"✅ تم به <code>{text}</code> تغییر کرد."
        elif key in ("min_gb", "max_gb"):
            val = int(float(text.replace(",", "")))
            if val < 0:
                raise ValueError("negative")
            settings.set_setting(admin_username, "minGB" if key == "min_gb" else "maxGB", val)
            msg = f"✅ ذخیره شد: {val} گیگ."
        else:
            raise ValueError("unknown key")
    except Exception:
        send(token, chat_id, "❗️ ورودی نامعتبر بود. دوباره تلاش کنید.",
             kb([back_btn("m:sys_settings")]))
        return
    send(token, chat_id, msg, kb([[btn("« تنظیمات سیستم", "m:sys_settings")], back_btn()]))


# ==========================================================================
#  SHOP MANAGEMENT (from within the bot)
# ==========================================================================

import shop as _shop_mod


def _show_shop_menu(token, chat_id, message_id, admin_username, cfg, api: PanelAPI):
    """Display the shop management menu for this admin."""
    enabled = cfg.get("shop_enabled", False)
    prefix = cfg.get("shop_prefix", "ST")
    renewal_enabled = cfg.get("renewal_enabled", True)

    # list packages
    try:
        pkgs = _shop_mod.list_packages(admin_username)
    except Exception:
        pkgs = []

    pkg_count = len(pkgs)
    active_pkgs = sum(1 for p in pkgs if p.get("enabled"))

    txt = (
        "🛍 <b>مدیریت فروشگاه</b>\n\n"
        f"وضعیت فروشگاه: {'🟢 فعال' if enabled else '🔴 غیرفعال'}\n"
        f"بخش تمدید فرانت: {'🟢 فعال' if renewal_enabled else '🔴 غیرفعال'}\n"
        f"پیشوند نام‌گذاری: <code>{prefix}</code>\n"
        f"پکیج‌ها: {pkg_count} (فعال: {active_pkgs})\n"
    )
    safe_edit(token, chat_id, message_id, txt, kb([
        [btn("🔴 غیرفعال کردن فروشگاه" if enabled else "🟢 فعال کردن فروشگاه", "shop:toggle_shop")],
        [btn("🔴 قطع تمدید فرانت" if renewal_enabled else "🟢 فعال تمدید فرانت", "shop:toggle_renewal")],
        [btn("✏️ تغییر پیشوند", "shop:prefix")],
        [btn("🧩 مدیریت پکیج‌ها", "shop:pkgs")],
        back_btn(),
    ]))


def _shop_action(token, cb_id, chat_id, message_id, admin_username, cfg, api, action):
    """Handle shop-level actions."""
    if action == "toggle_shop":
        cur = str(settings.get_setting(admin_username, "shop_enabled", "0")) == "1"
        settings.set_setting(admin_username, "shop_enabled", "0" if cur else "1")
        answer(token, cb_id, "وضعیت فروشگاه تغییر کرد ✅")
        # refresh cfg
        new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
        _show_shop_menu(token, chat_id, message_id, admin_username, new_cfg, api)
        return

    if action == "toggle_renewal":
        cur = str(settings.get_setting(admin_username, "renewal_enabled", "1")) != "0"
        settings.set_setting(admin_username, "renewal_enabled", "0" if cur else "1")
        answer(token, cb_id, "وضعیت تمدید فرانت تغییر کرد ✅")
        new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
        _show_shop_menu(token, chat_id, message_id, admin_username, new_cfg, api)
        return

    if action == "prefix":
        CONV.set(chat_id, "shop_prefix", {})
        prefix = cfg.get("shop_prefix", "ST")
        send(token, chat_id,
             f"✏️ پیشوند فعلی: <code>{prefix}</code>\n\nپیشوند جدید را بفرستید (بدون فاصله، حداکثر ۱۰ کاراکتر):\nمثلاً: <code>Mt</code>")
        return

    if action == "pkgs":
        _show_packages_list(token, chat_id, message_id, admin_username, api)
        return

    answer(token, cb_id)


def _show_packages_list(token, chat_id, message_id, admin_username, api: PanelAPI):
    """Show the list of packages with action buttons."""
    try:
        pkgs = _shop_mod.list_packages(admin_username)
    except Exception:
        pkgs = []

    # get services for display
    try:
        svcs = api.list_services() or []
    except Exception:
        svcs = []
    svc_names = {}
    for s in svcs:
        sid = str(s.get("id") or s.get("service_id") or s.get("_id") or "")
        name = s.get("name") or s.get("title") or f"سرویس {sid}"
        svc_names[sid] = name

    rows = []
    if not pkgs:
        txt = "🧩 <b>پکیج‌های سرویس</b>\n\nهنوز پکیجی تعریف نشده.\n\nبا افزودن پکیج، مشتریان می‌توانند سرویس خاصی را با قیمت اختصاصی انتخاب کنند."
    else:
        txt = f"🧩 <b>پکیج‌های سرویس</b> ({len(pkgs)} پکیج)\n\n"
        for i, p in enumerate(pkgs):
            sid = str(p.get("service_id", ""))
            svc_name = svc_names.get(sid, f"سرویس {sid}")
            status = "🟢" if p.get("enabled") else "⚪️"
            prices_str = ""
            for d, v in sorted(p.get("prices", {}).items()):
                prices_str += f" {d}روز:{int(v):,}ت"
            txt += f"{status} <b>{p['name']}</b> — {svc_name}\n   {prices_str}\n"
            if p.get("note"):
                txt += f"   📝 {p['note']}\n"
            txt += "\n"
            rows.append([
                btn(f"{'⚪️' if not p.get('enabled') else '🔴'} {'غیرفعال' if not p.get('enabled') else 'غیرفعال'}",
                    f"pkg:toggle:{p['id']}"),
                btn("✏️ ویرایش", f"pkg:edit:{p['id']}"),
                btn("🗑 حذف", f"pkg:del:{p['id']}"),
            ])

    rows.append([btn("➕ افزودن پکیج جدید", "pkg:add")])
    rows.append(back_btn("m:shop"))

    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _pkg_action(token, cb_id, chat_id, message_id, admin_username, cfg, api, data):
    """Handle package-level actions."""
    parts = data.split(":")
    action = parts[1] if len(parts) > 1 else ""

    if action == "add":
        # start package creation flow
        CONV.set(chat_id, "pkg_name", {"admin": admin_username, "edit_id": 0})
        send(token, chat_id,
             "🧩 <b>افزودن پکیج جدید</b>\n\n"
             "نام پکیج را بفرستید (مثلاً: V2Ray، OpenVPN، پرسرعت):")
        return

    if action == "toggle":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        pkg = _shop_mod.get_package(pkg_id)
        if not pkg or pkg["admin_username"] != admin_username:
            answer(token, cb_id, "پکیج یافت نشد", alert=True)
            return
        new_enabled = not pkg["enabled"]
        _shop_mod.update_package(pkg_id, pkg["name"], pkg["service_id"],
                                pkg["prices"], pkg.get("note", ""),
                                new_enabled, pkg.get("sort_order", 0))
        answer(token, cb_id, "وضعیت پکیج تغییر کرد ✅")
        _show_packages_list(token, chat_id, message_id, admin_username, api)
        return

    if action == "del":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        pkg = _shop_mod.get_package(pkg_id)
        if not pkg or pkg["admin_username"] != admin_username:
            answer(token, cb_id, "پکیج یافت نشد", alert=True)
            return
        # ask for confirmation
        safe_edit(token, chat_id, message_id,
             f"🗑 آیا از حذف پکیج <b>{pkg['name']}</b> مطمئن هستید؟",
             kb([
                 [btn("✅ بله، حذف کن", f"pkg:delconfirm:{pkg_id}")],
                 [btn("« انصراف", "shop:pkgs")],
             ]))
        return

    if action == "delconfirm":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        _shop_mod.delete_package(pkg_id)
        answer(token, cb_id, "پکیج حذف شد ✅")
        _show_packages_list(token, chat_id, message_id, admin_username, api)
        return

    if action == "edit":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        pkg = _shop_mod.get_package(pkg_id)
        if not pkg or pkg["admin_username"] != admin_username:
            answer(token, cb_id, "پکیج یافت نشد", alert=True)
            return
        # show edit options for this package
        try:
            svcs = api.list_services() or []
        except Exception:
            svcs = []
        sid = str(pkg.get("service_id", ""))
        svc_name = next((s.get("name") or s.get("title") for s in svcs
                        if str(s.get("id") or s.get("service_id") or "") == sid), f"سرویس {sid}")

        prices = pkg.get("prices", {})
        prices_str = ""
        for d in sorted(prices):
            prices_str += f"\n  {d}روز: {int(prices[d]):,} تومان/گیگ"

        txt = (
            f"✏️ <b>ویرایش پکیج: {pkg['name']}</b>\n\n"
            f"🧩 سرویس: {svc_name}\n"
            f"💰 قیمت‌ها:{prices_str}\n"
            f"📝 توضیح: {pkg.get('note') or '-'}\n"
            f"وضعیت: {'🟢 فعال' if pkg.get('enabled') else '⚪️ غیرفعال'}\n"
        )
        safe_edit(token, chat_id, message_id, txt, kb([
            [btn("✏️ تغییر نام", f"pkg:ename:{pkg_id}"), btn("🧩 تغییر سرویس", f"pkg:esvc:{pkg_id}")],
            [btn("💰 تغییر قیمت‌ها", f"pkg:eprice:{pkg_id}")],
            [btn("📝 تغییر توضیح", f"pkg:enote:{pkg_id}")],
            [btn("🔴 غیرفعال" if pkg.get("enabled") else "🟢 فعال", f"pkg:toggle:{pkg_id}")],
            back_btn("shop:pkgs"),
        ]))
        return

    # ---- edit sub-actions ----
    if action == "ename":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        CONV.set(chat_id, "pkg_ename", {"pkg_id": pkg_id, "admin": admin_username})
        send(token, chat_id, "✏️ نام جدید پکیج را بفرستید:")
        return

    if action == "esvc":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        # show service selection buttons
        rows, svcs = _service_buttons(api, f"pkg:esvc_sel:{pkg_id}")
        if not svcs:
            answer(token, cb_id, "سرویسی یافت نشد", alert=True)
            return
        safe_edit(token, chat_id, message_id, "🧩 سرویس جدید را انتخاب کنید:",
             kb(rows + [back_btn(f"pkg:edit:{pkg_id}")]))
        return

    if action == "esvc_sel":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        sid = parts[3] if len(parts) > 3 else ""
        pkg = _shop_mod.get_package(pkg_id)
        if not pkg or pkg["admin_username"] != admin_username:
            answer(token, cb_id, "پکیج یافت نشد", alert=True)
            return
        _shop_mod.update_package(pkg_id, pkg["name"], sid,
                                pkg["prices"], pkg.get("note", ""),
                                pkg.get("enabled", True), pkg.get("sort_order", 0))
        answer(token, cb_id, "سرویس تغییر کرد ✅")
        _show_packages_list(token, chat_id, message_id, admin_username, api)
        return

    if action == "eprice":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        CONV.set(chat_id, "pkg_eprice", {"pkg_id": pkg_id, "admin": admin_username})
        send(token, chat_id,
             "💰 قیمت‌های جدید را به این شکل بفرستید:\n"
             "<code>30:10000, 60:11000, 90:12000</code>\n\n"
             "(فقط پلن‌هایی که می‌خواهید تغییر دهید را بفرستید)")
        return

    if action == "enote":
        pkg_id = int(parts[2]) if len(parts) > 2 else 0
        CONV.set(chat_id, "pkg_enote", {"pkg_id": pkg_id, "admin": admin_username})
        send(token, chat_id, "📝 توضیح جدید را بفرستید (یا «-» برای پاک کردن):")
        return

    if action == "svc_sel":
        # service selected for a NEW package (from conversation state)
        service_id = parts[2] if len(parts) > 2 else ""
        conv = CONV.get(chat_id)
        if not conv or conv["state"] != "pkg_service":
            answer(token, cb_id)
            return
        data = conv["data"]
        CONV.clear(chat_id)
        answer(token, cb_id)
        _do_save_package_with_service(token, chat_id, admin_username, data, service_id)
        return

    if action == "svc_none":
        # no service for new package
        conv = CONV.get(chat_id)
        if not conv or conv["state"] != "pkg_service":
            answer(token, cb_id)
            return
        data = conv["data"]
        CONV.clear(chat_id)
        answer(token, cb_id)
        _do_save_package_with_service(token, chat_id, admin_username, data, "")
        return

    answer(token, cb_id)


def _do_save_package(token, chat_id, admin_username, api: PanelAPI, data):
    """Save a new or edited package after the conversation flow."""
    edit_id = data.get("edit_id", 0)
    name = data.get("name", "")
    prices = {}
    if data.get("p30"):
        prices[30] = data["p30"]
    if data.get("p60"):
        prices[60] = data["p60"]
    if data.get("p90"):
        prices[90] = data["p90"]
    note = data.get("note", "")

    if not prices:
        send(token, chat_id, "❗️ حداقل یک قیمت لازم است.", kb([[btn("« فروشگاه", "m:shop")]]))
        return

    # get service selection
    try:
        svcs = api.list_services() or []
    except Exception:
        svcs = []

    if not svcs:
        # no services -> create without service_id
        if edit_id:
            pkg = _shop_mod.get_package(edit_id)
            if pkg:
                _shop_mod.update_package(edit_id, name, pkg["service_id"],
                                        prices, note, pkg.get("enabled", True),
                                        pkg.get("sort_order", 0))
        else:
            _shop_mod.add_package(admin_username, name, "", prices, note)
        send(token, chat_id, f"✅ پکیج <b>{name}</b> ذخیره شد.",
             kb([[btn("🧩 پکیج‌ها", "shop:pkgs")], [btn("« فروشگاه", "m:shop")]]))
        return

    # show service selection
    rows, _ = _service_buttons(api, f"pkg:svc_sel")
    # store data for the next step
    data["prices"] = prices
    CONV.set(chat_id, "pkg_service", data)
    send(token, chat_id, "🧩 سرویس این پکیج را انتخاب کنید:",
         kb(rows + [[btn("❌ بدون سرویس", "pkg:svc_none")]]))
    return


def _do_save_package_with_service(token, chat_id, admin_username, data, service_id):
    """Final step: save package after service selection."""
    name = data.get("name", "")
    prices = data.get("prices", {})
    note = data.get("note", "")
    edit_id = data.get("edit_id", 0)

    if edit_id:
        _shop_mod.update_package(edit_id, name, service_id, prices, note, True, 0)
    else:
        _shop_mod.add_package(admin_username, name, service_id, prices, note)

    send(token, chat_id, f"✅ پکیج <b>{name}</b> ذخیره شد.",
         kb([[btn("🧩 پکیج‌ها", "shop:pkgs")], [btn("« فروشگاه", "m:shop")]]))


# ---- conversation handlers for package edit sub-actions ----

def _handle_pkg_edit_input(token, chat_id, admin_username, state, text, data):
    """Handle text input during package edit flows."""
    pkg_id = data.get("pkg_id", 0)
    pkg = _shop_mod.get_package(pkg_id)
    if not pkg or pkg["admin_username"] != admin_username:
        send(token, chat_id, "❌ پکیج یافت نشد.")
        return True

    if state == "pkg_ename":
        name = text.strip()
        if not name:
            send(token, chat_id, "❗️ نام نمی‌تواند خالی باشد.")
            return True
        _shop_mod.update_package(pkg_id, name, pkg["service_id"],
                                pkg["prices"], pkg.get("note", ""),
                                pkg.get("enabled", True), pkg.get("sort_order", 0))
        send(token, chat_id, f"✅ نام پکیج به <b>{name}</b> تغییر کرد.",
             kb([[btn("« پکیج‌ها", "shop:pkgs")]]))
        return True

    if state == "pkg_eprice":
        try:
            prices = {}
            for part in text.replace("،", ",").split(","):
                if ":" in part:
                    d, p = part.split(":")
                    prices[int(d.strip())] = int(p.strip().replace(",", ""))
            if not prices:
                raise ValueError
            _shop_mod.update_package(pkg_id, pkg["name"], pkg["service_id"],
                                    prices, pkg.get("note", ""),
                                    pkg.get("enabled", True), pkg.get("sort_order", 0))
            send(token, chat_id, "✅ قیمت‌ها بروزرسانی شد.",
                 kb([[btn("« پکیج‌ها", "shop:pkgs")]]))
        except Exception:
            send(token, chat_id, "❗️ فرمت نامعتبر. مثلاً: <code>30:10000, 60:11000</code>")
        return True

    if state == "pkg_enote":
        note = text.strip() if text.strip() != "-" else ""
        _shop_mod.update_package(pkg_id, pkg["name"], pkg["service_id"],
                                pkg["prices"], note,
                                pkg.get("enabled", True), pkg.get("sort_order", 0))
        send(token, chat_id, "✅ توضیح بروزرسانی شد.",
             kb([[btn("« پکیج‌ها", "shop:pkgs")]]))
        return True

    return False


# ==========================================================================
#  DISCOUNT CODES MANAGEMENT (admin side)
# ==========================================================================

def _show_discounts_menu(token, chat_id, message_id, admin_username):
    import shop as _sh
    codes = _sh.list_discount_codes(admin_username)
    txt = "🎟 <b>کدهای تخفیف</b>\n\n"
    if not codes:
        txt += "هنوز کد تخفیفی ساخته نشده."
    else:
        for c in codes[:15]:
            dtype = "درصد" if c["discount_type"] == "percent" else "تومان"
            used = c["used_count"]
            max_u = c["max_uses"]
            status = "🟢" if c["active"] and used < max_u else "🔴"
            txt += (f"{status} <code>{c['code']}</code> — {c['discount_value']} {dtype}\n"
                    f"   استفاده: {used}/{max_u}\n")
    rows = [
        [btn("➕ ساخت کد تخفیف", "disc:create")],
        [btn("🔄 لیست کدها", "disc:refresh")],
    ]
    # Add delete buttons for each code
    for c in codes[:10]:
        rows.append([btn(f"🗑 حذف {c['code']}", f"disc:del:{c['id']}")])
    rows.append(back_btn())
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _discount_action(token, cb_id, chat_id, message_id, admin_username, action):
    if action == "create":
        answer(token, cb_id)
        CONV.set(chat_id, "disc_code", {})
        send(token, chat_id,
             "🎟 <b>ساخت کد تخفیف جدید</b>\n\n"
             "ابتدا <b>کد</b> را بفرستید (مثلاً: SALE20):\n"
             "(یا «auto» برای تولید خودکار)")
        return

    if action == "refresh":
        answer(token, cb_id)
        _show_discounts_menu(token, chat_id, message_id, admin_username)
        return

    if action.startswith("del:"):
        code_id = int(action.split(":")[1])
        import shop as _sh
        _sh.delete_discount_code(code_id)
        answer(token, cb_id, "کد حذف شد ✅")
        _show_discounts_menu(token, chat_id, message_id, admin_username)
        return

    answer(token, cb_id)


# ==========================================================================
#  GIFT CODES MANAGEMENT (admin side)
# ==========================================================================

def _show_gifts_menu(token, chat_id, message_id, admin_username):
    import shop as _sh
    try:
        with _sh._conn() as c:
            rows = c.execute(
                "SELECT * FROM gift_codes WHERE admin_username=? ORDER BY id DESC",
                (admin_username,)).fetchall()
        codes = [dict(r) for r in rows]
    except Exception:
        codes = []

    txt = "🎁 <b>کدهای هدیه اشتراک</b>\n\n"
    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}
    if not codes:
        txt += "هنوز کد هدیه‌ای ساخته نشده."
    else:
        for c in codes[:15]:
            used = c["used_count"]
            max_u = c["max_uses"]
            status = "🟢" if c["active"] and used < max_u else "🔴"
            days_label = label.get(c["plan_days"], f"{c['plan_days']} روز")
            txt += (f"{status} <code>{c['code']}</code> — {days_label} | {c['gb']} گیگ\n"
                    f"   استفاده: {used}/{max_u}\n")
    rows = [
        [btn("➕ ساخت کد هدیه", "gift:create")],
        [btn("🔄 لیست کدها", "gift:refresh")],
    ]
    # Add reset/delete buttons for each code
    for c in codes[:10]:
        if c["used_count"] > 0:
            rows.append([btn(f"🔄 ریست {c['code']}", f"gift:reset:{c['id']}")])
        rows.append([btn(f"🗑 حذف {c['code']}", f"gift:del:{c['id']}")])
    rows.append(back_btn())
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _gift_action(token, cb_id, chat_id, message_id, admin_username, action):
    if action == "create":
        answer(token, cb_id)
        CONV.set(chat_id, "gift_code", {})
        send(token, chat_id,
             "🎁 <b>ساخت کد هدیه</b>\n\n"
             "کد را بفرستید (مثلاً: FREE2024):\n"
             "(یا «auto» برای تولید خودکار)")
        return

    if action == "refresh":
        answer(token, cb_id)
        _show_gifts_menu(token, chat_id, message_id, admin_username)
        return

    if action.startswith("del:"):
        code_id = int(action.split(":")[1])
        with __import__("shop")._conn() as c:
            c.execute("DELETE FROM gift_codes WHERE id=?", (code_id,))
        answer(token, cb_id, "کد هدیه حذف شد ✅")
        _show_gifts_menu(token, chat_id, message_id, admin_username)
        return

    if action.startswith("reset:"):
        code_id = int(action.split(":")[1])
        with __import__("shop")._conn() as c:
            c.execute("UPDATE gift_codes SET used_count=0 WHERE id=?", (code_id,))
        answer(token, cb_id, "کد ریست شد ✅")
        _show_gifts_menu(token, chat_id, message_id, admin_username)
        return

    answer(token, cb_id)


# ==========================================================================
#  TRIAL ACCOUNT MANAGEMENT (admin side)
# ==========================================================================

def _show_trial_menu(token, chat_id, message_id, admin_username, cfg):
    eff = settings.get_effective_config(admin_username, cfg)
    enabled = eff.get("trial_enabled", False)
    data_mb = eff.get("trial_data_mb", 100)
    hours = eff.get("trial_hours", 24)

    # count trial users
    import shop as _sh
    try:
        with _sh._conn() as c:
            count = c.execute(
                "SELECT COUNT(*) as cnt FROM trial_usage WHERE admin_username=?",
                (admin_username,)).fetchone()["cnt"]
    except Exception:
        count = 0

    txt = (
        "🎮 <b>اکانت تست (آزمایشی)</b>\n\n"
        f"وضعیت: {'🟢 فعال' if enabled else '🔴 غیرفعال'}\n"
        f"📦 حجم: {data_mb} مگابایت\n"
        f"⏰ زمان: {hours} ساعت\n"
        f"👥 کاربران استفاده‌کرده: {count}\n\n"
        "کاربران با ارسال لینک ساب، اکانت تست رایگان دریافت می‌کنند."
    )
    rows = [
        [btn("🔴 غیرفعال" if enabled else "🟢 فعال", "trial:toggle")],
        [btn("📦 تنظیم حجم", "trial:set_data"), btn("⏰ تنظیم زمان", "trial:set_time")],
        [btn("🔄 ریست کاربران", "trial:reset")],
        back_btn(),
    ]
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _trial_action(token, cb_id, chat_id, message_id, admin_username, cfg, action):
    if action == "toggle":
        cur = str(settings.get_setting(admin_username, "trial_enabled", "0")) == "1"
        settings.set_setting(admin_username, "trial_enabled", "0" if cur else "1")
        answer(token, cb_id, "تغییر کرد ✅")
        new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
        _show_trial_menu(token, chat_id, message_id, admin_username, new_cfg)
        return

    if action == "set_data":
        answer(token, cb_id)
        CONV.set(chat_id, "trial_data", {})
        current = int(settings.get_setting(admin_username, "trial_data_mb", 100) or 100)
        send(token, chat_id,
             f"📦 حجم فعلی: <b>{current} مگابایت</b>\n\nحجم جدید را به مگابایت بفرستید:")
        return

    if action == "set_time":
        answer(token, cb_id)
        CONV.set(chat_id, "trial_time", {})
        current = int(settings.get_setting(admin_username, "trial_hours", 24) or 24)
        send(token, chat_id,
             f"⏰ زمان فعلی: <b>{current} ساعت</b>\n\nزمان جدید را به ساعت بفرستید:")
        return

    if action == "reset":
        answer(token, cb_id)
        safe_edit(token, chat_id, message_id,
             "⚠️ آیا از ریست کاربران آزمایشی مطمئن هستید؟\n"
             "همه کاربران می‌توانند دوباره از تست استفاده کنند.",
             kb([
                 [btn("✅ بله، ریست کن", "trial:resetconfirm"), btn("« انصراف", "m:trial")],
             ]))
        return

    if action == "resetconfirm":
        import shop as _sh
        count = _sh.reset_trial_users(admin_username)
        answer(token, cb_id, f"{count} کاربر ریست شد ✅")
        new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
        _show_trial_menu(token, chat_id, message_id, admin_username, new_cfg)
        return

    answer(token, cb_id)


# ==========================================================================
#  REFERRAL REWARD MANAGEMENT (admin side)
# ==========================================================================

def _show_ref_reward_menu(token, chat_id, message_id, admin_username, cfg):
    eff = settings.get_effective_config(admin_username, cfg)
    rtype = eff.get("referral_reward_type", "wallet")
    value = eff.get("referral_reward_value", 5000)
    percent = eff.get("referral_reward_percent", 10)

    type_label = "💰 کیف پول" if rtype == "wallet" else "🎟 کد تخفیف"
    if rtype == "wallet":
        amount_label = f"{value:,} تومان"
    else:
        amount_label = f"{percent}% تخفیف"

    txt = (
        "💰 <b>پاداش رفرال (معرفی دوستان)</b>\n\n"
        f"نوع پاداش: {type_label}\n"
        f"مقدار: {amount_label}\n\n"
        "وقتی کاربر معرفی‌شده خرید کند، معرف پاداش دریافت می‌کند:\n"
        "• <b>کیف پول:</b> مبلغ مستقیم به کیف پول معرف اضافه می‌شه\n"
        "• <b>کد تخفیف:</b> یه کد تخفیف رندوم برای معرف ساخته می‌شه"
    )
    rows = [
        [btn("💰 کیف پول" if rtype != "wallet" else "🎟 کد تخفیف", "refr:toggle_type")],
        [btn("✏️ تنظیم مبلغ کیف پول", "refr:set_wallet"), btn("✏️ تنظیم درصد تخفیف", "refr:set_percent")],
        [btn("✏️ متن پاداش", "refr:set_text")],
        back_btn(),
    ]
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _ref_reward_action(token, cb_id, chat_id, message_id, admin_username, cfg, action):
    if action == "toggle_type":
        cur = settings.get_setting(admin_username, "referral_reward_type", "wallet") or "wallet"
        new_type = "code" if cur == "wallet" else "wallet"
        settings.set_setting(admin_username, "referral_reward_type", new_type)
        answer(token, cb_id, "تغییر کرد ✅")
        new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
        _show_ref_reward_menu(token, chat_id, message_id, admin_username, new_cfg)
        return

    if action == "set_wallet":
        answer(token, cb_id)
        CONV.set(chat_id, "refr_wallet", {})
        current = int(settings.get_setting(admin_username, "referral_reward_value", 5000) or 5000)
        send(token, chat_id,
             f"💰 مبلغ فعلی: <b>{current:,} تومان</b>\n\nمبلغ جدید را به تومان بفرستید:")
        return

    if action == "set_percent":
        answer(token, cb_id)
        CONV.set(chat_id, "refr_percent", {})
        current = int(settings.get_setting(admin_username, "referral_reward_percent", 10) or 10)
        send(token, chat_id,
             f"🎟 درصد فعلی: <b>{current}%</b>\n\nدرصد جدید را بفرستید:")
        return

    if action == "set_text":
        answer(token, cb_id)
        CONV.set(chat_id, "refr_text", {})
        send(token, chat_id,
             "✏️ متن پاداش را بفرستید.\n\n"
             "متغیرها:\n"
             "• <code>{code}</code> — کد تخفیف\n"
             "• <code>{amount}</code> — مبلغ تومان\n\n"
             "مثال: 🎉 کد تخفیف شما: <code>{code}</code>")
        return

    answer(token, cb_id)


# ==========================================================================
#  PAYMENT METHODS MANAGEMENT (admin side)
# ==========================================================================

def _show_pay_methods_menu(token, chat_id, message_id, admin_username, cfg):
    eff = settings.get_effective_config(admin_username, cfg)
    card_on = eff.get("pay_card_enabled", True)
    rial_on = eff.get("pay_rial_gateway_enabled", False)
    crypto_on = eff.get("pay_crypto_gateway_enabled", False)

    txt = (
        "💳 <b>روش‌های پرداخت</b>\n\n"
        "روش‌هایی که می‌خواهید برای خریداران فعال باشد را روشن کنید.\n"
        "فقط روش‌های فعال به کاربران نمایش داده می‌شوند.\n\n"
        f"🏦 کارت به کارت: {'🟢 فعال' if card_on else '🔴 غیرفعال'}\n"
        f"🌐 درگاه ریالی: {'🟢 فعال' if rial_on else '🔴 غیرفعال'}\n"
        f"💎 درگاه ارزی: {'🟢 فعال' if crypto_on else '🔴 غیرفعال'}\n\n"
        "<i>درگاه ریالی و ارزی در نسخه‌های آینده فعال خواهند شد.</i>"
    )
    rows = [
        [btn("🏦 " + ("غیرفعال" if card_on else "فعال") + " کارت به کارت", "pay:toggle_card")],
        [btn("🌐 " + ("غیرفعال" if rial_on else "فعال") + " درگاه ریالی", "pay:toggle_rial")],
        [btn("💎 " + ("غیرفعال" if crypto_on else "فعال") + " درگاه ارزی", "pay:toggle_crypto")],
        back_btn(),
    ]
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _pay_methods_action(token, cb_id, chat_id, message_id, admin_username, cfg, action):
    if action == "toggle_card":
        cur = str(settings.get_setting(admin_username, "pay_card_enabled", "1")) == "1"
        # Don't allow disabling if no other method is enabled
        rial_on = str(settings.get_setting(admin_username, "pay_rial_gateway_enabled", "0")) == "1"
        crypto_on = str(settings.get_setting(admin_username, "pay_crypto_gateway_enabled", "0")) == "1"
        if cur and not rial_on and not crypto_on:
            answer(token, cb_id, "حداقل یک روش پرداخت باید فعال باشد", alert=True)
            return
        settings.set_setting(admin_username, "pay_card_enabled", "0" if cur else "1")
        answer(token, cb_id, "تغییر کرد ✅")
    elif action == "toggle_rial":
        cur = str(settings.get_setting(admin_username, "pay_rial_gateway_enabled", "0")) == "1"
        settings.set_setting(admin_username, "pay_rial_gateway_enabled", "0" if cur else "1")
        answer(token, cb_id, "تغییر کرد ✅")
    elif action == "toggle_crypto":
        cur = str(settings.get_setting(admin_username, "pay_crypto_gateway_enabled", "0")) == "1"
        settings.set_setting(admin_username, "pay_crypto_gateway_enabled", "0" if cur else "1")
        answer(token, cb_id, "تغییر کرد ✅")
    else:
        answer(token, cb_id)
        return

    new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
    _show_pay_methods_menu(token, chat_id, message_id, admin_username, new_cfg)


# ==========================================================================
#  ADMIN BACKUP / RESTORE MENU (per admin)
# ==========================================================================

def _show_backup_menu(token, chat_id, message_id, admin_username, cfg):
    """Show backup/restore menu for admin."""
    eff = settings.get_effective_config(admin_username, cfg)
    auto_enabled = eff.get("backup_auto_enabled", False)
    interval = eff.get("backup_interval_hours", 24)
    
    txt = (
        "💾 <b>بکاپ و بازیابی</b>\n\n"
        f"🔹 بکاپ خودکار: {'🟢 فعال' if auto_enabled else '🔴 غیرفعال'}\n"
        f"🔹 فاصله زمانی: هر {interval} ساعت\n\n"
        "بکاپ شامل همه‌ی داده‌های شماست:\n"
        "• تنظیمات، کارت‌ها، کدهای تخفیف/هدیه\n"
        "• پکیج‌ها، سفارش‌ها، کیف پول\n"
        "• کاربران ثبت‌نام شده\n\n"
        "⚠️ بازیابی، داده‌های فعلی را <b>جایگزین</b> می‌کند."
    )
    rows = [
        [btn("⬇️ دریافت بکاپ", "backup:get")],
        [btn("⬆️ بازیابی از فایل", "backup:restore")],
        [btn("🔄 " + ("غیرفعال" if auto_enabled else "فعال") + " کردن بکاپ خودکار", "backup:toggle_auto")],
        [btn("⏰ تنظیم فاصله زمانی", "backup:set_interval")],
        back_btn(),
    ]
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _backup_action(token, cb_id, chat_id, message_id, admin_username, cfg, action):
    """Handle backup actions."""
    if action == "get":
        answer(token, cb_id, "در حال ساخت بکاپ...")
        try:
            import shop as _sh
            import datetime as _dt
            backup_data = _sh.create_admin_backup(admin_username)
            ts = _dt.datetime.now().strftime("%Y%m%d-%H%M")
            filename = f"backup-{admin_username}-{ts}.zip"
            if not _send_document(token, chat_id, filename, backup_data,
                                  caption=f"💾 بکاپ ادمین <b>{escape(admin_username)}</b>\n📅 {ts}\n\n"
                                          "⚠️ این فایل را در جای امن نگه دارید."):
                send(token, chat_id, "❌ ارسال فایل بکاپ به تلگرام ناموفق بود.")
        except Exception as e:
            send(token, chat_id, f"❌ خطا در ساخت بکاپ: {str(e)[:150]}")
        return

    if action == "restore":
        answer(token, cb_id)
        CONV.set(chat_id, "backup_restore", {"admin": admin_username})
        send(token, chat_id,
             "⬆️ <b>بازیابی از فایل بکاپ</b>\n\n"
             "⚠️ <b>هشدار:</b> این عمل همه‌ی داده‌های فعلی شما را <b>جایگزین</b> می‌کند!\n\n"
             "فایل بکاپ (.zip) را ارسال کنید:")
        return

    if action == "toggle_auto":
        cur = str(settings.get_setting(admin_username, "backup_auto_enabled", "0")) == "1"
        settings.set_setting(admin_username, "backup_auto_enabled", "0" if cur else "1")
        _reset_backup_schedule(admin_username)
        answer(token, cb_id, "✅ تغییر کرد")
        new_cfg = settings.get_effective_config(admin_username, _resolve_admin_cfg(admin_username))
        _show_backup_menu(token, chat_id, message_id, admin_username, new_cfg)
        return

    if action == "set_interval":
        answer(token, cb_id)
        CONV.set(chat_id, "backup_interval", {"admin": admin_username})
        current = int(settings.get_setting(admin_username, "backup_interval_hours", 24) or 24)
        send(token, chat_id,
             f"⏰ <b>تنظیم فاصله زمانی بکاپ خودکار</b>\n\n"
             f"فاصله فعلی: <b>{current} ساعت</b>\n\n"
             "فاصله جدید را به ساعت وارد کنید (مثلاً 6 یا 12 یا 24):")
        return

    answer(token, cb_id)


def _handle_backup_restore(token, chat_id, admin_username, document):
    """Handle backup restore from uploaded file."""
    import shop as _sh
    
    name = (document.get("file_name") or "").lower()
    if not name.endswith(".zip"):
        send(token, chat_id, "❌ فایل باید ZIP باشد.")
        return
    
    file_id = document.get("file_id")
    send(token, chat_id, "⏳ در حال دانلود و بازیابی...")
    
    content = _download_file(token, file_id)
    if not content:
        send(token, chat_id, "❌ دانلود فایل ناموفق بود.")
        return
    
    try:
        result = _sh.restore_admin_backup(admin_username, content)
        if not result.get("ok"):
            error = result.get("error", "unknown")
            if error == "backup_belongs_to_different_admin":
                send(token, chat_id, "❌ این فایل بکاپ متعلق به ادمین دیگری است.")
            elif error == "invalid_backup_file":
                send(token, chat_id, "❌ فایل بکاپ معتبر نیست.")
            elif error == "backup_signature_invalid":
                send(token, chat_id, "❌ امضای بکاپ معتبر نیست یا فایل برای نصب دیگری است.")
            elif error == "backup_scope_conflict":
                send(token, chat_id, "❌ بکاپ با داده‌های موجود تداخل دارد؛ هیچ داده‌ای تغییر نکرد.")
            else:
                send(token, chat_id, f"❌ خطا در بازیابی: {escape(str(error))}")
            return
        
        settings.invalidate_settings_cache(admin_username)
        _reset_backup_schedule(admin_username)
        import bot_user
        bot_user._invalidate_user_cache()
        _invalidate_stats(admin_username)
        stats = result.get("stats", {})
        txt = "✅ <b>بازیابی با موفقیت انجام شد</b>\n\n📊 آمار بازیابی:\n"
        for table, count in stats.items():
            txt += f"• {table}: {count} رکورد\n"
        if result.get("legacy"):
            txt += "\nℹ️ این نسخهٔ قدیمی بکاپ، کاربران بات، حساب‌های فروشگاه، لینک‌ها و سفارش‌ها را جایگزین نمی‌کند."
        txt += "\n⚠️ توصیه: تنظیمات را بررسی کنید."
        send(token, chat_id, txt)
    except Exception as e:
        send(token, chat_id, f"❌ خطا: {str(e)[:150]}")


# ---- restore (sudo uploads a .zip backup) --------------------------------

def _handle_restore_upload(token, chat_id, document):
    name = (document.get("file_name") or "").lower()
    if not name.endswith(".zip"):
        send(token, chat_id, "فایل باید یک بکاپ .zip باشد.")
        return
    file_id = document.get("file_id")
    send(token, chat_id, "⏳ در حال دریافت و بررسی فایل بکاپ...")
    content = _download_file(token, file_id)
    if not content:
        send(token, chat_id, "❌ دانلود فایل ناموفق بود.")
        return
    try:
        res = _restore_backup(content)
    except ValueError as e:
        send(token, chat_id, f"❌ بازیابی ناموفق: {e}")
        return
    except Exception as e:
        send(token, chat_id, f"❌ خطای غیرمنتظره: {str(e)[:150]}")
        return
    parts = ["✅ <b>بازیابی انجام شد</b>"]
    if res.get("db"):
        parts.append("• دیتابیس بازیابی شد (تنظیمات، کاربران، سفارش‌ها، تخفیف‌ها)")
    if res.get("admins"):
        parts.append("• فایل admins.json بازیابی شد")
    parts.append("\nنسخه‌ی قبلی با پسوند <code>.pre-restore</code> نگه داشته شد.")
    parts.append("توصیه: یک‌بار سرویس را ری‌استارت کنید تا همه‌ی بات‌ها با تنظیمات جدید بالا بیایند.")
    send(token, chat_id, "\n".join(parts), kb([[btn("« منو", "m:home")]]))


# ==========================================================================
#  BOT USERS MANAGEMENT (admin side)
# ==========================================================================

def _show_bot_users_menu(token, chat_id, message_id, admin_username):
    """Show bot users management menu with stats."""
    import user_registry as _ur
    
    stats = _ur.get_user_stats(admin_username)
    
    txt = (
        "👥 <b>مدیریت کاربران بات</b>\n\n"
        f"📊 آمار:\n"
        f"• کل ثبت‌نامی‌ها: {stats['total']}\n"
        f"• فعال: {stats['active']}\n"
        f"• مسدود شده: {stats['blocked']}\n\n"
        "برای جستجو، نام کاربری یا chat_id را بفرستید.\n"
        "یا از دکمه‌های زیر استفاده کنید:"
    )
    
    rows = [
        [btn("🔎 جستجوی کاربر", "botuser:search")],
        [btn("📊 مشاهده آمار کامل", "botuser:stats")],
        [btn("🚫 لیست مسدودی‌ها", "botuser:blocked")],
        [btn("« بازگشت", "m:home")],
    ]
    
    safe_edit(token, chat_id, message_id, txt, kb(rows))


def _bot_user_action(token, cb_id, chat_id, message_id, admin_username, action):
    """Handle bot user management actions."""
    import user_registry as _ur
    
    if action == "search":
        answer(token, cb_id)
        CONV.set(chat_id, "botuser_search", {"admin": admin_username})
        send(token, chat_id, "🔎 نام کاربری یا chat_id را برای جستجو بفرستید:")
        return
    
    if action == "stats":
        answer(token, cb_id)
        stats = _ur.get_user_stats(admin_username)
        txt = (
            "📊 <b>آمار کامل کاربران بات</b>\n\n"
            f"• کل ثبت‌نامی‌ها: {stats['total']}\n"
            f"• کاربران فعال: {stats['active']}\n"
            f"• کاربران مسدود شده: {stats['blocked']}\n\n"
            f"درصد مسدودی: {(stats['blocked']/stats['total']*100) if stats['total'] > 0 else 0:.1f}%"
        )
        safe_edit(token, chat_id, message_id, txt, kb([[btn("« بازگشت", "m:bot_users")]]))
        return
    
    if action == "blocked":
        answer(token, cb_id)
        # Get blocked users
        with _ur._conn() as c:
            rows = c.execute(
                "SELECT * FROM bot_users WHERE admin_username=? AND blocked=1 ORDER BY blocked_at DESC LIMIT 50",
                (admin_username,)
            ).fetchall()
        blocked_users = [dict(r) for r in rows]
        
        if not blocked_users:
            txt = "🚫 هیچ کاربر مسدود شده‌ای وجود ندارد."
        else:
            txt = f"🚫 <b>کاربران مسدود شده ({len(blocked_users)})</b>\n\n"
            for u in blocked_users[:20]:  # Show max 20
                txt += f"• <code>{u['username']}</code>\n"
                if u.get("block_reason"):
                    txt += f"  دلیل: {u['block_reason']}\n"
                txt += "\n"
        
        rows = [[btn("« بازگشت", "m:bot_users")]]
        safe_edit(token, chat_id, message_id, txt, kb(rows))
        return
    
    if action.startswith("block:"):
        chat_id_to_block = action.split(":", 1)[1]
        CONV.set(chat_id, "botuser_block_reason", {"target_chat": chat_id_to_block})
        answer(token, cb_id)
        send(token, chat_id, "دلیل مسدودیت را بنویسید (یا «بدون دلیل»):")
        return
    
    if action.startswith("unblock:"):
        chat_id_to_unblock = action.split(":", 1)[1]
        _ur.unblock_user(chat_id_to_unblock)
        answer(token, cb_id, "کاربر آزاد شد ✅")
        # Refresh the blocked list
        _bot_user_action(token, cb_id, chat_id, message_id, admin_username, "blocked")
        return

    if action.startswith("delete:"):
        chat_id_to_delete = action.split(":", 1)[1]
        # Get user info before deletion for confirmation
        user_info = _ur.get_user_by_chat(chat_id_to_delete)
        if user_info:
            CONV.set(chat_id, "botuser_delete_confirm", {"target_chat": chat_id_to_delete, "username": user_info.get("username", "")})
            answer(token, cb_id)
            send(token, chat_id,
                 f"⚠️ <b>تایید حذف کاربر</b>\n\n"
                 f"👤 نام کاربری: <code>{user_info.get('username', '')}</code>\n"
                 f"🆔 chat_id: <code>{chat_id_to_delete}</code>\n\n"
                 "آیا مطمئن هستید؟ این عمل قابل بازگشت نیست!\n"
                 "برای تایید عدد 1 را بفرستید:",
                 kb([[btn("❌ لغو", "m:bot_users")]]))
        else:
            answer(token, cb_id, "کاربر یافت نشد")
        return

    answer(token, cb_id)
