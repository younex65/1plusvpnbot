# مرجع API پنل Rebecca (استخراج‌شده از docs)

پایه: `https://all.1plusnet.ir:4177` — احراز: `Authorization: Bearer <api_key>`

## کاربران (User)
| متد | مسیر | کاربرد |
|---|---|---|
| GET | `/api/users` | **لیست کاربران** (فیلتر با ادمین/جستجو/صفحه‌بندی) |
| POST | `/api/user` | ساخت کاربر |
| POST | `/api/v2/users` | ساخت کاربر (نسخه ۲، با service_ids) |
| GET | `/api/user/{username}` | خواندن یک کاربر |
| PUT | `/api/user/{username}` | ویرایش کاربر (data_limit, expire, status, note, ...) |
| PUT | `/api/v2/users/{username}` | ویرایش (نسخه ۲) |
| DELETE | `/api/user/{username}` | **حذف کاربر** |
| GET | `/api/user/{username}/usage` | مصرف کاربر |
| POST | `/api/user/{username}/reset` | ریست مصرف |
| POST | `/api/user/{username}/revoke_sub` | باطل‌کردن/نوکردن لینک ساب |
| POST | `/api/user/{username}/active-next` | فعال‌سازی پلن بعدی (مرتبط با onhold) |
| POST | `/api/users/actions` | **عملیات دسته‌جمعی روی کاربران** |
| GET | `/api/users/usage` | مصرف کلی کاربران |

## ادمین (Admin)
| متد | مسیر | کاربرد |
|---|---|---|
| GET | `/api/admins` | لیست ادمین‌ها |
| GET | `/api/admin/usage/{username}` | مصرف یک ادمین |
| POST | `/api/admin/{username}/users/disable` | **غیرفعال‌کردن همه‌ی کاربران آن ادمین** |
| POST | `/api/admin/{username}/users/activate` | **فعال‌کردن همه‌ی کاربران آن ادمین** |
| GET | `/api/admin/{username}/usage/daily` | مصرف روزانه |
| GET | `/api/myaccount` | حساب خودِ صاحب کلید |

## سرویس‌ها (Services v2)
| متد | مسیر | کاربرد |
|---|---|---|
| GET | `/api/v2/services` | **لیست سرویس‌ها** (برای انتخاب سرویس هنگام ساخت کاربر) |
| GET | `/api/v2/services/{service_id}/users` | کاربران یک سرویس |

## اینباند (Inbounds)
| متد | مسیر | کاربرد |
|---|---|---|
| GET | `/api/inbounds` | لیست اینباندها (برای flow/پروتکل) |
| GET | `/api/inbounds/full` | جزئیات کامل |

## زیرمجموعه (Sub) — عمومی، بدون کلید ادمین
| GET | `/sub/{identifier}/info` | اطلاعات حساب از روی توکن ساب |
| GET | `/sub/{identifier}/usage` | مصرف |
| GET | `/sub/{identifier}` | خروجی کانفیگ‌ها |
| GET | `/sub/{identifier}/ov/{host_tag}.ovpn` | کانفیگ OpenVPN |
| GET | `/sub/{identifier}/wg/{host_tag}.conf` | کانفیگ WireGuard |

## نکته‌های مهم
- فیلدهای کاربر: `username`, `data_limit` (bytes), `expire` (epoch ثانیه‌ای), `used_traffic`, `status` (active/limited/expired/disabled/on_hold), `admin_username`, `note`.
- ساخت کاربر onhold: `status="on_hold"`، `expire=0` و `on_hold_expire_duration` مثبت (مدت پس از فعال‌سازی به ثانیه؛ ۳۰ روز برابر با `2592000`). `active-next` عملیات جداگانهٔ فعال‌کردن پلن بعدی است.
- در `GET /api/user/{username}`، فیلد `subscription_url` لینک اصلی و `links` فهرست کانفیگ‌های همان حساب است.
- برای «هر ادمین فقط کاربران خودش»: هر ادمین **API Key خودش** را در `admins.json` می‌گذارد؛ پنل خودش فقط کاربران همان ادمین را برمی‌گرداند.
- بدنه‌ی دقیق `POST /api/user` و `POST /api/users/actions`: چون در docs ذخیره‌شده schema نبود، هنگام ساخت، ساختار را از یک کاربر موجود (GET) آینه می‌کنیم؛ در صورت خطا با curl تأیید می‌کنیم.
