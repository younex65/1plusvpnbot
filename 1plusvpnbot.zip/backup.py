"""
backup.py — consistent backup / restore of ALL bot data (sudo only).
====================================================================

Everything sensitive lives in one SQLite file (emergency.db) plus the
admins.json config. A backup is a single .zip containing:

    emergency.db    -> a *consistent* snapshot (via sqlite backup API)
    admins.json     -> per-admin api keys / bot tokens / cards (if present)
    manifest.json   -> {created_at, version}

Because the DB is shared by every admin's bot, one sudo backup captures the
whole system (all admins, all registered users, all settings, all orders).
"""
from __future__ import annotations

import io
import os
import json
import time
import sqlite3
import zipfile
import tempfile

BACKUP_VERSION = 1


def make_backup(db_path: str, admins_path: str = "", env_path: str = "") -> bytes:
    """Return the bytes of a .zip backup archive."""
    # consistent snapshot of the live DB
    snap_dir = os.path.dirname(db_path) or "."
    snap_fd, snap_path = tempfile.mkstemp(suffix=".db", dir=snap_dir)
    os.close(snap_fd)
    try:
        src = sqlite3.connect(db_path)
        try:
            dst = sqlite3.connect(snap_path)
            try:
                with dst:
                    src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(snap_path, "emergency.db")
            if admins_path and os.path.exists(admins_path):
                z.write(admins_path, "admins.json")
            manifest = {
                "created_at": int(time.time()),
                "version": BACKUP_VERSION,
                "has_admins": bool(admins_path and os.path.exists(admins_path)),
            }
            z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
        return buf.getvalue()
    finally:
        try:
            os.remove(snap_path)
        except OSError:
            pass


def restore_backup(zip_bytes: bytes, db_path: str, admins_path: str = "") -> dict:
    """Validate and restore a .zip backup. Returns a summary dict.

    Keeps the current db as <db_path>.pre-restore before overwriting so a bad
    restore can be undone.
    """
    buf = io.BytesIO(zip_bytes)
    try:
        zf = zipfile.ZipFile(buf)
    except zipfile.BadZipFile:
        raise ValueError("فایل بکاپ معتبر نیست (zip خراب).")

    names = zf.namelist()
    if "emergency.db" not in names:
        raise ValueError("فایل بکاپ ناقص است: emergency.db وجود ندارد.")

    # write the db to a temp file in the SAME directory (avoids cross-device rename)
    db_dir = os.path.dirname(db_path) or "."
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".db", dir=db_dir)
    os.close(tmp_fd)
    try:
        with open(tmp_path, "wb") as fh:
            fh.write(zf.read("emergency.db"))

        # integrity check
        c = sqlite3.connect(tmp_path)
        try:
            row = c.execute("PRAGMA integrity_check").fetchone()
            # also make sure it looks like our schema
            tables = {r[0] for r in c.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        finally:
            c.close()
        if not row or row[0] != "ok":
            raise ValueError("دیتابیس بکاپ سالم نیست (integrity check رد شد).")
        expected = {"renewal_orders", "bot_users", "admin_settings"}
        if not expected & tables:
            raise ValueError("این فایل به نظر بکاپ این ربات نیست.")

        # keep current db, then swap in the restored one
        if os.path.exists(db_path):
            os.replace(db_path, db_path + ".pre-restore")
        os.replace(tmp_path, db_path)
        tmp_path = None  # consumed

        result = {"db": True, "admins": False,
                  "created_at": None}
        try:
            manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
            result["created_at"] = manifest.get("created_at")
        except Exception:
            pass

        if "admins.json" in names and admins_path:
            if os.path.exists(admins_path):
                try:
                    os.replace(admins_path, admins_path + ".pre-restore")
                except OSError:
                    pass
            with open(admins_path, "wb") as fh:
                fh.write(zf.read("admins.json"))
            result["admins"] = True

        return result
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
