#!/bin/bash
# deploy.sh — Copy updated files and restart the service
# Run this on the server: bash deploy.sh

set -e

SRC="/home/user/emergency-backend"
DST="/opt/emergency-backend"

echo "=== 1PlusVPN Emergency Backend — Deploy ==="

# Copy changed files
echo "📁 Copying files..."
cp "$SRC/bot_user.py" "$DST/bot_user.py"
cp "$SRC/bot_settings.py" "$DST/bot_settings.py"

# Verify syntax
echo "🔍 Checking Python syntax..."
python3 -c "import ast; ast.parse(open('$DST/bot_user.py').read()); print('  ✅ bot_user.py OK')"
python3 -c "import ast; ast.parse(open('$DST/bot_settings.py').read()); print('  ✅ bot_settings.py OK')"

# Restart service
echo "🔄 Restarting service..."
sudo systemctl restart emergency-backend

# Wait a moment and check status
sleep 2
echo "📋 Service status:"
sudo systemctl status emergency-backend --no-pager | head -8

echo ""
echo "=== Deploy complete! ==="
echo ""
echo "📝 Changes made:"
echo "  1. shop_enabled default changed from '0' to '1' (shop enabled by default)"
echo "  2. _show_buy_options now falls back to plans when no packages defined"
echo "  3. Debug logging added to trace buy flow"
echo ""
echo "🧪 Test now:"
echo "  - Open the bot as a NEW user (or delete your registration)"
echo "  - Click '🛒 خرید اکانت جدید'"
echo "  - You should see plan options (30/60/90 day)"
echo ""
echo "📊 Check logs if issues:"
echo "  sudo journalctl -u emergency-backend -f --no-pager | grep '\[BUY\]\|\[CB\]'"
