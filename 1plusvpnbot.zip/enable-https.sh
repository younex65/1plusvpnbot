#!/usr/bin/env bash
#
# 1PlusVPN — Emergency Charge backend :: enable direct HTTPS (no nginx needed)
# ===========================================================================
# Your server has no nginx/caddy, ports 443 & 4177 are taken, but you DO have a
# valid TLS certificate (the one your Rebecca panel uses). This script makes the
# backend serve HTTPS directly on a spare port using that same certificate, so
# the browser trusts it.
#
#   sudo bash enable-https.sh
#
# Re-running is safe.
#
set -euo pipefail

c_g(){ printf '\033[1;32m%s\033[0m\n' "$*"; }
c_y(){ printf '\033[1;33m%s\033[0m\n' "$*"; }
c_r(){ printf '\033[1;31m%s\033[0m\n' "$*"; }
c_b(){ printf '\033[1;36m%s\033[0m\n' "$*"; }
line(){ printf '\033[2m%s\033[0m\n' "------------------------------------------------------------"; }

APP_DIR="/opt/emergency-backend"
SERVICE_NAME="emergency-backend"
ENV_FILE="$APP_DIR/.env"

DEFAULT_PORT="9443"
DEFAULT_CERT="/var/lib/rebecca/certs/sublink.1plusnet.ir/fullchain.pem"
DEFAULT_KEY="/var/lib/rebecca/certs/sublink.1plusnet.ir/privkey.pem"

line; c_b " Enable HTTPS for the Emergency Charge backend"; line

if [[ $EUID -ne 0 ]]; then c_r "Please run as root:  sudo bash enable-https.sh"; exit 1; fi
if [[ ! -d "$APP_DIR" ]]; then c_r "Backend not installed at $APP_DIR. Run install.sh first."; exit 1; fi

ask(){ local prompt="$1" def="$2" __var="$3" ans=""; [[ -n "$def" ]] && prompt="$prompt [$def]";
  read -r -p "  $prompt: " ans; ans="${ans:-$def}"; printf -v "$__var" '%s' "$ans"; }

echo
c_y "  The public HTTPS port for the API (must be OPEN in your firewall/provider)."
c_y "  443 and 4177 are already used, so pick a free port like 9443."
ask "HTTPS port" "$DEFAULT_PORT" HTTPS_PORT
echo
c_y "  TLS certificate files. Defaults point to your panel's cert for sublink.1plusnet.ir"
ask "Certificate (fullchain.pem)" "$DEFAULT_CERT" CERT_FILE
ask "Private key (privkey.pem)"   "$DEFAULT_KEY"  KEY_FILE

if [[ ! -f "$CERT_FILE" ]]; then c_r "Certificate not found: $CERT_FILE"; exit 1; fi
if [[ ! -f "$KEY_FILE" ]];  then c_r "Private key not found: $KEY_FILE";  exit 1; fi

# ---- rewrite the systemd service to serve HTTPS on all interfaces ----
# We run as root so uvicorn can read the root-owned Rebecca certs directly
# (they renew in place; a weekly restart timer picks up renewals).
c_g "[1/4] Reconfiguring systemd service for HTTPS on port ${HTTPS_PORT}..."
cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<EOF
[Unit]
Description=1PlusVPN Emergency Charge backend (HTTPS)
After=network.target

[Service]
WorkingDirectory=$APP_DIR
User=root
Group=root
EnvironmentFile=$ENV_FILE
ExecStart=$APP_DIR/venv/bin/uvicorn app:app \\
  --host 0.0.0.0 --port ${HTTPS_PORT} \\
  --ssl-certfile ${CERT_FILE} \\
  --ssl-keyfile ${KEY_FILE}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# ---- weekly restart timer so renewed certs are reloaded ----
c_g "[2/4] Installing weekly restart timer (to reload renewed certificates)..."
cat > "/etc/systemd/system/${SERVICE_NAME}-reload.service" <<EOF
[Unit]
Description=Restart emergency-backend to reload TLS certs
[Service]
Type=oneshot
ExecStart=/bin/systemctl restart ${SERVICE_NAME}.service
EOF
cat > "/etc/systemd/system/${SERVICE_NAME}-reload.timer" <<EOF
[Unit]
Description=Weekly restart of emergency-backend (TLS cert reload)
[Timer]
OnCalendar=weekly
Persistent=true
[Install]
WantedBy=timers.target
EOF

# ---- try to open the firewall port (best effort) ----
c_g "[3/4] Opening firewall port ${HTTPS_PORT} (if a firewall is active)..."
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi "Status: active"; then
  ufw allow "${HTTPS_PORT}/tcp" || true
  c_y "  ufw: allowed ${HTTPS_PORT}/tcp"
elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port="${HTTPS_PORT}/tcp" || true
  firewall-cmd --reload || true
  c_y "  firewalld: allowed ${HTTPS_PORT}/tcp"
else
  c_y "  No active local firewall detected."
fi
c_r "  IMPORTANT: if your provider (e.g. Hetzner) has a CLOUD firewall,"
c_r "  open TCP ${HTTPS_PORT} there too, or the API won't be reachable."

# ---- restart & verify ----
c_g "[4/4] Restarting service & verifying..."
systemctl daemon-reload
systemctl enable "${SERVICE_NAME}-reload.timer" >/dev/null 2>&1 || true
systemctl start  "${SERVICE_NAME}-reload.timer" >/dev/null 2>&1 || true
systemctl restart "$SERVICE_NAME"
sleep 3

OK=0
for i in 1 2 3 4 5; do
  if curl -fsS "https://127.0.0.1:${HTTPS_PORT}/api/emergency/health" --resolve "dummy:${HTTPS_PORT}:127.0.0.1" -k >/tmp/emg_h.json 2>/dev/null \
     || curl -fsS -k "https://127.0.0.1:${HTTPS_PORT}/api/emergency/health" >/tmp/emg_h.json 2>/dev/null; then
    OK=1; break; fi
  sleep 1
done

line
if [[ "$OK" == "1" ]]; then
  c_g " ✅ HTTPS backend is running on port ${HTTPS_PORT}."
  echo "    $(cat /tmp/emg_h.json)"
else
  c_r " ⚠ Service did not answer. Check: journalctl -u ${SERVICE_NAME} -n 40 --no-pager"
fi
rm -f /tmp/emg_h.json 2>/dev/null || true
line

# figure out the public origin for the frontend hint
SUB_ORIGIN="$(grep -E '^ALLOWED_ORIGINS=' "$ENV_FILE" | head -n1 | cut -d= -f2- | cut -d, -f1)"
API_HOST="$(printf '%s' "$SUB_ORIGIN" | sed -E 's#^https?://##; s#:.*##')"
[[ -z "$API_HOST" ]] && API_HOST="sublink.1plusnet.ir"

cat <<EOF

$(c_b "NEXT STEP — point the frontend at this API")

In index-reb-multi-api.html set:

    EMERGENCY_API_BASE: 'https://${API_HOST}:${HTTPS_PORT}',

Then test from your OWN browser (not the server):

    https://${API_HOST}:${HTTPS_PORT}/api/emergency/health

You should see JSON with "ok":true. If it times out, the port is blocked by a
cloud/provider firewall — open TCP ${HTTPS_PORT} there.

$(c_b "USEFUL COMMANDS")
   Logs   : journalctl -u ${SERVICE_NAME} -f
   Restart: systemctl restart ${SERVICE_NAME}
   Config : nano ${ENV_FILE}

EOF
c_g "Done."
