"""
1PlusVPN — Emergency Charge backend proxy
=========================================

A small, self-contained FastAPI service that sits between the public user
subscription page and the Rebecca panel admin API.

Why this exists
---------------
Changing a user's `data_limit` / `expire` requires an ADMIN api key. That key
must NEVER live in the public HTML page (any user could steal it and take over
the whole panel). This service keeps the admin key server-side and exposes only
two safe, purpose-built endpoints to the page:

    GET  /api/emergency/status   -> what buttons should the page show?
    POST /api/emergency/charge   -> apply the one-time emergency top-up

Security model
--------------
* The page identifies the user by its own `subscription_url` (a secret token
  only that user has). The backend validates it against the panel's public
  `/sub/{token}/info` endpoint to resolve the real username. A user therefore
  can only ever act on their own account.
* The admin API key is read from the environment / .env file, server-side only.
* "One emergency charge until the admin renews" is tracked in a local SQLite DB.
  Renewal is detected by comparing the account against a baseline snapshot that
  is captured *right after* a charge (so the charge itself can never be mistaken
  for a renewal).

Configuration (see config.example.env)
--------------------------------------
    PANEL_BASE_URL      admin panel API base incl. base-path, e.g. https://all.1plusnet.ir:4177/oneplus
    SUB_BASE_URL        subscription host base (if different), e.g. https://sublink.1plusnet.ir:4177
                        (defaults to PANEL_BASE_URL when empty)
    ADMIN_API_KEY       personal admin API key created in "My Account -> API Keys"
    SUPPORT_URL         e.g. https://t.me/oneplusvpn_support
    EMERGENCY_DATA_MB   default 200
    EMERGENCY_DAYS      default 1
    ALLOWED_ORIGINS     comma list, e.g. https://all.1plusnet.ir:4177
    DB_PATH             default ./emergency.db
    PANEL_VERIFY_TLS    default true  (set false only if panel uses self-signed cert)
"""

from __future__ import annotations

import os
import re
import sqlite3
import time
import threading
from contextlib import closing, contextmanager
from typing import Optional

import httpx

import dbx
import admin_config
import backup_schedule
from html import escape
import tg_client
from fastapi import FastAPI, HTTPException, Request, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------

def _load_dotenv(path: str = ".env") -> None:
    """Minimal .env loader (no external dependency)."""
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip().strip('"').strip("'")
            os.environ.setdefault(k, v)


_load_dotenv()

PANEL_BASE_URL = os.environ.get("PANEL_BASE_URL", "https://all.1plusnet.ir:4177/oneplus").rstrip("/")
# The subscription links can live on a DIFFERENT host/base-path than the admin
# panel. This is only used to validate the user's sub link and resolve their
# username. Defaults to PANEL_BASE_URL when not set.
SUB_BASE_URL = os.environ.get("SUB_BASE_URL", "").rstrip("/") or PANEL_BASE_URL
ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "")
SUPPORT_URL = os.environ.get("SUPPORT_URL", "https://t.me/oneplusvpn_support")
EMERGENCY_DATA_BYTES = int(float(os.environ.get("EMERGENCY_DATA_MB", "200")) * 1024 * 1024)
EMERGENCY_SECONDS = int(float(os.environ.get("EMERGENCY_DAYS", "1")) * 86400)
DB_PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(__file__), "emergency.db"))
PANEL_VERIFY_TLS = os.environ.get("PANEL_VERIFY_TLS", "true").lower() not in ("0", "false", "no")
ALLOWED_ORIGINS = [
    o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "").split(",") if o.strip()
]
# If no explicit ALLOWED_ORIGINS, build from PANEL_BASE_URL + SUB_BASE_URL
if not ALLOWED_ORIGINS:
    ALLOWED_ORIGINS = []
    if PANEL_BASE_URL:
        ALLOWED_ORIGINS.append(PANEL_BASE_URL)
    if SUB_BASE_URL and SUB_BASE_URL != PANEL_BASE_URL:
        ALLOWED_ORIGINS.append(SUB_BASE_URL)
    # also allow the subscription frontend origin (port may differ from panel)
    # e.g. https://sublink.1plusnet.ir:4177
    ALLOWED_ORIGINS = list(dict.fromkeys(ALLOWED_ORIGINS))  # deduplicate
    if not ALLOWED_ORIGINS:
        # Don't default to wildcard — require explicit configuration
        ALLOWED_ORIGINS = [
            "https://sublink.1plusnet.ir:4177",
            "https://all.1plusnet.ir:4177",
        ]

# ---- Self-service renewal (plans + Telegram approval bot) ----
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
# Admin chat id(s) that receive payment screenshots and can approve/reject.
TELEGRAM_ADMIN_IDS = [
    x.strip() for x in os.environ.get("TELEGRAM_ADMIN_IDS", "").replace(" ", ",").split(",") if x.strip()
]
CARD_NUMBER = os.environ.get("CARD_NUMBER", "6219861903371283")
CARD_HOLDER = os.environ.get("CARD_HOLDER", "یونس پناهی")
CARD_BANK = os.environ.get("CARD_BANK", "بلوبانک")
# Per-plan pricing: toman per GB. Keys are plan duration in days.
PLAN_PRICES = {
    30: int(os.environ.get("PRICE_PER_GB_1M", "8000")),
    60: int(os.environ.get("PRICE_PER_GB_2M", "8800")),
    90: int(os.environ.get("PRICE_PER_GB_3M", "9600")),
}
MIN_GB = int(os.environ.get("MIN_GB", "10"))
MAX_GB = int(os.environ.get("MAX_GB", "1000"))
# where uploaded receipts are stored temporarily before forwarding to Telegram
RECEIPT_DIR = os.environ.get("RECEIPT_DIR", os.path.join(os.path.dirname(__file__), "receipts"))

# ---- Multi-admin renewal config ----
# Optional per-admin overrides (card, bot, chat ids, pricing). Loaded from a JSON
# file so each panel admin can have their OWN renewal card + Telegram bot while
# renewals are still applied with the shared (sudo) ADMIN_API_KEY.
#
# admins.json shape (all fields optional; missing ones fall back to .env defaults):
# {
#   "1plus":  { "bot_token":"...", "admin_ids":["123"], "card_number":"...",
#               "card_holder":"...", "card_bank":"...",
#               "prices":{"30":8000,"60":8800,"90":9600} },
#   "reseller2": { "bot_token":"...", "admin_ids":["456"], "card_number":"...", ... }
# }
import json as _cfgjson
ADMINS_CONFIG_PATH = os.environ.get(
    "ADMINS_CONFIG_PATH", os.path.join(os.path.dirname(__file__), "admins.json"))


def _default_admin_cfg() -> dict:
    return {
        "bot_token": TELEGRAM_BOT_TOKEN,
        "admin_ids": list(TELEGRAM_ADMIN_IDS),
        "card_number": CARD_NUMBER,
        "card_holder": CARD_HOLDER,
        "card_bank": CARD_BANK,
        "prices": dict(PLAN_PRICES),
        "api_key": ADMIN_API_KEY,
    }


def _load_admins_config() -> dict:
    """Load admins.json with in-memory cache (TTL=30s to reduce disk reads)."""
    now = time.time()
    try:
        st = os.stat(ADMINS_CONFIG_PATH)
        stamp = (st.st_dev, st.st_ino, st.st_mtime_ns, st.st_size)
    except OSError:
        stamp = None
    if hasattr(_load_admins_config, "_cache"):
        cached, ts, old_stamp = _load_admins_config._cache
        if stamp == old_stamp and now - ts < 30:
            return cached
    try:
        with open(ADMINS_CONFIG_PATH, "r", encoding="utf-8") as fh:
            raw = _cfgjson.load(fh)
        result = raw if isinstance(raw, dict) else {}
    except FileNotFoundError:
        result = {}
    except Exception:
        result = {}
    _load_admins_config._cache = (result, now, stamp)
    return result


def _invalidate_admins_cache():
    """Clear the admins config cache (call after updating admins.json)."""
    if hasattr(_load_admins_config, "_cache"):
        del _load_admins_config._cache


def _resolve_admin_cfg(admin_username: str) -> dict:
    """Merge the per-admin overrides (if any) over the .env defaults."""
    cfg = _default_admin_cfg()
    admins = _load_admins_config()
    ov = admins.get(admin_username or "")
    if not isinstance(ov, dict):
        ov = {}
    if ov.get("bot_token"):
        cfg["bot_token"] = str(ov["bot_token"]).strip()
    if ov.get("admin_ids"):
        ids = ov["admin_ids"]
        if isinstance(ids, str):
            ids = [x.strip() for x in ids.replace(" ", ",").split(",") if x.strip()]
        cfg["admin_ids"] = [str(x).strip() for x in ids if str(x).strip()]
    for k_src, k_dst in (("card_number", "card_number"), ("card_holder", "card_holder"),
                         ("card_bank", "card_bank"), ("api_key", "api_key")):
        if ov.get(k_src):
            cfg[k_dst] = str(ov[k_src])
    if isinstance(ov.get("prices"), dict) and ov["prices"]:
        cfg["prices"] = {int(k): int(v) for k, v in ov["prices"].items()}
    return cfg


def _all_bot_tokens() -> list:
    """Every distinct bot token (default + per-admin) that must be polled."""
    tokens = set()
    if TELEGRAM_BOT_TOKEN:
        tokens.add(TELEGRAM_BOT_TOKEN)
    for _uname, ov in admin_config.entries(_load_admins_config()):
        t = (ov or {}).get("bot_token")
        if t:
            tokens.add(str(t).strip())
    return [t for t in tokens if t]


def _admin_username_for_token(token: str) -> str:
    """Reverse map a bot token to the panel admin_username that owns it.

    The default/sudo bot token maps to the first admin whose config has no
    explicit bot_token (or to "" meaning the sudo/default admin)."""
    token = (token or "").strip()
    admins = _load_admins_config()
    for uname, ov in admin_config.entries(admins):
        if str((ov or {}).get("bot_token", "")).strip() == token and token:
            return uname
    # default/sudo bot
    return ""


def _sales_stats(admin_username: str) -> dict:
    """Approved-order sales totals for one admin (today / month / all-time)."""
    import datetime as _dt
    now = _dt.datetime.now()
    start_today = int(_dt.datetime(now.year, now.month, now.day).timestamp())
    start_month = int(_dt.datetime(now.year, now.month, 1).timestamp())
    where_admin = "(admin_username = ? OR (? = '' AND (admin_username IS NULL OR admin_username = '')))"
    with _db() as conn:
        def q(extra="", params=()):
            row = conn.execute(
                f"""SELECT COUNT(*) c, COALESCE(SUM(price),0) s
                    FROM renewal_orders
                    WHERE status='approved' AND {where_admin} {extra}""",
                (admin_username, admin_username, *params),
            ).fetchone()
            return int(row["c"]), int(row["s"])
        tc, ta = q("AND decided_at >= ?", (start_today,))
        mc, ma = q("AND decided_at >= ?", (start_month,))
        ac, aa = q()
    return {
        "today_count": tc, "today_amount": ta,
        "month_count": mc, "month_amount": ma,
        "total_count": ac, "total_amount": aa,
    }


def _list_orders(admin_username: str, limit: int = 20) -> list:
    with _db() as conn:
        rows = conn.execute(
            """SELECT * FROM renewal_orders
               WHERE admin_username = ? OR (? = '' AND (admin_username IS NULL OR admin_username = ''))
               ORDER BY created_at DESC LIMIT ?""",
            (admin_username, admin_username, limit),
        ).fetchall()
    return [dict(r) for r in rows]

# ----------------------------------------------------------------------------
# Database
# ----------------------------------------------------------------------------

_db_lock = threading.Lock()


def _init_db() -> None:
    with closing(sqlite3.connect(DB_PATH)) as db:
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS emergency_charges (
                username         TEXT PRIMARY KEY,
                charged_at       INTEGER NOT NULL,
                baseline_expire  INTEGER NOT NULL,   -- expire (unix seconds, 0 = unlimited) right after charge
                baseline_limit   INTEGER NOT NULL,   -- data_limit (bytes, 0 = unlimited) right after charge
                baseline_used    INTEGER NOT NULL    -- used_traffic (bytes) right after charge
            )
            """
        )
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS renewal_orders (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                username     TEXT NOT NULL,
                sub          TEXT NOT NULL,
                plan_days    INTEGER NOT NULL,
                gb           INTEGER NOT NULL,
                price        INTEGER NOT NULL,
                status       TEXT NOT NULL DEFAULT 'pending',  -- pending | approved | rejected
                created_at   INTEGER NOT NULL,
                decided_at   INTEGER,
                tg_message_id INTEGER,
                admin_username TEXT
            )
            """
        )
        # add admin_username column for DBs created before multi-admin support
        try:
            db.execute("ALTER TABLE renewal_orders ADD COLUMN admin_username TEXT")
        except Exception:
            pass
        # add discount column (phase 2 referral system)
        try:
            db.execute("ALTER TABLE renewal_orders ADD COLUMN discount INTEGER DEFAULT 0")
        except Exception:
            pass
        db.commit()


@contextmanager
def _db():
    """
    PERF FIX: this used to open a brand-new sqlite3 connection inside a
    process-wide lock for EVERY query — including the ones on the bot's hot
    path (_sales_stats, _list_orders, order lookups). Every bot worker thread
    and every HTTP request thread queued behind that single mutex.

    Now it reuses this thread's WAL connection (see dbx.py): parallel reads,
    autocommitting writes, and a busy_timeout instead of instant
    "database is locked" errors.
    """
    yield dbx.get(DB_PATH)


def _get_charge_record(username: str) -> Optional[sqlite3.Row]:
    with _db() as conn:
        cur = conn.execute(
            "SELECT * FROM emergency_charges WHERE username = ?", (username,)
        )
        return cur.fetchone()


def _save_charge_record(username: str, expire: int, limit: int, used: int) -> None:
    with _db() as conn:
        conn.execute(
            """
            INSERT INTO emergency_charges (username, charged_at, baseline_expire, baseline_limit, baseline_used)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(username) DO UPDATE SET
                charged_at=excluded.charged_at,
                baseline_expire=excluded.baseline_expire,
                baseline_limit=excluded.baseline_limit,
                baseline_used=excluded.baseline_used
            """,
            (username, int(time.time()), expire, limit, used),
        )


def _clear_charge_record(username: str) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM emergency_charges WHERE username = ?", (username,))


# ----------------------------------------------------------------------------
# Panel API helpers
# ----------------------------------------------------------------------------

# Persistent HTTP client for panel API calls (connection pooling)
_panel_client_instance = None
_panel_client_lock = threading.Lock()


def _panel_client() -> httpx.Client:
    """Get a persistent HTTP client for panel API calls (sudo admin key)."""
    global _panel_client_instance
    if _panel_client_instance is None:
        with _panel_client_lock:
            if _panel_client_instance is None:
                _panel_client_instance = httpx.Client(
                    # Split timeouts: fail fast on connect, allow a slow panel
                    # to finish a read. A single 15 s blanket timeout meant a
                    # dead panel held a bot worker thread hostage for 15 s.
                    timeout=httpx.Timeout(connect=6.0, read=15.0, write=15.0, pool=10.0),
                    limits=httpx.Limits(max_keepalive_connections=20,
                                        max_connections=50, keepalive_expiry=90.0),
                    verify=PANEL_VERIFY_TLS,
                    headers={"Authorization": f"Bearer {ADMIN_API_KEY}", "Accept": "application/json"},
                )
    return _panel_client_instance


# Persistent client for the PUBLIC subscription host (no auth header).
# Was lazily stashed on a function attribute in two different places, which
# meant two clients and a race on first use.
_sub_client_instance = None
_sub_client_lock = threading.Lock()

# sub-token -> (username, expires_at). See _resolve_username() for why.
_SUB_NAME_CACHE: dict = {}
_SUB_NAME_TTL = int(os.environ.get("SUB_NAME_CACHE_TTL", "3600"))
_SUB_NAME_CACHE_MAX = 20000


def _sub_client() -> httpx.Client:
    global _sub_client_instance
    if _sub_client_instance is None:
        with _sub_client_lock:
            if _sub_client_instance is None:
                _sub_client_instance = httpx.Client(
                    timeout=httpx.Timeout(connect=6.0, read=15.0, write=15.0, pool=10.0),
                    limits=httpx.Limits(max_keepalive_connections=20, max_connections=50,
                                        keepalive_expiry=90.0),
                    verify=PANEL_VERIFY_TLS,
                    headers={"Accept": "application/json"},
                )
    return _sub_client_instance


def _sub_identifier_from_url(sub_url: str) -> Optional[str]:
    """Extract the subscription identifier (token / path) from a full sub URL."""
    if not sub_url:
        return None
    s = sub_url.strip()
    # Accept full URL or bare token. Strip the origin and /sub/ prefix.
    m = re.search(r"/sub/([^?#]+)", s)
    if m:
        ident = m.group(1).strip("/")
        # tolerate callers that pass the info/usage endpoints directly
        for suffix in ("/info", "/usage"):
            if ident.endswith(suffix):
                ident = ident[: -len(suffix)]
        return ident.strip("/")
    # bare token
    if "/" not in s and "://" not in s:
        return s
    return None


def _resolve_username(sub_url: str) -> str:
    """
    Validate the subscription URL against the panel's public sub-info endpoint
    and return the real username. This proves the caller owns that sub link.

    PERF FIX: a sub token -> username mapping is immutable for the life of the
    link, yet this made a fresh HTTPS call to the panel on EVERY use. It sits
    in front of `_account_from_sub`, so every "📊 آمار اکانت" tap, every
    "📱 کانفیگ‌ها" tap, every /start and every notifier cycle paid for two
    sequential panel round trips where one was needed. Successful lookups are
    now memoised (bounded, with a TTL); failures are never cached so a newly
    created account is picked up immediately.
    """
    ident = _sub_identifier_from_url(sub_url)
    if not ident:
        raise HTTPException(status_code=400, detail="invalid_subscription_url")

    cached = _SUB_NAME_CACHE.get(ident)
    if cached and cached[1] > time.time():
        return cached[0]

    # The public sub-info endpoint does not require admin auth.
    # It lives on the SUBSCRIPTION host, which may differ from the admin panel.
    info_url = f"{SUB_BASE_URL}/sub/{ident}/info"
    try:
        r = _sub_client().get(info_url)
    except httpx.HTTPError:
        raise HTTPException(status_code=502, detail="panel_unreachable")

    if r.status_code == 404:
        raise HTTPException(status_code=404, detail="subscription_not_found")
    if r.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"sub_info_error_{r.status_code}")

    try:
        data = r.json()
    except Exception:
        raise HTTPException(status_code=502, detail="sub_info_not_json")

    # The Rebecca /sub/{token}/info response nests the account under a "user"
    # object, so read the username from there first. (A previous version wrongly
    # fell back to the whole "user" dict as the username.)
    username = None
    u = data.get("user")
    if isinstance(u, dict):
        username = u.get("username") or u.get("user")
    if not username:
        username = data.get("username")
    if not username and isinstance(u, str):
        username = u
    if not username or not isinstance(username, str):
        raise HTTPException(status_code=502, detail="username_not_resolvable")
    username = str(username)
    if len(_SUB_NAME_CACHE) > _SUB_NAME_CACHE_MAX:
        _SUB_NAME_CACHE.clear()
    _SUB_NAME_CACHE[ident] = (username, time.time() + _SUB_NAME_TTL)
    return username


def _get_user(client: httpx.Client, username: str) -> dict:
    r = client.get(f"{PANEL_BASE_URL}/api/user/{username}")
    if r.status_code == 404:
        raise HTTPException(status_code=404, detail="user_not_found")
    if r.status_code == 401 or r.status_code == 403:
        raise HTTPException(status_code=500, detail="admin_key_unauthorized")
    if r.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"get_user_error_{r.status_code}")
    return r.json()


def _put_user(client: httpx.Client, username: str, payload: dict) -> dict:
    r = client.put(f"{PANEL_BASE_URL}/api/user/{username}", json=payload)
    if r.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"update_user_error_{r.status_code}:{r.text[:200]}")
    try:
        return r.json()
    except Exception:
        return payload


def _admin_username_for(username: str) -> str:
    """Return which panel admin owns this user (for per-admin renewal config)."""
    try:
        client = _panel_client()
        u = _get_user(client, username)
        return str(u.get("admin_username") or u.get("admin") or "").strip()
    except Exception:
        return ""


# ----------------------------------------------------------------------------
# Value normalisation (expire format is auto-detected)
# ----------------------------------------------------------------------------

def _to_int(v, default=0) -> int:
    try:
        if v is None:
            return default
        return int(float(v))
    except (TypeError, ValueError):
        return default


def _expire_to_epoch(expire) -> int:
    """
    Normalise the panel's `expire` value to unix seconds.
    0 / None / falsy  -> 0 (unlimited / never).
    Accepts seconds-epoch, ms-epoch, or ISO-8601 string.
    """
    if not expire:
        return 0
    if isinstance(expire, (int, float)):
        v = int(expire)
        if v > 10_000_000_000:      # milliseconds epoch
            return v // 1000
        return v                     # seconds epoch
    if isinstance(expire, str):
        s = expire.strip()
        if not s or s.startswith("{"):
            return 0
        if s.isdigit():
            return _expire_to_epoch(int(s))
        # ISO string
        try:
            from datetime import datetime
            s2 = s.replace("Z", "+00:00")
            return int(datetime.fromisoformat(s2).timestamp())
        except Exception:
            return 0
    return 0


def _epoch_to_same_format(epoch: int, original) -> object:
    """Write a new expire value back in the SAME format the panel gave us."""
    if isinstance(original, str) and not original.strip().isdigit() and original.strip():
        # original was an ISO string -> return ISO
        from datetime import datetime, timezone
        return datetime.fromtimestamp(epoch, tz=timezone.utc).isoformat()
    if isinstance(original, (int, float)) and int(original) > 10_000_000_000:
        return epoch * 1000          # ms epoch
    return epoch                     # seconds epoch (default)


def _extract_account(user: dict) -> dict:
    """Pull the fields we care about out of a panel user object (name-tolerant)."""
    expire_raw = user.get("expire", user.get("expire_date", user.get("expiry")))
    limit_raw = user.get("data_limit", user.get("dataLimit", user.get("data_limit_bytes")))
    used_raw = user.get("used_traffic", user.get("usedTraffic", user.get("used")))
    status = str(user.get("status", (user.get("status") or "")) or "").lower()
    if isinstance(user.get("status"), dict):
        status = str(user["status"].get("value", "")).lower()
    return {
        "expire_epoch": _expire_to_epoch(expire_raw),
        "expire_raw": expire_raw,
        "data_limit": _to_int(limit_raw, 0),
        "used_traffic": _to_int(used_raw, 0),
        "status": status,
    }


# ----------------------------------------------------------------------------
# Core business logic
# ----------------------------------------------------------------------------

def _compute_conditions(acc: dict) -> dict:
    now = int(time.time())
    time_expired = acc["expire_epoch"] > 0 and acc["expire_epoch"] <= now
    data_exhausted = acc["data_limit"] > 0 and acc["used_traffic"] >= acc["data_limit"]
    return {"time_expired": time_expired, "data_exhausted": data_exhausted, "now": now}


def _renewed_since_charge(acc: dict, rec: sqlite3.Row) -> bool:
    """Detect an admin renewal by comparing the account to the post-charge baseline."""
    if rec is None:
        return False
    # data limit grew, expiry pushed further out, or usage was reset
    if acc["data_limit"] > rec["baseline_limit"] + 1:
        return True
    if acc["expire_epoch"] > rec["baseline_expire"] + 60:  # >60s tolerance
        return True
    if acc["used_traffic"] < rec["baseline_used"] - (10 * 1024 * 1024):  # dropped >10MB
        return True
    return False


def _decide_action(acc: dict, emergency_used: bool) -> str:
    """
    Which primary control should the page show?
      normal    -> account healthy: show the usual quick actions
      emergency -> exhausted, top-up still available: show "شارژ اضطراری"
      renew     -> exhausted, top-up already used: show "درخواست تمدید"
      support   -> disabled account: show "تماس با پشتیبانی"
    """
    status = acc["status"]
    cond = _compute_conditions(acc)

    if status == "disabled":
        return "support"

    exhausted = (
        status in ("limited", "expired")
        or cond["time_expired"]
        or cond["data_exhausted"]
    )
    if not exhausted:
        return "normal"

    return "renew" if emergency_used else "emergency"


def _build_state(username: str, acc: dict) -> dict:
    rec = _get_charge_record(username)
    if rec and _renewed_since_charge(acc, rec):
        _clear_charge_record(username)
        rec = None
    emergency_used = rec is not None
    action = _decide_action(acc, emergency_used)
    return {
        "action": action,
        "status": acc["status"],
        "emergencyUsed": emergency_used,
        "supportUrl": SUPPORT_URL,
        "emergency": {"dataMB": EMERGENCY_DATA_BYTES // (1024 * 1024),
                      "days": EMERGENCY_SECONDS // 86400},
    }


# ----------------------------------------------------------------------------
# FastAPI app
# ----------------------------------------------------------------------------

app = FastAPI(title="1PlusVPN Emergency Charge", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS or ["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
def _shutdown():
    """Release the pooled Telegram/panel connections and sqlite handles."""
    _maintenance_stop.set()
    with _pollers_lock:
        for _, stop in _pollers.values():
            stop.set()
    try:
        tg_client.close_all()
    except Exception:
        pass
    try:
        dbx.close_thread()
    except Exception:
        pass


@app.on_event("startup")
def _startup():
    _maintenance_stop.clear()
    _init_db()
    backup_schedule.init(DB_PATH)
    # initialise the bot-side databases (settings, user registry) on the same DB file
    try:
        import bot_settings as _bs
        import user_registry as _ur
        import referrals as _rf
        import shop as _shopmod
        import bot as _bot
        import bot_user as _bu
        import notifier as _nf
        _bs.init(DB_PATH)
        _ur.init(DB_PATH)
        _rf.init(DB_PATH)
        _shopmod.init(DB_PATH)
        _bot.configure(
            resolve_admin_cfg=_telegram_admin_cfg,
            admin_username_for_token=_admin_username_for_token,
            sales_stats=_sales_stats,
            list_orders=_list_orders,
            is_sudo=_is_sudo,
            make_backup=_make_backup_bytes,
            restore_backup=_restore_backup_bytes,
            send_document=_tg_send_document,
            download_file=_tg_download_file,
            subscription_base_url=SUB_BASE_URL,
            can_add_admin=lambda token, sender: bool(TELEGRAM_BOT_TOKEN and token == TELEGRAM_BOT_TOKEN
                                                   and _is_sudo(token, sender)),
            add_admin=_register_telegram_admin,
            reset_backup_schedule=lambda admin: backup_schedule.reset(DB_PATH, admin),
        )
        _bu.configure(
            resolve_username=_resolve_username,
            account_from_sub=_account_from_sub,
            effective_cfg=_bot_effective_cfg,
            admin_username_for=_admin_username_for,
            admin_username_for_token=_admin_username_for_token,
            fetch_configs=_fetch_configs,
            create_order=_create_order,
            notify_admin_receipt=_notify_admin_receipt_fileid,
            shop_list_packages=_shop_list_packages,
            shop_get_package=_shop_get_package,
            shop_ensure_account=_shop_ensure_account,
            shop_create_order=_shop_create_order,
            shop_notify_receipt=_shop_notify_receipt,
        )
        _nf.configure(
            account_from_sub=_account_from_sub,
            effective_cfg=_bot_effective_cfg,
            send_message=lambda tok, cid, txt, kb: _tg_call(
                "sendMessage", token=tok, chat_id=cid, text=txt,
                parse_mode="HTML", reply_markup=_json.dumps(kb) if kb else None),
        )
        if _all_bot_tokens():
            _nf.start()
        _threading.Thread(target=_admin_backup_loop, name="admin-backup", daemon=True).start()
        # optional automatic backups to the sudo chat
        if BACKUP_INTERVAL_HOURS > 0:
            _threading.Thread(target=_auto_backup_loop, daemon=True).start()
    except Exception as _e:
        print("bot init warning:", _e)


def _bot_effective_cfg(admin_username: str) -> dict:
    """Config for an admin, merged with bot-editable settings (card/prices/etc).
    Uses cached admins config and bot settings for performance."""
    base = _resolve_admin_cfg(admin_username)
    try:
        import bot_settings as _bs
        return _bs.get_effective_config(admin_username, base)
    except Exception:
        return base



def _telegram_admin_cfg(admin_username: str) -> dict:
    cfg = _bot_effective_cfg(admin_username)
    if admin_username:
        # Never inherit the .env sudo key for a named admin's Telegram bot.
        override = _load_admins_config().get(admin_username) or {}
        cfg["api_key"] = str(override.get("api_key") or "").strip()
    return cfg


# ---- phase-2 helpers (user side of the bot) --------------------------------

def _account_from_sub(sub: str) -> dict:
    """Resolve a sub link to a normalized account dict (for the bot user side)."""
    username = _resolve_username(sub)
    client = _panel_client()
    user = _get_user(client, username)
    acc = _extract_account(user)
    return {
        "username": username,
        "status": acc["status"],
        "used_traffic": acc["used_traffic"],
        "data_limit": acc["data_limit"],
        "expire_epoch": acc["expire_epoch"],
        "admin_username": str(user.get("admin_username") or user.get("admin") or "").strip(),
    }


def _fetch_configs(sub: str) -> list:
    """Return [(name, uri), ...] of a user's configs from their sub link."""
    ident = _sub_identifier_from_url(sub)
    if not ident:
        return []
    url = f"{SUB_BASE_URL}/sub/{ident}"
    out = []
    try:
        import base64 as _b64
        r = _sub_client().get(url, headers={"User-Agent": "v2rayNG/1.8.0"})
        body = r.text.strip()
        # try base64 decode
        content = body
        if "://" not in body:
            try:
                pad = body + "=" * (-len(body) % 4)
                content = _b64.b64decode(pad).decode("utf-8", "ignore")
            except Exception:
                content = body
        for line in content.splitlines():
            line = line.strip()
            if not line or "://" not in line:
                continue
            name = line.rsplit("#", 1)[1] if "#" in line else line.split("://", 1)[0].upper()
            try:
                from urllib.parse import unquote
                name = unquote(name)
            except Exception:
                pass
            out.append((name, line))
    except Exception:
        return []
    return out


def _notify_admin_receipt_fileid(order_id, username, plan_days, gb, price,
                                 file_id, cfg, discount=0) -> bool:
    """Forward a receipt (already uploaded to Telegram as file_id) to the admin(s)."""
    disc_line = f"\n🎁 تخفیف: {discount}%" if discount else ""
    caption = (
        f"🧾 <b>درخواست تمدید جدید (از ربات)</b>\n"
        f"👤 کاربر: <code>{username}</code>\n"
        f"📦 پلن: {_plan_label(plan_days)} ({plan_days} روز)\n"
        f"📊 حجم: {gb} گیگابایت{disc_line}\n"
        f"💰 مبلغ: {price:,} تومان\n"
        f"🆔 سفارش: #{order_id}"
    )
    kb = {"inline_keyboard": [[
        {"text": "✅ تایید و تمدید", "callback_data": f"approve:{order_id}"},
        {"text": "❌ رد", "callback_data": f"reject:{order_id}"},
    ]]}
    token = cfg.get("bot_token", "")
    sent_any = False
    for admin_id in cfg.get("admin_ids", []):
        res = _tg_call("sendPhoto", token=token, chat_id=admin_id, photo=file_id,
                       caption=caption, parse_mode="HTML", reply_markup=_json.dumps(kb))
        if res and res.get("ok"):
            sent_any = True
            _set_order_tg_msg(order_id, res["result"]["message_id"])
    return sent_any


# ---- shop helpers for bot_user (buy new account from bot) ------------------

def _shop_list_packages(admin_username: str, enabled_only: bool = True) -> list:
    """List shop packages for an admin."""
    try:
        import shop as _sh
        return _sh.list_packages(admin_username, enabled_only=enabled_only)
    except Exception:
        return []


def _shop_get_package(pkg_id: int):
    """Get a single package by ID."""
    try:
        import shop as _sh
        return _sh.get_package(pkg_id)
    except Exception:
        return None


def _shop_ensure_account(admin_username: str, shop_username: str, chat_id: str) -> int:
    """Get or create a shop account for a bot user. Returns shop_user_id."""
    import shop as _sh
    # try to authenticate first (existing account)
    acc = _sh.authenticate(admin_username, shop_username, chat_id)
    if acc:
        return acc["id"]
    # try to create (will fail if exists with different password)
    try:
        uid = _sh.create_account(admin_username, shop_username, chat_id, "", "")
        return uid
    except ValueError:
        # username taken — try to find the existing one
        # (password won't match if created from web, so we need a direct lookup)
        with _sh._conn() as c:
            row = c.execute(
                "SELECT id FROM shop_users WHERE admin_username=? AND username=?",
                (admin_username, shop_username)
            ).fetchone()
        if row:
            return row["id"]
        raise


def _shop_create_order(shop_user_id: int, admin: str, otype: str, plan_days: int,
                       gb: int, price: int, target_user: str = "",
                       service_id: str = "", package_id: int = 0) -> int:
    """Create a shop order."""
    import shop as _sh
    package_name = ""
    if package_id:
        pkg = _sh.get_package(package_id)
        if pkg:
            package_name = pkg.get("name", "")
            service_id = service_id or str(pkg.get("service_id", ""))
    return _sh.create_order(shop_user_id, admin, otype, plan_days, gb, price,
                            target_user, service_id, package_name)


def _shop_notify_receipt(order_id: int, shop_user_id: int, admin_username: str,
                         otype: str, plan_days: int, gb: int, price: int,
                         file_id: str, package_id: int = 0) -> bool:
    """Send a shop buy receipt to the admin(s) for approval."""
    import shop as _sh
    acc = _sh.get_account(shop_user_id) or {"username": f"tg_{shop_user_id}", "email": "", "phone": ""}
    cfg = _bot_effective_cfg(admin_username)
    label = "🛒 خرید جدید (از ربات)" if otype == "buy" else "🔄 تمدید (از ربات)"
    package_name = ""
    if package_id:
        pkg = _sh.get_package(package_id)
        if pkg:
            package_name = pkg.get("name", "")
    caption = (
        f"{label}\n"
        f"🧑 مشتری: <code>{acc['username']}</code>\n"
        + (f"📧 {acc.get('email', '')}\n" if acc.get('email') else "")
        + (f"📱 {acc.get('phone', '')}\n" if acc.get('phone') else "")
        + (f"🧩 سرویس: {package_name}\n" if package_name else "")
        + f"📦 پلن: {_plan_label(plan_days)} ({plan_days} روز)\n"
        f"📊 حجم: {gb} گیگابایت\n"
        f"💰 مبلغ: {price:,} تومان\n"
        f"🆔 سفارش: #{order_id}"
    )
    kb = {"inline_keyboard": [[
        {"text": "✅ تایید و ساخت اکانت", "callback_data": f"shopok:{order_id}"},
        {"text": "❌ رد", "callback_data": f"shopno:{order_id}"},
    ]]}
    token = cfg.get("bot_token", "")
    sent_any = False
    for admin_id in cfg.get("admin_ids", []):
        res = _tg_call("sendPhoto", token=token, chat_id=admin_id, photo=file_id,
                       caption=caption, parse_mode="HTML", reply_markup=_json.dumps(kb))
        if res and res.get("ok"):
            sent_any = True
            _sh.set_order_msg(order_id, res["result"]["message_id"])
    return sent_any


def _notify_buyer(order: dict, created_user: str, created_sub: str, token: str):
    """Notify a bot user (by chat_id extracted from shop username) about order approval."""
    import shop as _sh
    shop_user = _sh.get_account(order["shop_user_id"])
    if not shop_user:
        return
    uname = shop_user.get("username", "")
    # only notify if this is a bot user (username starts with tg_)
    if not uname.startswith("tg_"):
        return
    try:
        chat_id = int(uname[3:])  # extract chat_id from "tg_{chat_id}"
    except (ValueError, IndexError):
        return
    label = {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}.get(order.get("plan_days"), f"{order.get('plan_days', '?')} روز")
    msg = (
        f"✅ <b>سفارش خرید شما تایید و اکانتتان ساخته شد!</b>\n\n"
        f"👤 نام اکانت: <code>{created_user}</code>\n"
        f"📦 پلن: {label} — {order.get('gb', '?')} گیگابایت\n"
    )
    if created_sub:
        msg += f"\n🔗 <b>لینک اشتراک:</b>\n<code>{created_sub}</code>\n"
        msg += "\nاین لینک را در اپ VPN خود وارد کنید."
    else:
        msg += "\nلطفاً برای دریافت لینک اشتراک با پشتیبانی تماس بگیرید."
    try:
        import bot as _b
        _b.send(token, chat_id, msg)
    except Exception:
        pass


# ---- pending shop rejections (admin types reason) ----
_pending_rejections: dict = {}


def _auto_register_buyer(order: dict, vpn_username: str, admin_uname: str, sub_link: str):
    """After a bot buy order is approved, auto-register the user in user_registry
    so they get access to stats/configs/renew menus without manual registration."""
    if not sub_link or not vpn_username:
        return
    # Extract chat_id from the shop user (username is "tg_{chat_id}")
    import shop as _sh
    shop_user = _sh.get_account(order["shop_user_id"])
    if not shop_user:
        return
    shop_uname = shop_user.get("username", "")
    if not shop_uname.startswith("tg_"):
        return  # not a bot user
    try:
        chat_id = int(shop_uname[3:])
    except (ValueError, IndexError):
        return
    # Only register if not already registered
    import user_registry as _ur
    existing = _ur.get_user_by_chat(str(chat_id))
    if existing:
        # Already registered — update the sub link if it changed
        if existing.get("sub") != sub_link:
            _ur.register(chat_id, vpn_username, admin_uname, sub_link)
        return
    # Register the user
    _ur.register(chat_id, vpn_username, admin_uname, sub_link)
    print(f"[AUTO-REG] Registered chat_id={chat_id}, username={vpn_username}, admin={admin_uname}")


def _notify_renewal_rejection(order: dict, token: str):
    """Notify a user that their renewal order was rejected.
    For renewal orders, the user has a registered chat_id in user_registry."""
    try:
        import user_registry as _ur
        username = order.get("username", "")
        # Find chat_id for this user
        chat_id = _ur.get_chat_id_for_user(username)
        if not chat_id:
            return
        msg = (
            "❌ <b>درخواست تمدید شما رد شد</b>\n\n"
            f"👤 کاربر: <code>{username}</code>\n"
            f"📦 پلن: {order.get('plan_days', '?')} روزه — {order.get('gb', '?')} گیگابایت\n"
            f"💰 مبلغ: {order.get('price', 0):,} تومان\n\n"
            "در صورت نیاز با پشتیبانی تماس بگیرید."
        )
        _tg_call("sendMessage", token=token, chat_id=chat_id, text=msg, parse_mode="HTML")
    except Exception as e:
        print(f"[RENEW REJECT NOTIFY] error: {e}")


def _notify_rejection(order: dict, reason: str, token: str):
    """Notify a bot user (by chat_id extracted from shop username) that their order was rejected."""
    import shop as _sh
    shop_user = _sh.get_account(order["shop_user_id"])
    if not shop_user:
        return
    uname = shop_user.get("username", "")
    # only notify if this is a bot user (username starts with tg_)
    if not uname.startswith("tg_"):
        return
    try:
        chat_id = int(uname[3:])  # extract chat_id from "tg_{chat_id}"
    except (ValueError, IndexError):
        return
    label_map = {"buy": "خرید", "renew": "تمدید"}
    otype_label = label_map.get(order.get("type", "buy"), "خرید")
    msg = (
        f"❌ <b>درخواست {otype_label} شما رد شد</b>\n\n"
        f"🆔 سفارش: #{order['id']}\n"
        f"📦 پلن: {order.get('plan_days', '?')} روزه — {order.get('gb', '?')} گیگابایت\n"
        f"💰 مبلغ: {order.get('price', 0):,} تومان\n\n"
        f"📝 دلیل رد: <b>{reason}</b>\n\n"
    )
    if "مسدود" in reason:
        msg += "⛔️ شما از بات مسدود شده‌اید.\n"
    else:
        msg += "در صورت نیاز با پشتیبانی تماس بگیرید."
    try:
        import bot as _b
        _b.send(token, chat_id, msg)
    except Exception as e:
        print(f"[REJECT NOTIFY] error notifying chat_id={chat_id}: {e}")


def _block_shop_user(order: dict, token: str):
    """Block a bot user extracted from a shop order."""
    import shop as _sh
    import user_registry as _ur
    shop_user = _sh.get_account(order["shop_user_id"])
    if not shop_user:
        return
    uname = shop_user.get("username", "")
    if not uname.startswith("tg_"):
        return
    try:
        chat_id = int(uname[3:])
    except (ValueError, IndexError):
        return
    _ur.block_user(chat_id, reason="سفارش مشکوک توسط ادمین")
    print(f"[BLOCK] Blocked user chat_id={chat_id} for suspicious order #{order['id']}")


def _handle_reject_reason_text(chat_id: int, text: str) -> bool:
    """Check if admin is in 'write rejection reason' mode. Returns True if handled."""
    pending = _pending_rejections.get(chat_id)
    if not pending:
        return False
    # Only intercept text when explicitly waiting for reason input
    if pending.get("state") != "waiting_reason":
        return False
    reason = text.strip()
    if not reason:
        return True  # still waiting, ignore empty
    pending["reason"] = reason
    order_id = pending["order_id"]
    token = pending["token"]
    message_id = pending.get("message_id")
    base = pending["base"]
    confirm_kb = {"inline_keyboard": [
        [{"text": "✅ تایید رد با این دلیل", "callback_data": f"shopno_confirm:{order_id}"}],
        [{"text": "⛔️ رد + مسدود کردن کاربر", "callback_data": f"shopno_block_with_reason:{order_id}"}],
        [{"text": "❌ لغو", "callback_data": f"shopno_cancel:{order_id}"}],
    ]}
    confirm_msg = (
        f"📝 دلیل رد درخواست:\n<b>{reason}</b>\n\n"
        f"سفارش #{order_id}\n"
        f"{base}\n\n"
        "آیا تایید می‌کنید؟"
    )
    _tg_call("sendMessage", token=token, chat_id=chat_id, text=confirm_msg,
             parse_mode="HTML", reply_markup=_json.dumps(confirm_kb))
    # Clear the waiting state so further text isn't intercepted
    pending["state"] = "confirmed_reason"
    return True


# ---- backup / restore (sudo only) ------------------------------------------

# Sudo Telegram ids may be listed explicitly; default to the .env admin ids.
SUDO_ADMIN_IDS = [
    x.strip() for x in os.environ.get("SUDO_ADMIN_IDS", "").replace(" ", ",").split(",") if x.strip()
] or list(TELEGRAM_ADMIN_IDS)
# hours between automatic backups sent to the sudo chat (0 = disabled)
BACKUP_INTERVAL_HOURS = int(float(os.environ.get("BACKUP_INTERVAL_HOURS", "0") or 0))

# How many Telegram updates may be handled in parallel per bot token.
# Was hard-coded to 8; every handler is blocking (panel HTTP + sqlite), so 8
# concurrent admin actions used to freeze the bot for every other user.
_BOT_WORKERS = int(os.environ.get("BOT_WORKERS", "32"))

# Cached reference to the bot module (was re-imported on every update).
_BOT_MODULE = None


def _is_sudo(token: str, from_id) -> bool:
    """Only the sudo owner may take/restore full backups."""
    return str(from_id) in [str(x) for x in SUDO_ADMIN_IDS]


def _make_backup_bytes() -> bytes:
    import backup as _bk
    return _bk.make_backup(DB_PATH, ADMINS_CONFIG_PATH)


def _restore_backup_bytes(zip_bytes: bytes) -> dict:
    import backup as _bk
    res = _bk.restore_backup(zip_bytes, DB_PATH, ADMINS_CONFIG_PATH)
    # re-init in-memory pieces that read the DB
    try:
        import bot_settings as _bs, user_registry as _ur, referrals as _rf
        _bs.init(DB_PATH); _ur.init(DB_PATH); _rf.init(DB_PATH)
        import shop as _sh; _sh.init(DB_PATH)
    except Exception:
        pass
    return res


def _tg_send_document(token: str, chat_id, filename: str, content: bytes,
                      caption: str = "") -> bool:
    files = {"document": (filename, content)}
    res = _tg_call("sendDocument", token=token, chat_id=chat_id,
                   caption=caption, parse_mode="HTML", _files=files)
    return bool(res and res.get("ok"))


def _tg_download_file(token: str, file_id: str) -> Optional[bytes]:
    """Download a Telegram file. PERF FIX: uses the shared pooled client."""
    return tg_client.download_file(token, file_id)


def _auto_backup_loop():
    """Optionally send a fresh backup to the sudo chat every N hours."""
    if BACKUP_INTERVAL_HOURS <= 0 or not TELEGRAM_BOT_TOKEN or not SUDO_ADMIN_IDS:
        return
    import datetime as _dt
    while True:
        _time.sleep(BACKUP_INTERVAL_HOURS * 3600)
        try:
            content = _make_backup_bytes()
            ts = _dt.datetime.now().strftime("%Y%m%d-%H%M")
            for cid in SUDO_ADMIN_IDS:
                _tg_send_document(
                    TELEGRAM_BOT_TOKEN, cid, f"1plusvpn-backup-{ts}.zip", content,
                    caption=f"💾 بکاپ خودکار — {ts}")
        except Exception as e:
            print("auto-backup error:", e)


def _admin_backup_jobs():
    configs = [("", _default_admin_cfg()), *admin_config.entries(_load_admins_config())]
    tokens = [str(own.get("bot_token") or "").strip() for _, own in configs]
    jobs = {}
    for name, own in configs:
        token = str(own.get("bot_token") or "").strip()
        ids = own.get("admin_ids") or []
        if isinstance(ids, str):
            ids = ids.replace(",", " ").split()
        if not isinstance(ids, (list, tuple)):
            continue
        ids = list(dict.fromkeys(str(cid).strip() for cid in ids
                                 if re.fullmatch(r"[1-9][0-9]*", str(cid).strip())))
        # Skip ambiguous/shared tokens rather than send an archive from the wrong bot.
        if not token or not ids or tokens.count(token) != 1:
            continue
        cfg = _bot_effective_cfg(name)
        hours = cfg.get("backup_interval_hours", 24)
        if cfg.get("backup_auto_enabled") and 1 <= hours <= 168:
            jobs[name] = (hours * 3600, token, ids)
    return jobs


def _send_admin_auto_backup(token, chat_id, admin, content):
    job = _admin_backup_jobs().get(admin)
    if not job or job[1] != token or chat_id not in job[2]:
        return False
    stamp = _time.strftime("%Y%m%d-%H%M")
    return _tg_send_document(token, chat_id, f"admin-backup-{stamp}.zip", content,
                             caption=f"💾 بکاپ خودکار داده‌های <b>{escape(admin or 'ادمین پیش‌فرض')}</b>")


_maintenance_stop = threading.Event()


def _admin_backup_loop():
    from shop import create_admin_backup
    while not _maintenance_stop.is_set():
        try:
            backup_schedule.tick(DB_PATH, _admin_backup_jobs(), create_admin_backup,
                                 _send_admin_auto_backup,
                                 report=lambda admin, step, error: print(
                                     f"[admin-backup] {admin!r} {step}: {error}"))
        except Exception as e:
            print(f"[admin-backup] scheduler: {type(e).__name__}")
        _maintenance_stop.wait(15)


def _register_telegram_admin(name, api_key, bot_token, ids):
    from panel_api import PanelAPI, PanelError
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", name):
        return "نام ادمین نامعتبر است."
    if not re.fullmatch(r"[A-Za-z0-9._~+/-]{1,2048}={0,2}", api_key) or api_key == ADMIN_API_KEY.strip():
        return "کلید API اختصاصی حساب ادمین را وارد کنید؛ کلید سودو پذیرفته نمی‌شود."
    if not re.fullmatch(r"[1-9][0-9]*:[A-Za-z0-9_-]{20,100}", bot_token):
        return "فرمت توکن بات معتبر نیست."
    if not ids or any(not re.fullmatch(r"[1-9][0-9]{0,15}", cid) for cid in ids):
        return "آیدی عددی تلگرام معتبر نیست."
    try:
        account = PanelAPI(api_key).current_admin()
        if isinstance(account, dict) and isinstance(account.get("admin"), dict):
            account = account["admin"]
        if not isinstance(account, dict) or account.get("username") != name:
            return "نام ادمین با صاحب کلید API در Rebecca یکسان نیست."
        if account.get("is_sudo") or account.get("role") in ("sudo", "full_access"):
            return "برای این بات از کلید یک ادمین محدود یا فروشنده استفاده کنید."
    except PanelError:
        return "اعتبارسنجی کلید در Rebecca ناموفق بود؛ کلید و دسترسی حساب را بررسی کنید."
    result = tg_client.call("getMe", bot_token)
    if not result or not result.get("ok") or not (result.get("result") or {}).get("is_bot"):
        return "توکن بات در تلگرام تأیید نشد."
    webhook = tg_client.call("getWebhookInfo", bot_token)
    if not webhook or not webhook.get("ok") or (webhook.get("result") or {}).get("url"):
        return "از توکن یک بات اختصاصی و بدون وب‌هوک فعال استفاده کنید."
    try:
        admin_config.add(ADMINS_CONFIG_PATH, name,
                         {"api_key": api_key, "bot_token": bot_token, "admin_ids": ids},
                         default_token=TELEGRAM_BOT_TOKEN, default_key=ADMIN_API_KEY.strip())
    except admin_config.Conflict as e:
        return {"duplicate_admin": "این نام از قبل ثبت شده است.",
                "duplicate_bot_token": "این توکن قبلاً به یک بات در این برنامه اختصاص داده شده است.",
                "duplicate_api_key": "این کلید API قبلاً ثبت شده است."}[str(e)]
    except (OSError, ValueError):
        return "ثبت فایل تنظیمات ناموفق بود؛ دسترسی و سلامت admins.json را بررسی کنید."
    _invalidate_admins_cache()
    return ""


class SubBody(BaseModel):
    sub: str


@app.get("/api/emergency/health")
def health():
    return {"ok": True, "panel": PANEL_BASE_URL, "sub": SUB_BASE_URL, "configured": bool(ADMIN_API_KEY),
            "renewConfigured": bool(_all_bot_tokens())}


# ---- discount / gift code endpoints ----------------------------------------

# Simple in-memory rate limiter
_rate_limits: dict = {}

def _rate_check(key: str, max_requests: int = 10, window: int = 60) -> bool:
    """Check if a request is within rate limits. Returns True if allowed."""
    now = _time.time()
    if key not in _rate_limits:
        _rate_limits[key] = []
    _rate_limits[key] = [t for t in _rate_limits[key] if now - t < window]
    if len(_rate_limits[key]) >= max_requests:
        return False
    _rate_limits[key].append(now)
    return True



@app.get("/api/discount/validate")
def validate_discount(code: str, admin: str = "", sub: str = "", request: Request = None):
    """Validate a discount code. Accepts admin name OR sub link to resolve admin."""
    # Rate limiting: max 20 requests per minute per IP
    client_ip = request.client.host if request and request.client else "unknown"
    if not _rate_check(f"discount:{client_ip}", max_requests=20):
        raise HTTPException(status_code=429, detail="too_many_requests")

    import shop as _sh
    code = (code or "").strip().upper()
    if not code:
        raise HTTPException(status_code=400, detail="code_required")

    # Resolve admin from sub link if admin not provided directly
    if not admin and sub:
        try:
            username = _resolve_username(sub)
            admin = _admin_username_for(username)
        except Exception:
            raise HTTPException(status_code=400, detail="could_not_resolve_admin")

    if not admin:
        raise HTTPException(status_code=400, detail="admin_required")

    # Validate admin name format
    import re
    if not re.match(r'^[a-zA-Z0-9_]+$', admin):
        raise HTTPException(status_code=400, detail="invalid_admin_name")

    try:
        info = _sh.validate_discount_code(admin, code)
        sample_price = 10000
        discount_amt = _sh.calculate_discount(sample_price, info)
        return {
            "ok": True,
            "code": info["code"],
            "type": info["discount_type"],
            "value": info["discount_value"],
            "discount_amount": discount_amt,
            "sample_price": sample_price,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/discount/calculate")
def calculate_discount(code: str, price: int, admin: str = ""):
    """Calculate actual discount for a given price."""
    import shop as _sh
    code = (code or "").strip().upper()
    if not code or not admin:
        return {"discount": 0}
    try:
        info = _sh.validate_discount_code(admin, code)
        discount_amt = _sh.calculate_discount(int(price), info)
        return {"discount": discount_amt, "type": info["discount_type"], "value": info["discount_value"]}
    except ValueError:
        return {"discount": 0}


@app.post("/api/gift/redeem")
def redeem_gift(body: dict, request: Request = None):
    """Redeem a gift code to get a free account."""
    print(f"[GIFT REDEEM] Request received: body={body}")
    # Rate limiting
    client_ip = request.client.host if request and request.client else "unknown"
    if not _rate_check(f"gift:{client_ip}", max_requests=5, window=60):
        raise HTTPException(status_code=429, detail="too_many_requests")

    import shop as _sh
    code = (body.get("code") or "").strip().upper()
    admin = (body.get("admin") or "").strip()
    if not code or not admin:
        raise HTTPException(status_code=400, detail="code_and_admin_required")
    # Validate code format (alphanumeric + dash only)
    import re
    if not re.match(r'^[A-Z0-9\-]+$', code):
        raise HTTPException(status_code=400, detail="invalid_code_format")
    # Allow admin lookup from admins.json OR from known admin list
    admin = admin.strip()
    if not re.match(r'^[a-zA-Z0-9_]+$', admin):
        raise HTTPException(status_code=400, detail="invalid_admin_name")

    try:
        gift = _sh.validate_gift_code(admin, code)
        # Create account FIRST, then mark code as used
        cfg = _bot_effective_cfg(admin)
        api_key = cfg.get("api_key") or ADMIN_API_KEY
        from panel_api import PanelAPI
        api = PanelAPI(api_key)
        prefix = cfg.get("shop_prefix", "ST")
        username = _sh.next_username(api, prefix)
        now = int(_time.time())
        
        # Get first available service
        services = api.list_services()
        service_id = None
        if services and len(services) > 0:
            service_id = services[0].get("id") or services[0].get("service_id")
        
        payload = {
            "username": username,
            "data_limit": gift["gb"] * 1024 * 1024 * 1024 if gift["gb"] > 0 else 0,
            "expire": now + gift["plan_days"] * 86400,
            "status": "active",
        }
        
        if service_id:
            try:
                sid_int = int(service_id)
            except (TypeError, ValueError):
                sid_int = service_id
            payload["service_ids"] = [sid_int]
            payload["service_id"] = sid_int
        
        try:
            api.create_user_v2(payload)
        except Exception:
            api.create_user(payload)
        
        # Account created successfully — NOW mark code as used
        _sh.use_gift_code(code)
        user = api.get_user(username)
        sub = user.get("subscription_url") or user.get("sub") or ""
        # Link VPN account to the logged-in shop user (if any)
        try:
            sess = _shop_session(request) if request else None
            if sess:
                _sh.link_vpn(sess["shop_user_id"], username, sub)
        except Exception:
            pass
        return {"ok": True, "username": username, "sub": sub,
                "plan_days": gift["plan_days"], "gb": gift["gb"]}
    except ValueError as e:
        # Include admin name in error for debugging
        raise HTTPException(status_code=400, detail=f"{str(e)} (admin={admin}, code={code})")


@app.get("/api/gift/debug")
def gift_debug(admin: str = ""):
    """Debug endpoint to list all gift codes for an admin."""
    import shop as _sh
    try:
        with _sh._conn() as c:
            if admin:
                rows = c.execute(
                    "SELECT code, admin_username, plan_days, gb, max_uses, used_count, active FROM gift_codes WHERE admin_username=?",
                    (admin,)).fetchall()
            else:
                rows = c.execute(
                    "SELECT code, admin_username, plan_days, gb, max_uses, used_count, active FROM gift_codes ORDER BY id DESC LIMIT 20").fetchall()
        return {"codes": [dict(r) for r in rows]}
    except Exception as e:
        return {"error": str(e)}


@app.post("/api/trial/request")
def trial_request(body: dict, request: Request = None):
    """Request a trial account for a user."""
    # Rate limiting
    client_ip = request.client.host if request and request.client else "unknown"
    if not _rate_check(f"trial:{client_ip}", max_requests=5, window=60):
        raise HTTPException(status_code=429, detail="too_many_requests")

    import shop as _sh
    sub = (body.get("sub") or "").strip()
    chat_id = int(body.get("chat_id", 0))
    if not sub or not chat_id:
        raise HTTPException(status_code=400, detail="sub_and_chat_id_required")
    # Validate chat_id is a real Telegram chat ID (positive integer)
    if chat_id <= 0:
        raise HTTPException(status_code=400, detail="invalid_chat_id")

    username = _resolve_username(sub)
    admin_uname = _admin_username_for(username)
    cfg = _bot_effective_cfg(admin_uname)

    if not cfg.get("trial_enabled"):
        raise HTTPException(status_code=403, detail="trial_disabled")
    if _sh.has_used_trial(admin_uname, chat_id):
        raise HTTPException(status_code=409, detail="trial_already_used")

    data_mb = int(cfg.get("trial_data_mb", 100))
    hours = int(cfg.get("trial_hours", 24))

    # Validate trial limits (prevent abuse)
    if data_mb > 1000 or data_mb <= 0:
        raise HTTPException(status_code=500, detail="trial_config_error")
    if hours > 168 or hours <= 0:  # max 7 days
        raise HTTPException(status_code=500, detail="trial_config_error")

    api_key = cfg.get("api_key") or ADMIN_API_KEY
    from panel_api import PanelAPI
    api = PanelAPI(api_key)
    prefix = cfg.get("shop_prefix", "TR")
    trial_username = _sh.next_username(api, prefix)
    now = int(_time.time())
    
    # Get first available service
    services = api.list_services()
    service_id = None
    if services and len(services) > 0:
        service_id = services[0].get("id") or services[0].get("service_id")
    
    payload = {
        "username": trial_username,
        "data_limit": data_mb * 1024 * 1024,
        "expire": now + hours * 3600,
        "status": "active",
    }
    
    if service_id:
        try:
            sid_int = int(service_id)
        except (TypeError, ValueError):
            sid_int = service_id
        payload["service_ids"] = [sid_int]
        payload["service_id"] = sid_int
    
    try:
        api.create_user_v2(payload)
    except Exception:
        api.create_user(payload)

    _sh.record_trial_usage(admin_uname, chat_id, trial_username)

    user = api.get_user(trial_username)
    sub_link = user.get("subscription_url") or user.get("sub") or ""
    return {"ok": True, "username": trial_username, "sub": sub_link,
            "data_mb": data_mb, "hours": hours}


_RENEW_PAGE_PATH = os.path.join(os.path.dirname(__file__), "renew_page.html")


@app.get("/renew", response_class=HTMLResponse)
def renew_page():
    """Serve the self-service renewal page (same style as the sub page)."""
    try:
        with open(_RENEW_PAGE_PATH, "r", encoding="utf-8") as fh:
            return HTMLResponse(fh.read())
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="renew_page_missing")


@app.get("/api/emergency/status")
def status(sub: str):
    """Tell the page which buttons to render for this subscription."""
    username = _resolve_username(sub)
    client = _panel_client()
    user = _get_user(client, username)
    acc = _extract_account(user)
    admin_uname = str(user.get("admin_username") or user.get("admin") or "").strip()
    state = _build_state(username, acc)
    # If this admin has renewal disabled (from panel or bot), force "normal" action
    cfg = _bot_effective_cfg(admin_uname)
    if not cfg.get("renewal_enabled", True):
        state["action"] = "normal"
        state["emergencyUsed"] = False
    return state


@app.post("/api/emergency/charge")
def charge(body: SubBody):
    """
    Apply the one-time emergency top-up:
      * data exhausted, time remaining  -> +200MB data only
      * time expired, data remaining    -> +1 day (from NOW) only
      * both exhausted                  -> +200MB and +1 day (from NOW)
    Re-activates the account and records a baseline for renewal detection.
    Refuses if already used (until an admin renewal resets it) or if the
    account is disabled / still healthy.
    """
    username = _resolve_username(body.sub)

    client = _panel_client()
    user = _get_user(client, username)
    acc = _extract_account(user)

    # ---- guard rails ----
    admin_uname = str(user.get("admin_username") or user.get("admin") or "").strip()
    cfg = _bot_effective_cfg(admin_uname)
    if not cfg.get("renewal_enabled", True):
        raise HTTPException(status_code=403, detail="renewal_disabled")

    rec = _get_charge_record(username)
    if rec and _renewed_since_charge(acc, rec):
        _clear_charge_record(username)
        rec = None
    if rec is not None:
        raise HTTPException(status_code=409, detail="already_used")

    if acc["status"] == "disabled":
        raise HTTPException(status_code=403, detail="account_disabled")

    cond = _compute_conditions(acc)
    exhausted = (
        acc["status"] in ("limited", "expired")
        or cond["time_expired"]
        or cond["data_exhausted"]
    )
    if not exhausted:
        raise HTTPException(status_code=400, detail="not_eligible")

    # ---- compute new values ----
    now = cond["now"]
    new_limit = acc["data_limit"]
    new_expire_epoch = acc["expire_epoch"]

    # Add data if data is exhausted OR unlimited-time accounts that hit limit
    if cond["data_exhausted"] or (acc["data_limit"] > 0 and not cond["time_expired"]):
        # only when data is actually the blocker
        if cond["data_exhausted"]:
            new_limit = acc["data_limit"] + EMERGENCY_DATA_BYTES

    # Add time if time is expired
    if cond["time_expired"]:
        # extend from NOW (a past expiry + 1 day could still be in the past)
        new_expire_epoch = now + EMERGENCY_SECONDS

    # Safety: if neither branch changed anything (e.g. status said limited/expired
    # but raw values looked fine), apply the sensible default based on status.
    if new_limit == acc["data_limit"] and new_expire_epoch == acc["expire_epoch"]:
        if acc["status"] == "expired":
            new_expire_epoch = now + EMERGENCY_SECONDS
        else:  # limited or unknown-but-exhausted
            base_limit = acc["data_limit"] if acc["data_limit"] > 0 else acc["used_traffic"]
            new_limit = base_limit + EMERGENCY_DATA_BYTES

    # ---- build minimal update payload (preserve everything else) ----
    payload = dict(user)  # keep all existing fields
    payload["data_limit"] = new_limit
    payload["expire"] = _epoch_to_same_format(new_expire_epoch, acc["expire_raw"]) if new_expire_epoch else acc["expire_raw"]
    # re-activate
    if isinstance(user.get("status"), dict):
        payload["status"] = "active"
    else:
        payload["status"] = "active"

    updated = _put_user(client, username, payload)

    # ---- re-read to capture the true post-charge baseline ----
    try:
        fresh = _get_user(client, username)
        facc = _extract_account(fresh)
    except HTTPException:
        facc = {"expire_epoch": new_expire_epoch, "data_limit": new_limit,
                "used_traffic": acc["used_traffic"]}

    _save_charge_record(username, facc["expire_epoch"], facc["data_limit"], facc["used_traffic"])

    return {
        "ok": True,
        "applied": {
            "addedDataMB": (new_limit - acc["data_limit"]) // (1024 * 1024),
            "addedDays": EMERGENCY_SECONDS // 86400 if new_expire_epoch != acc["expire_epoch"] else 0,
        },
        "status": "active",
        "emergencyUsed": True,
        "supportUrl": SUPPORT_URL,
    }


# ---- web app (mini app) endpoints ------------------------------------------

_WEBAPP_HTML_PATH = os.path.join(os.path.dirname(__file__), "webapp.html")

@app.get("/webapp/{admin}/{menu_type}")
def webapp_page(admin: str, menu_type: str, request: Request = None):
    """Serve the Web App page with the admin's chosen theme."""
    try:
        import shop as _sh
        cfg = _bot_effective_cfg(admin)
        # Get the appropriate theme for this menu type
        if menu_type == "admin":
            theme = cfg.get("admin_bot_theme", "gradient")
        else:
            theme = cfg.get("user_bot_theme", "gradient")
    except Exception:
        theme = "gradient"
    
    try:
        with open(_WEBAPP_HTML_PATH, "r", encoding="utf-8") as f:
            html = f.read()
        # Inject the theme into the HTML
        html = html.replace("data-theme=\"gradient\"", f"data-theme=\"{theme}\"")
        html = html.replace("params.get('menu')||'user'", f"'{menu_type}'")
        return HTMLResponse(html)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="webapp_not_found")


# ============================================================================
import json as _json
import time as _time
import threading as _threading

os.makedirs(RECEIPT_DIR, exist_ok=True)


# ---- pricing ---------------------------------------------------------------

def _plan_label(days: int) -> str:
    return {30: "۱ ماهه", 60: "۲ ماهه", 90: "۳ ماهه"}.get(days, f"{days} روز")


# ---- DB helpers for orders -------------------------------------------------

def _create_order(username, sub, plan_days, gb, price, admin_username="", discount=0) -> int:
    with _db() as conn:
        cur = conn.execute(
            """INSERT INTO renewal_orders (username, sub, plan_days, gb, price, status, created_at, admin_username, discount)
               VALUES (?,?,?,?,?, 'pending', ?, ?, ?)""",
            (username, sub, plan_days, gb, price, int(_time.time()), admin_username, discount),
        )
        return cur.lastrowid


def _get_order(order_id) -> Optional[sqlite3.Row]:
    with _db() as conn:
        return conn.execute("SELECT * FROM renewal_orders WHERE id=?", (order_id,)).fetchone()


def _set_order_status(order_id, status):
    with _db() as conn:
        conn.execute("UPDATE renewal_orders SET status=?, decided_at=? WHERE id=?",
                     (status, int(_time.time()), order_id))


def _set_order_tg_msg(order_id, msg_id):
    with _db() as conn:
        conn.execute("UPDATE renewal_orders SET tg_message_id=? WHERE id=?", (msg_id, order_id))


# ---- apply a FRESH renewal to a user (reset usage, new limit, expire=now+days)

def _apply_fresh_renewal(username: str, plan_days: int, gb: int) -> dict:
    client = _panel_client()
    user = _get_user(client, username)
    acc = _extract_account(user)
    now = int(_time.time())
    new_limit = gb * 1024 * 1024 * 1024
    new_expire_epoch = now + plan_days * 86400

    payload = dict(user)
    payload["data_limit"] = new_limit
    payload["expire"] = _epoch_to_same_format(new_expire_epoch, acc["expire_raw"])
    payload["status"] = "active"
    # reset usage — try common field names the panel accepts
    payload["used_traffic"] = 0
    try:
        _put_user(client, username, payload)
    except HTTPException:
        # some panels reject used_traffic in PUT; retry without it then call reset
        payload.pop("used_traffic", None)
        _put_user(client, username, payload)
    # best-effort explicit usage reset endpoint
    try:
        client.post(f"{PANEL_BASE_URL}/api/user/{username}/reset")
    except Exception:
        pass

    # clear any emergency-charge lock so the emergency button works again next cycle
    _clear_charge_record(username)
    return {"username": username, "plan_days": plan_days, "gb": gb,
            "expire_epoch": new_expire_epoch, "data_limit": new_limit}


# ---- Telegram helpers ------------------------------------------------------

_TG_API = "https://api.telegram.org/bot{token}/{method}"


def _tg_call(method: str, token: str = "", **kwargs):
    """
    PERF FIX: identical problem to bot.tg() — a new httpx.Client (and therefore
    a new TLS handshake) per Telegram call. Now routed through the shared
    keep-alive pool in tg_client, with 429/5xx handling.
    """
    token = (token or TELEGRAM_BOT_TOKEN or "").strip()
    if not token:
        return None
    files = kwargs.pop("_files", None)
    return tg_client.call(method, token, _files=files, **kwargs)


def _tg_send_receipt(order_id: int, username: str, plan_days: int, gb: int,
                     price: int, receipt_path: str, cfg: dict):
    caption = (
        f"🧾 <b>درخواست تمدید جدید</b>\n"
        f"👤 کاربر: <code>{username}</code>\n"
        f"📦 پلن: {_plan_label(plan_days)} ({plan_days} روز)\n"
        f"📊 حجم: {gb} گیگابایت\n"
        f"💰 مبلغ: {price:,} تومان\n"
        f"🆔 سفارش: #{order_id}"
    )
    kb = {"inline_keyboard": [[
        {"text": "✅ تایید و تمدید", "callback_data": f"approve:{order_id}"},
        {"text": "❌ رد", "callback_data": f"reject:{order_id}"},
    ]]}
    token = cfg.get("bot_token", "")
    sent_any = False
    for admin_id in cfg.get("admin_ids", []):
        try:
            with open(receipt_path, "rb") as fh:
                files = {"photo": (os.path.basename(receipt_path), fh.read())}
            res = _tg_call("sendPhoto", token=token, chat_id=admin_id, caption=caption,
                           parse_mode="HTML", reply_markup=_json.dumps(kb), _files=files)
            if res and res.get("ok"):
                sent_any = True
                _set_order_tg_msg(order_id, res["result"]["message_id"])
        except Exception:
            continue
    return sent_any


def _tg_answer_callback(cb_id, text="", token=""):
    _tg_call("answerCallbackQuery", token=token, callback_query_id=cb_id, text=text)


def _tg_edit_caption(chat_id, message_id, caption, token=""):
    _tg_call("editMessageCaption", token=token, chat_id=chat_id, message_id=message_id,
             caption=caption, parse_mode="HTML")


def _handle_tg_update(update: dict, poll_token: str = ""):
    cb = update.get("callback_query")
    if not cb:
        return
    data = cb.get("data", "")
    cb_id = cb.get("id")
    msg = cb.get("message", {})
    chat_id = msg.get("chat", {}).get("id")
    message_id = msg.get("message_id")
    from_id = str(cb.get("from", {}).get("id", ""))

    if ":" not in data:
        return
    action, _, oid = data.partition(":")
    try:
        order_id = int(oid)
    except ValueError:
        return
    order = _get_order(order_id)
    if not order:
        _tg_answer_callback(cb_id, "سفارش یافت نشد", token=poll_token)
        return

    # resolve this order's admin config; only that admin's ids may decide
    admin_uname = order["admin_username"] if "admin_username" in order.keys() else ""
    cfg = _resolve_admin_cfg(admin_uname or "")
    token = cfg.get("bot_token", "") or poll_token
    allowed = [str(x) for x in cfg.get("admin_ids", [])]
    if allowed and from_id not in allowed:
        _tg_answer_callback(cb_id, "شما مجاز نیستید", token=token)
        return

    if order["status"] != "pending":
        _tg_answer_callback(cb_id, f"قبلاً {order['status']} شده", token=token)
        return

    base = (
        f"👤 کاربر: <code>{order['username']}</code>\n"
        f"📦 پلن: {_plan_label(order['plan_days'])} ({order['plan_days']} روز)\n"
        f"📊 حجم: {order['gb']} گیگابایت\n"
        f"💰 مبلغ: {order['price']:,} تومان\n"
        f"🆔 سفارش: #{order_id}"
    )

    if action == "approve":
        try:
            _apply_fresh_renewal(order["username"], order["plan_days"], order["gb"])
            _set_order_status(order_id, "approved")
            # consume any referral discount credit and grant referrer bonus
            try:
                import referrals as _rf
                _rf.consume_credit_on_approval(order["username"])
            except Exception:
                pass
            _tg_answer_callback(cb_id, "تمدید شد ✅", token=token)
            _tg_edit_caption(chat_id, message_id, "✅ <b>تایید و تمدید شد</b>\n" + base, token=token)
        except Exception as e:
            _tg_answer_callback(cb_id, "خطا در تمدید", token=token)
            _tg_edit_caption(chat_id, message_id,
                             f"⚠️ <b>خطا در تمدید</b> ({str(e)[:60]})\n" + base, token=token)
    elif action == "reject":
        _set_order_status(order_id, "rejected")
        _tg_answer_callback(cb_id, "❌ رد شد", token=token)
        _tg_edit_caption(chat_id, message_id, "❌ <b>رد شد</b>\n" + base, token=token)
        # Notify the user about rejection
        _notify_renewal_rejection(order, token)


def _create_vpn_account(admin_uname: str, base_username: str, plan_days: int, gb: int,
                        service_id: str = "") -> dict:
    """Create a fresh VPN user in the panel for the given admin, using that
    admin's own api key. Returns {username, sub}."""
    import shop as _shop
    from panel_api import PanelAPI, PanelError
    cfg = _bot_effective_cfg(admin_uname)
    api_key = cfg.get("api_key") or ADMIN_API_KEY
    prefix = cfg.get("shop_prefix") or "ST"
    api = PanelAPI(api_key)
    username = base_username or _shop.next_username(api, prefix)
    now = int(_time.time())
    payload = {
        "username": username,
        "data_limit": gb * 1024 * 1024 * 1024 if gb > 0 else 0,
        "expire": (now + plan_days * 86400) if plan_days > 0 else 0,
        "status": "active",
    }
    # pick the service: the one chosen for this order (package), else the first
    sid = service_id or ""
    if not sid:
        try:
            svcs = api.list_services()
            if svcs:
                sid = svcs[0].get("id") or svcs[0].get("service_id")
        except Exception:
            sid = ""
    if sid not in ("", None):
        payload["service_ids"] = [int(sid)] if str(sid).isdigit() else [sid]
        payload["service_id"] = payload["service_ids"][0]
    try:
        res = api.create_user_v2(payload)
    except PanelError:
        res = api.create_user(payload)
    sub = res.get("subscription_url") or res.get("sub") or ""
    if not sub:
        # fetch the created user to get its sub link
        try:
            u = api.get_user(username)
            sub = u.get("subscription_url") or u.get("sub") or ""
        except Exception:
            pass
    return {"username": username, "sub": sub}


def _handle_shop_update(update: dict, poll_token: str = ""):
    """Approve/reject a SHOP order from the admin's Telegram bot."""
    import shop as _shop
    cb = update.get("callback_query")
    if not cb:
        return
    data = cb.get("data", "")
    cb_id = cb.get("id")
    msg = cb.get("message", {})
    chat_id = msg.get("chat", {}).get("id")
    message_id = msg.get("message_id")
    from_id = str(cb.get("from", {}).get("id", ""))

    action, _, oid = data.partition(":")
    try:
        order_id = int(oid)
    except ValueError:
        return
    order = _shop.get_order(order_id)
    if not order:
        _tg_answer_callback(cb_id, "سفارش یافت نشد", token=poll_token)
        return

    admin_uname = order.get("admin_username") or ""
    cfg = _resolve_admin_cfg(admin_uname)
    token = cfg.get("bot_token", "") or poll_token
    allowed = [str(x) for x in cfg.get("admin_ids", [])]
    if allowed and from_id not in allowed:
        _tg_answer_callback(cb_id, "شما مجاز نیستید", token=token)
        return
    if order["status"] != "pending":
        _tg_answer_callback(cb_id, f"قبلاً {order['status']} شده", token=token)
        return

    is_renew = order["type"] == "renew"
    base = (
        f"{'🔄 تمدید' if is_renew else '🛒 خرید'} — سفارش #{order_id}\n"
        f"📦 پلن: {_plan_label(order['plan_days'])} ({order['plan_days']} روز)\n"
        f"📊 حجم: {order['gb']} گیگابایت\n"
        f"💰 مبلغ: {order['price']:,} تومان"
    )

    if action == "shopok":
        try:
            if is_renew:
                _apply_fresh_renewal(order["target_user"], order["plan_days"], order["gb"])
                created_user, created_sub = order["target_user"], ""
            else:
                created = _create_vpn_account(admin_uname, "", order["plan_days"], order["gb"],
                                             service_id=order.get("service_id") or "")
                created_user, created_sub = created["username"], created["sub"]
                _shop.link_vpn(order["shop_user_id"], created_user, created_sub)
            _shop.set_order_status(order_id, "approved", created_user, created_sub)
            _tg_answer_callback(cb_id, "تایید شد ✅", token=token)
            extra = f"\n👤 اکانت: <code>{created_user}</code>" if created_user else ""
            _tg_edit_caption(chat_id, message_id, "✅ <b>تایید شد</b>\n" + base + extra, token=token)
            # ---- notify the bot user about approval ----
            _notify_buyer(order, created_user, created_sub, token)
            # ---- auto-register the buyer in user_registry (so menus appear) ----
            if not is_renew and created_user and created_sub:
                _auto_register_buyer(order, created_user, admin_uname, created_sub)
        except Exception as e:
            _tg_answer_callback(cb_id, "خطا در انجام سفارش", token=token)
            _tg_edit_caption(chat_id, message_id,
                             f"⚠️ <b>خطا</b> ({str(e)[:60]})\n" + base, token=token)

    elif action == "shopno":
        # Step 1: Show rejection options as a NEW message
        _tg_answer_callback(cb_id, token=token)
        reject_msg = (
            f"❌ <b>رد درخواست سفارش #{order_id}</b>\n\n"
            f"{base}\n\n"
            "یکی از گزینه‌ها را انتخاب کنید:"
        )
        reject_kb = {"inline_keyboard": [
            [{"text": "⚡️ رد بدون دلیل", "callback_data": f"shopno_noreason:{order_id}"}],
            [{"text": "✍️ نوشتن دلیل رد", "callback_data": f"shopno_ask_reason:{order_id}"}],
            [{"text": "⛔️ رد و مسدود کردن کاربر", "callback_data": f"shopno_block:{order_id}"}],
            [{"text": "❌ انصراف", "callback_data": f"shopno_cancel:{order_id}"}],
        ]}
        _tg_call("sendMessage", token=token, chat_id=chat_id, text=reject_msg,
                 parse_mode="HTML", reply_markup=_json.dumps(reject_kb))

    elif action == "shopno_noreason":
        # Reject without reason
        _shop.set_order_status(order_id, "rejected", reject_reason="بدون دلیل")
        _tg_answer_callback(cb_id, "❌ رد شد (بدون دلیل)", token=token)
        _tg_edit_caption(chat_id, message_id,
                         "❌ <b>رد شد</b>\nدلیل: بدون دلیل\n" + base, token=token)
        _pending_rejections.pop(chat_id, None)
        _notify_rejection(order, "بدون دلیل", token)

    elif action == "shopno_block":
        # Reject + block user (no reason asked)
        reason = "سفارش مشکوک — کاربر مسدود شد"
        _shop.set_order_status(order_id, "rejected", reject_reason=reason)
        _tg_answer_callback(cb_id, "⛔️ رد شد و کاربر مسدود شد", token=token)
        _tg_edit_caption(chat_id, message_id,
                         f"⛔️ <b>رد شد و کاربر مسدود شد</b>\nدلیل: {reason}\n" + base, token=token)
        _pending_rejections.pop(chat_id, None)
        _block_shop_user(order, token)
        _notify_rejection(order, reason, token)

    elif action == "shopno_cancel":
        # Cancel rejection
        _tg_answer_callback(cb_id, "لغو شد", token=token)
        _tg_edit_caption(chat_id, message_id, base, token=token)
        _pending_rejections.pop(chat_id, None)

    elif action == "shopno_ask_reason":
        # Admin wants to type a custom reason
        _tg_answer_callback(cb_id, token=token)
        _pending_rejections[chat_id] = {
            "state": "waiting_reason",
            "order_id": order_id,
            "admin_uname": admin_uname,
            "token": token,
            "chat_id": chat_id,
            "message_id": message_id,
            "base": base,
            "order": dict(order),
        }
        ask_msg = (
            f"✍️ <b>نوشتن دلیل رد</b>\n\n"
            f"سفارش #{order_id}\n"
            f"{base}\n\n"
            "دلیل رد درخواست را بنویسید:"
        )
        ask_kb = {"inline_keyboard": [
            [{"text": "❌ انصراف", "callback_data": f"shopno_cancel:{order_id}"}],
        ]}
        _tg_call("sendMessage", token=token, chat_id=chat_id, text=ask_msg,
                 parse_mode="HTML", reply_markup=_json.dumps(ask_kb))

    elif action == "shopno_confirm":
        # Admin confirmed the typed reason
        reason = _pending_rejections.get(chat_id, {}).get("reason", "")
        if not reason:
            _tg_answer_callback(cb_id, "❗️ دلیل رد خالی است", token=token)
            return
        _shop.set_order_status(order_id, "rejected", reject_reason=reason)
        _tg_answer_callback(cb_id, "✅ رد شد", token=token)
        _tg_edit_caption(chat_id, message_id,
                         f"❌ <b>رد شد</b>\nدلیل: {reason}\n" + base, token=token)
        _pending_rejections.pop(chat_id, None)
        _notify_rejection(order, reason, token)

    elif action == "shopno_block_with_reason":
        # Admin typed a reason AND wants to block the user
        reason = _pending_rejections.get(chat_id, {}).get("reason", "")
        if not reason:
            reason = "سفارش مشکوک"
        full_reason = f"{reason} — کاربر مسدود شد"
        _shop.set_order_status(order_id, "rejected", reject_reason=full_reason)
        _tg_answer_callback(cb_id, "⛔️ رد شد و کاربر مسدود شد", token=token)
        _tg_edit_caption(chat_id, message_id,
                         f"⛔️ <b>رد شد و کاربر مسدود شد</b>\nدلیل: {full_reason}\n" + base, token=token)
        _pending_rejections.pop(chat_id, None)
        _block_shop_user(order, token)
        _notify_rejection(order, full_reason, token)


def _tg_poll_one(token: str, stop=None):
    """Long-poll a single bot token and dispatch updates concurrently.

    FIXES APPLIED HERE
    ------------------
    1. The poll used `with httpx.Client(timeout=60.0)` per cycle -> a fresh TLS
       handshake every 50 s and, worse, a cold pool. It now uses the shared
       keep-alive polling client in tg_client.
    2. `allowed_updates` was not set, so Telegram streamed edited_message /
       channel_post / poll / chat_member updates that this bot immediately
       discards. Now only the 3 kinds we actually handle are requested.
    3. The worker pool was hard-coded to 8 threads for ALL users of the bot.
       Every handler is blocking (sync httpx to the panel + sqlite), so 8 slow
       admin actions froze the bot for everyone else. It is now configurable
       and defaults to 32.
    4. Updates from the SAME chat were dispatched in parallel, so a user's two
       fast taps could be processed out of order (classic "menu jumps back"
       bug). Updates are now serialised per chat while staying parallel
       across chats.
    5. A `getUpdates` 409 Conflict (another instance polling the same token, or
       a leftover webhook) used to spin in a tight 3 s retry loop forever with
       no log line. It is now detected, reported, and the webhook is dropped.
    6. On a network error the loop slept a flat 3 s; it now backs off
       progressively so a panel/network outage does not hammer the API.
    """
    pool = _ChatSerialPool(max_workers=_BOT_WORKERS)
    offset = None
    backoff = 1.0
    stop = stop if stop is not None else threading.Event()
    while not stop.is_set():
        try:
            data = tg_client.get_updates(token, offset, timeout=50)
            if stop.is_set():
                break
            if data is None:
                stop.wait(backoff)
                backoff = min(backoff * 2, 30.0)
                continue
            if not data.get("ok"):
                code = data.get("error_code")
                if code == 409:
                    # Another poller / a webhook owns this token.
                    print("[tg-poll] 409 conflict for a configured bot")
                    tg_client.call("deleteWebhook", token, drop_pending_updates=False)
                    stop.wait(5)
                    continue
                if code == 401:
                    print("[tg-poll] invalid bot token — stopping its poller")
                    return
                stop.wait(backoff)
                backoff = min(backoff * 2, 30.0)
                continue

            backoff = 1.0
            for upd in data.get("result", []):
                offset = upd["update_id"] + 1
                pool.submit(_update_chat_key(upd), _dispatch_update_safe, upd, token)
        except Exception as exc:
            print(f"[tg-poll] loop error: {type(exc).__name__}")
            stop.wait(backoff)
            backoff = min(backoff * 2, 30.0)


def _update_chat_key(upd: dict) -> str:
    """The chat an update belongs to — used to keep per-chat ordering."""
    for key in ("message", "edited_message", "my_chat_member"):
        part = upd.get(key)
        if part:
            return str((part.get("chat") or {}).get("id", ""))
    cb = upd.get("callback_query")
    if cb:
        return str(((cb.get("message") or {}).get("chat") or {}).get("id", ""))
    return ""


class _ChatSerialPool:
    """A thread pool that guarantees FIFO ordering of jobs per chat_id.

    Without this, two quick taps from one user race each other on the pool and
    the second answer can overwrite the first — the bot looked "buggy" and
    "jumpy". Different chats still run fully in parallel.
    """

    def __init__(self, max_workers: int = 32):
        from concurrent.futures import ThreadPoolExecutor
        self._pool = ThreadPoolExecutor(max_workers=max_workers,
                                        thread_name_prefix="tg-worker")
        self._queues: dict = {}
        self._lock = _threading.Lock()

    def submit(self, key, fn, *args):
        with self._lock:
            queue = self._queues.get(key)
            if queue is None:
                queue = self._queues[key] = []
            queue.append((fn, args))
            if len(queue) > 1:
                return  # a worker is already draining this chat's queue
        self._pool.submit(self._drain, key)

    def _drain(self, key):
        while True:
            with self._lock:
                queue = self._queues.get(key)
                if not queue:
                    self._queues.pop(key, None)
                    return
                fn, args = queue[0]
            try:
                fn(*args)
            except Exception:
                pass
            with self._lock:
                queue = self._queues.get(key)
                if queue:
                    queue.pop(0)
                if not queue:
                    self._queues.pop(key, None)
                    return


def _dispatch_update_safe(upd: dict, token: str):
    try:
        if token in _all_bot_tokens():
            _dispatch_update(upd, token)
    except Exception as exc:
        import traceback
        print(f"[tg-dispatch] {exc}")
        traceback.print_exc()



def _dispatch_update(upd: dict, token: str):
    """Route a Telegram update: legacy approve/reject stays here, everything
    else (menus, search, management) goes to the full bot module.

    FIX: the import error used to be swallowed silently (`except: _bot = None`),
    so a syntax error or a missing dependency in bot.py turned the whole bot
    into a black hole with zero log output. It is now logged once.
    """
    global _BOT_MODULE
    _bot = _BOT_MODULE
    if _bot is None:
        try:
            import bot as _bot  # noqa: PLC0415
            _BOT_MODULE = _bot
        except Exception as exc:
            if not getattr(_dispatch_update, "_warned", False):
                import traceback
                print(f"[tg-dispatch] cannot import bot.py: {exc}")
                traceback.print_exc()
                _dispatch_update._warned = True
            _bot = None

    if "callback_query" in upd:
        data = upd["callback_query"].get("data", "")
        if data.startswith("approve:") or data.startswith("reject:"):
            _handle_tg_update(upd, poll_token=token)
            return
        if (data.startswith("shopok:") or data.startswith("shopno:")
                or data.startswith("shopno_noreason:") or data.startswith("shopno_block:")
                or data.startswith("shopno_block_with_reason:")
                or data.startswith("shopno_ask_reason:")
                or data.startswith("shopno_cancel:") or data.startswith("shopno_confirm:")):
            _handle_shop_update(upd, poll_token=token)
            return
        if _bot:
            _bot.handle_callback(upd, token, legacy_order_handler=lambda u, t: _handle_tg_update(u, poll_token=t))
        return

    if "message" in upd:
        msg = upd.get("message") or {}
        if _bot and _bot.is_admin_onboarding_input(msg, token):
            _bot.handle_message(upd, token)
            return
        # Other free-text flows still go through pending rejection first.
        chat_id = msg.get("chat", {}).get("id")
        text = (msg.get("text") or "").strip()
        if chat_id and text and not msg.get("photo") and not msg.get("document"):
            if _handle_reject_reason_text(chat_id, text):
                return
        if _bot:
            _bot.handle_message(upd, token)
        return


_pollers = {}
_pollers_lock = threading.Lock()


def _run_tg_poller(token, stop):
    try:
        if stop.is_set():
            return
        tg_client.call("deleteWebhook", token, drop_pending_updates=False)
        _tg_poll_one(token, stop)
    except Exception as e:
        print(f"[tg-poll] startup failed: {type(e).__name__}")


def _tg_poll_loop():
    """Reconcile tokens once; kept as the startup helper for existing callers."""
    with _pollers_lock:
        tokens = set(_all_bot_tokens())
        for tok, (thread, stop) in list(_pollers.items()):
            if tok not in tokens:
                stop.set()
                if not thread.is_alive():
                    del _pollers[tok]
            elif stop.is_set() and not thread.is_alive():
                del _pollers[tok]
        for tok in tokens - _pollers.keys():
            stop = threading.Event()
            thread = _threading.Thread(target=_run_tg_poller, args=(tok, stop), name="tg-poll", daemon=True)
            _pollers[tok] = (thread, stop)
            thread.start()


def _watch_bot_tokens():
    while not _maintenance_stop.wait(5):
        try:
            _tg_poll_loop()
        except Exception as e:
            print(f"[tg-poll] sync failed: {type(e).__name__}")


# ---- renewal API endpoints -------------------------------------------------

@app.get("/api/renew/plans")
def renew_plans(sub: str):
    """Return plan pricing + card info + packages for the renewal page (per owning admin)."""
    username = _resolve_username(sub)
    admin_uname = _admin_username_for(username)
    cfg = _bot_effective_cfg(admin_uname)

    # Get packages from shop system (if any)
    packages = []
    try:
        import shop as _sh
        packages = _sh.list_packages(admin_uname, enabled_only=True)
    except Exception:
        pass

    # Build plans from packages if available, otherwise use default prices
    if packages:
        # Collect all unique plan days from all packages
        all_days = set()
        for pk in packages:
            for d in pk.get("prices", {}):
                all_days.add(int(d))
        # Use the first package's prices as default plan display
        first_pkg = packages[0]
        pk_prices = first_pkg.get("prices", {})
        plans = [
            {"days": d, "label": _plan_label(d), "pricePerGB": pk_prices.get(d, pk_prices.get(str(d), 0))}
            for d in sorted(all_days)
        ]
    else:
        prices = cfg.get("prices") or PLAN_PRICES
        plan_list = cfg.get("plans") or sorted(prices)
        plans = [
            {"days": d, "label": _plan_label(d), "pricePerGB": prices[d]}
            for d in plan_list if d in prices
        ]

    # Get random card from admin_cards table, fallback to default config
    import shop as _sh
    random_card = _sh.get_random_card(admin_uname)
    if not random_card:
        random_card = {"number": cfg.get("card_number", ""), "holder": cfg.get("card_holder", ""), "bank": cfg.get("card_bank", "")}

    # Get per-admin min/max GB from settings
    admin_cfg = _bot_effective_cfg(admin_uname)
    admin_min_gb = int(admin_cfg.get("minGB", MIN_GB))
    admin_max_gb = int(admin_cfg.get("maxGB", MAX_GB))
    
    return {
        "username": username,
        "minGB": admin_min_gb,
        "maxGB": admin_max_gb,
        "plans": plans,
        "packages": [{"id": p["id"], "name": p["name"], "note": p.get("note", ""),
                       "prices": {int(k): int(v) for k, v in p.get("prices", {}).items()}}
                      for p in packages],
        "card": random_card,
    }


@app.post("/api/renew/submit")
async def renew_submit(
    sub: str = Form(...),
    plan_days: int = Form(...),
    gb: int = Form(...),
    receipt: UploadFile = File(...),
    package_id: int = Form(0),
    discount_code: str = Form(""),
):
    """Create a pending renewal order and forward the receipt to the owning admin's bot."""
    username = _resolve_username(sub)
    admin_uname = _admin_username_for(username)
    cfg = _bot_effective_cfg(admin_uname)

    # Determine pricing: from package if selected, otherwise from default config
    prices = cfg.get("prices") or PLAN_PRICES
    if package_id:
        try:
            import shop as _sh
            pkg = _sh.get_package(package_id)
            if pkg and pkg.get("enabled") and pkg.get("admin_username") == admin_uname:
                pkg_prices = pkg.get("prices", {})
                prices = {int(k): int(v) for k, v in pkg_prices.items()}
        except Exception:
            pass

    if plan_days not in prices:
        raise HTTPException(status_code=400, detail="invalid_plan")
    if gb < MIN_GB:
        raise HTTPException(status_code=400, detail=f"min_gb_{MIN_GB}")
    if gb > MAX_GB:
        raise HTTPException(status_code=400, detail=f"max_gb_{MAX_GB}")

    # validate the uploaded file is an image and not too big
    content = await receipt.read()
    if len(content) > 8 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="file_too_large")
    ctype = (receipt.content_type or "").lower()
    if not ctype.startswith("image/"):
        raise HTTPException(status_code=400, detail="not_an_image")

    base_price = prices[plan_days] * gb

    # Apply discount code if provided
    discount_amount = 0
    if discount_code:
        try:
            import shop as _sh
            disc_info = _sh.validate_discount_code(admin_uname, discount_code)
            discount_amount = _sh.calculate_discount(base_price, disc_info)
        except ValueError:
            discount_amount = 0

    price = max(0, base_price - discount_amount)
    order_id = _create_order(username, sub, plan_days, gb, price, admin_username=admin_uname)

    ext = ".jpg"
    if "png" in ctype:
        ext = ".png"
    elif "webp" in ctype:
        ext = ".webp"
    path = os.path.join(RECEIPT_DIR, f"order_{order_id}{ext}")
    with open(path, "wb") as fh:
        fh.write(content)

    if not cfg.get("bot_token") or not cfg.get("admin_ids"):
        raise HTTPException(status_code=500, detail="bot_not_configured")

    sent = _tg_send_receipt(order_id, username, plan_days, gb, price, path, cfg)
    if not sent:
        raise HTTPException(status_code=502, detail="telegram_send_failed")

    return {"ok": True, "orderId": order_id, "price": price,
            "plan": _plan_label(plan_days), "gb": gb}


@app.get("/api/renew/order/{order_id}")
def renew_order_status(order_id: int):
    o = _get_order(order_id)
    if not o:
        raise HTTPException(status_code=404, detail="order_not_found")
    return {"orderId": o["id"], "status": o["status"], "gb": o["gb"],
            "planDays": o["plan_days"], "price": o["price"]}


# ============================================================================
#  SHOP PORTAL (customer accounts + purchase)
# ============================================================================

SHOP_COOKIE = "shop_session"
_SHOP_PAGE_PATH = os.path.join(os.path.dirname(__file__), "shop.html")


@app.get("/shop", response_class=HTMLResponse)
def shop_page():
    try:
        with open(_SHOP_PAGE_PATH, "r", encoding="utf-8") as fh:
            return HTMLResponse(fh.read())
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="shop_page_missing")


def _shop_admin_ok(admin: str) -> dict:
    """Validate the admin exists and has the shop enabled. Returns its cfg."""
    admins = _load_admins_config()
    if admin not in admins:
        raise HTTPException(status_code=404, detail="admin_not_found")
    cfg = _bot_effective_cfg(admin)
    if not cfg.get("shop_enabled"):
        raise HTTPException(status_code=403, detail="shop_disabled")
    return cfg


def _shop_session(request: Request) -> dict:
    import shop as _shop
    tok = request.cookies.get(SHOP_COOKIE, "")
    sess = _shop.check_session(tok)
    if not sess:
        raise HTTPException(status_code=401, detail="unauthorized")
    return sess


class ShopAuthBody(BaseModel):
    admin: str
    username: str
    password: str
    email: str = ""
    phone: str = ""


@app.post("/api/shop/register")
def shop_register(body: ShopAuthBody):
    import shop as _shop
    _shop_admin_ok(body.admin)
    if len(body.password) < 6:
        raise HTTPException(status_code=400, detail="password_too_short")
    if not body.username or " " in body.username:
        raise HTTPException(status_code=400, detail="bad_username")
    try:
        uid = _shop.create_account(body.admin, body.username.strip(),
                                   body.password, body.email, body.phone)
    except ValueError:
        raise HTTPException(status_code=409, detail="username_taken")
    resp = JSONResponse({"ok": True, "username": body.username.strip()})
    resp.set_cookie(SHOP_COOKIE, _shop.make_session(uid, body.admin),
                    httponly=True, samesite="lax", max_age=_shop.SESSION_TTL)
    return resp


@app.post("/api/shop/login")
def shop_login(body: ShopAuthBody):
    import shop as _shop
    _shop_admin_ok(body.admin)
    acc = _shop.authenticate(body.admin, body.username.strip(), body.password)
    if not acc:
        raise HTTPException(status_code=401, detail="bad_credentials")
    resp = JSONResponse({"ok": True, "username": acc["username"]})
    resp.set_cookie(SHOP_COOKIE, _shop.make_session(acc["id"], body.admin),
                    httponly=True, samesite="lax", max_age=_shop.SESSION_TTL)
    return resp


@app.post("/api/shop/logout")
def shop_logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(SHOP_COOKIE)
    return resp


@app.get("/api/shop/plans")
def shop_plans(admin: str):
    import shop as _shop
    cfg = _shop_admin_ok(admin)
    prices = cfg.get("prices") or PLAN_PRICES
    plans = cfg.get("plans") or sorted(prices)
    # per-service packages (if the admin defined any)
    packages = []
    for p in _shop.list_packages(admin, enabled_only=True):
        packages.append({
            "id": p["id"], "name": p["name"], "note": p.get("note") or "",
            "plans": [{"days": d, "label": _plan_label(d), "pricePerGB": p["prices"][d]}
                      for d in sorted(p["prices"])],
        })
    # Get random card from admin_cards table, fallback to default config
    random_card = _shop.get_random_card(admin)
    if not random_card:
        random_card = {"number": cfg.get("card_number", ""), "holder": cfg.get("card_holder", ""), "bank": cfg.get("card_bank", "")}
    # Get per-admin min/max GB from settings
    admin_min_gb = int(cfg.get("minGB", MIN_GB))
    admin_max_gb = int(cfg.get("maxGB", MAX_GB))
    return {
        "minGB": admin_min_gb, "maxGB": admin_max_gb,
        # legacy flat plans (used when the admin has NO packages)
        "plans": [{"days": d, "label": _plan_label(d), "pricePerGB": prices[d]}
                  for d in plans if d in prices],
        "packages": packages,
        "card": random_card,
    }


@app.get("/api/shop/services")
def shop_services(admin: str, request: Request = None):
    """List the panel services for an admin (used when building packages).
    Requires the caller to be the logged-in owner OR the install panel; here we
    simply require a valid shop session for that admin, or allow if called
    server-side. Kept minimal: needs a valid shop session."""
    from panel_api import PanelAPI
    _shop_admin_ok(admin)
    api_key = _bot_effective_cfg(admin).get("api_key") or ADMIN_API_KEY
    try:
        svcs = PanelAPI(api_key).list_services()
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"services_error:{str(e)[:100]}")
    out = []
    for s in svcs:
        sid = s.get("id") or s.get("service_id") or s.get("_id")
        name = s.get("name") or s.get("title") or f"سرویس {sid}"
        if sid is not None:
            out.append({"id": sid, "name": name})
    return {"services": out}


@app.get("/api/shop/me")
def shop_me(request: Request):
    import shop as _shop
    sess = _shop_session(request)
    acc = _shop.get_account(sess["shop_user_id"])
    if not acc:
        raise HTTPException(status_code=401, detail="unauthorized")
    admin = sess["admin"]
    api_key = _bot_effective_cfg(admin).get("api_key") or ADMIN_API_KEY
    from panel_api import PanelAPI
    api = PanelAPI(api_key)

    accounts = []
    stale = []
    for link in _shop.list_vpn(sess["shop_user_id"]):
        uname = link["vpn_username"]
        try:
            u = api.get_user(uname)
        except Exception:
            stale.append(uname)   # deleted from panel
            continue
        a = _extract_account(u)
        gb = 1024 ** 3
        days = -1
        if a["expire_epoch"]:
            days = max(0, (a["expire_epoch"] - int(_time.time())) // 86400)
        accounts.append({
            "username": uname,
            "sub": link["sub"] or (u.get("subscription_url") or ""),
            "status": a["status"],
            "dataLimit": a["data_limit"],
            "usedGb": round(a["used_traffic"] / gb, 2),
            "totalGb": round(a["data_limit"] / gb, 1),
            "days": days,
        })
    for s in stale:
        _shop.unlink_vpn(sess["shop_user_id"], s)

    history = []
    for o in _shop.list_orders(sess["shop_user_id"]):
        history.append({
            "id": o["id"], "type": o["type"], "gb": o["gb"],
            "planDays": o["plan_days"], "price": o["price"],
            "status": o["status"],
            "date": _time.strftime("%Y/%m/%d", _time.localtime(o["created_at"] or 0)),
        })
    return {"username": acc["username"], "accounts": accounts, "history": history}


@app.post("/api/shop/buy")
async def shop_buy(
    request: Request,
    plan_days: int = Form(...),
    gb: int = Form(...),
    receipt: UploadFile = File(...),
    target_user: str = Form(""),
    package_id: int = Form(0),
):
    import shop as _shop
    sess = _shop_session(request)
    admin = sess["admin"]
    cfg = _shop_admin_ok(admin)

    # resolve pricing + service from a package if given, else flat plans
    service_id = ""
    package_name = ""
    if package_id:
        pkg = _shop.get_package(package_id)
        if not pkg or pkg["admin_username"] != admin or not pkg["enabled"]:
            raise HTTPException(status_code=400, detail="invalid_package")
        if plan_days not in pkg["prices"]:
            raise HTTPException(status_code=400, detail="invalid_plan")
        per_gb = pkg["prices"][plan_days]
        service_id = pkg["service_id"]
        package_name = pkg["name"]
    else:
        prices = cfg.get("prices") or PLAN_PRICES
        if plan_days not in prices:
            raise HTTPException(status_code=400, detail="invalid_plan")
        per_gb = prices[plan_days]

    if gb < MIN_GB:
        raise HTTPException(status_code=400, detail=f"min_gb_{MIN_GB}")
    if gb > MAX_GB:
        raise HTTPException(status_code=400, detail=f"max_gb_{MAX_GB}")

    content = await receipt.read()
    if len(content) > 8 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="file_too_large")
    if not (receipt.content_type or "").lower().startswith("image/"):
        raise HTTPException(status_code=400, detail="not_an_image")

    price = per_gb * gb
    otype = "renew" if target_user else "buy"
    order_id = _shop.create_order(sess["shop_user_id"], admin, otype,
                                  plan_days, gb, price, target_user,
                                  service_id=service_id, package_name=package_name)

    ext = ".jpg"
    ct = (receipt.content_type or "").lower()
    if "png" in ct: ext = ".png"
    elif "webp" in ct: ext = ".webp"
    path = os.path.join(RECEIPT_DIR, f"shop_{order_id}{ext}")
    with open(path, "wb") as fh:
        fh.write(content)

    if not cfg.get("bot_token") or not cfg.get("admin_ids"):
        raise HTTPException(status_code=500, detail="bot_not_configured")

    acc = _shop.get_account(sess["shop_user_id"])
    _shop_send_receipt(order_id, acc, otype, plan_days, gb, price, target_user,
                       path, cfg, package_name)
    return {"ok": True, "orderId": order_id, "price": price}



@app.get("/api/shop/order/{order_id}")
def shop_order_status(order_id: int, request: Request):
    import shop as _shop
    sess = _shop_session(request)
    o = _shop.get_order(order_id)
    if not o or o["shop_user_id"] != sess["shop_user_id"]:
        raise HTTPException(status_code=404, detail="order_not_found")
    return {"status": o["status"], "createdUser": o.get("created_user") or "",
            "sub": o.get("created_sub") or ""}


def _shop_send_receipt(order_id, acc, otype, plan_days, gb, price, target_user, path, cfg, package_name=""):
    label = "🔄 درخواست تمدید (فروشگاه)" if otype == "renew" else "🛒 درخواست خرید جدید (فروشگاه)"
    caption = (
        f"{label}\n"
        f"🧑 مشتری: <code>{acc['username']}</code>\n"
        + (f"📧 {acc.get('email')}\n" if acc.get('email') else "")
        + (f"📱 {acc.get('phone')}\n" if acc.get('phone') else "")
        + (f"🎯 اکانت: <code>{target_user}</code>\n" if target_user else "")
        + (f"🧩 سرویس: {package_name}\n" if package_name else "")
        + f"📦 پلن: {_plan_label(plan_days)} ({plan_days} روز)\n"
        f"📊 حجم: {gb} گیگابایت\n"
        f"💰 مبلغ: {price:,} تومان\n"
        f"🆔 سفارش: #{order_id}"
    )
    kb = {"inline_keyboard": [[
        {"text": "✅ تایید", "callback_data": f"shopok:{order_id}"},
        {"text": "❌ رد", "callback_data": f"shopno:{order_id}"},
    ]]}
    token = cfg.get("bot_token", "")
    import shop as _shop
    for admin_id in cfg.get("admin_ids", []):
        try:
            with open(path, "rb") as fh:
                files = {"photo": (os.path.basename(path), fh.read())}
            res = _tg_call("sendPhoto", token=token, chat_id=admin_id, caption=caption,
                           parse_mode="HTML", reply_markup=_json.dumps(kb), _files=files)
            if res and res.get("ok"):
                _shop.set_order_msg(order_id, res["result"]["message_id"])
        except Exception:
            continue


# start the Telegram poller(s) on app startup — one thread per distinct bot token
@app.on_event("startup")
def _start_tg_poller():
    _tg_poll_loop()
    _threading.Thread(target=_watch_bot_tokens, name="tg-poll-watch", daemon=True).start()
