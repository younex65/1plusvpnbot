"""
dbx.py — one shared, correctly-configured SQLite layer for the whole app.
=========================================================================

WHY THIS FILE EXISTS (cause #2 of the slowness / "database is locked" bugs)
---------------------------------------------------------------------------
There were FOUR independent copies of the same broken pattern in app.py,
bot_settings.py, user_registry.py, shop.py and referrals.py:

    _lock = threading.Lock()

    @contextmanager
    def _conn():
        with _lock:                       # <-- global mutex
            conn = sqlite3.connect(PATH)  # <-- new connection every call
            ...
            conn.close()

Three separate problems, all of them user-visible:

1. `sqlite3.connect()` on every query. Each connect re-opens the file,
   re-reads the header and re-plans; and because the connection is thrown
   away, SQLite's page cache is cold every single time.

2. A **process-wide mutex around every read**. The bot dispatches updates on a
   thread pool, but every one of those threads had to queue behind the same
   lock for even a trivial `SELECT`. And the lock in each module was a
   *different* lock guarding the *same* database file, so they did not even
   protect each other — they only serialised themselves.

3. Default journal mode (DELETE) and **no busy_timeout**. Any concurrent write
   from the notifier thread, the FastAPI request threads or the bot workers
   instantly raised `sqlite3.OperationalError: database is locked`, which the
   callers swallowed — so settings silently failed to save.

The fix: WAL journal mode (readers never block the writer, writer never blocks
readers), a real `busy_timeout`, one cached connection per thread, and
`check_same_thread=False` off the hot path. A single small write lock is kept
because SQLite allows only one writer at a time — but reads are now fully
parallel.
"""
from __future__ import annotations

import os
import sqlite3
import threading
from contextlib import contextmanager

# Milliseconds SQLite will wait for a lock before raising "database is locked".
BUSY_TIMEOUT_MS = int(os.environ.get("SQLITE_BUSY_TIMEOUT_MS", "10000"))

_local = threading.local()
_write_lock = threading.RLock()
_initialised: set[str] = set()
_init_lock = threading.Lock()


def _configure(conn: sqlite3.Connection, path: str) -> None:
    """Apply the pragmas. WAL + NORMAL sync is the right profile for a bot."""
    conn.row_factory = sqlite3.Row
    conn.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}")
    conn.execute("PRAGMA foreign_keys = ON")
    if path not in _initialised:
        with _init_lock:
            if path not in _initialised:
                try:
                    conn.execute("PRAGMA journal_mode = WAL")
                except sqlite3.DatabaseError:
                    pass  # e.g. a network filesystem; fall back to the default
                _initialised.add(path)
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA cache_size = -16000")   # ~16 MB page cache per conn
    conn.execute("PRAGMA temp_store = MEMORY")


def get(path: str) -> sqlite3.Connection:
    """Return this thread's cached connection to `path`, creating it once."""
    cache = getattr(_local, "conns", None)
    if cache is None:
        cache = _local.conns = {}
    conn = cache.get(path)
    if conn is not None:
        return conn
    conn = sqlite3.connect(path, timeout=BUSY_TIMEOUT_MS / 1000.0,
                           check_same_thread=False, isolation_level=None)
    _configure(conn, path)
    cache[path] = conn
    return conn


@contextmanager
def read(path: str):
    """A read-only cursor. No global lock — WAL lets readers run in parallel."""
    yield get(path)


@contextmanager
def write(path: str):
    """
    A write transaction. Serialised in-process (SQLite has a single writer)
    and committed/rolled back atomically.
    """
    conn = get(path)
    with _write_lock:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except Exception:
            try:
                conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
        else:
            conn.execute("COMMIT")


def close_thread() -> None:
    """Close this thread's connections (used by short-lived worker threads)."""
    cache = getattr(_local, "conns", None)
    if not cache:
        return
    for conn in cache.values():
        try:
            conn.close()
        except Exception:
            pass
    cache.clear()
