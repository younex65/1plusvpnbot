# 1PlusVPN — Emergency Charge Backend & Bot

سیستم کامل مدیریت اشتراک، فروشگاه، ربات تلگرام و پرداخت آنلاین برای پنل Rebecca.

## 📋 امکانات

### 🤖 ربات تلگرام (مدیریت ادمین)
- مدیریت کاربران (جستجو، ساخت، ویرایش، حذف)
- مدیریت پکیج‌ها و قیمت‌گذاری
- مدیریت کارت‌های بانکی (چندین کارت با انتخاب تصادفی)
- مدیریت کدهای تخفیف و هدیه
- تنظیمات فروشگاه (حداقل/حداکثر حجم، پیشوند نام)
- بکاپ و بازیابی خودکار و دستی
- تنظیمات روش‌های پرداخت (کارت به کارت، درگاه ریالی، درگاه ارزی)
- عضویت اجباری در کانال

### 👥 ربات تلگرام (کاربر)
- ثبت‌نام با لینک اشتراک
- مشاهده آمار اکانت
- دریافت کانفیگ‌ها
- تمدید اشتراک
- خرید اکانت جدید
- استفاده از کد تخفیف و هدیه
- سیستم دعوت دوستان
- دریافت اکانت تست رایگان

### 🌐 فروشگاه آنلاین (shop.html)
- ثبت‌نام و ورود کاربران
- مشاهده پکیج‌ها و قیمت‌ها
- خرید اشتراک جدید
- تمدید اشتراک
- استفاده از کد تخفیف
- نمایش کارت بانکی تصادفی
- آپلود رسید پرداخت

### 📄 صفحه تمدید (renew_page.html)
- تمدید اشتراک با لینک ساب
- نمایش پکیج‌ها و قیمت‌ها
- استفاده از کد تخفیف
- نمایش کارت بانکی تصادفی

### 🔧 پنل مدیریت وب (8088)
- وضعیت سرویس‌ها
- تنظیمات پایه (URL ها، کلید API، بات تلگرام)
- مدیریت ادمین‌ها (کلید API، بات، کارت، قیمت)
- مدیریت فروشگاه (پکیج‌ها، کارت‌ها، حداقل/حداکثر حجم)
- **مدیریت Nginx و دامنه فروشگاه**
- تنظیمات HTTPS
- نصب و راه‌اندازی
- بکاپ و بازیابی
- مشاهده لاگ‌ها

## 🚀 نصب

### روش ۱: نصب اتوماتیک (توصیه شده)

```bash
# روی سرور اجرا کنید
sudo bash install.sh
```

این اسکریپت:
1. وابستگی‌های سیستم را نصب می‌کند
2. فایل‌ها را در `/opt/emergency-backend` کپی می‌کند
3. محیط مجازی Python را ایجاد می‌کند
4. از شما سوالاتی می‌پرسد (URL پنل، کلید API، دامنه فروشگاه و...)
5. فایل `.env` را می‌سازد
6. سرویس backend را نصب و راه‌اندازی می‌کند
7. nginx را نصب و کانفیگ می‌کند (اگر دامنه فروشگاه داده باشید)
8. پنل وب را نصب و راه‌اندازی می‌کند

پس از نصب:
```
✅ Backend API  : https://IP:9443
✅ Web Panel    : http://IP:8088
✅ Shop Domain : https://shop.yourdomain.com (اگر تنظیم شده باشد)
```

### روش ۲: نصب دستی

```bash
# کپی فایل‌ها
sudo cp -r . /opt/emergency-backend
cd /opt/emergency-backend

# ساخت محیط مجازی
sudo python3 -m venv venv
sudo ./venv/bin/pip install -r requirements.txt

# کپی فایل نمونه .env و ویرایش
sudo cp config.example.env .env
sudo nano .env

# نصب سرویس
sudo cp emergency-backend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now emergency-backend

# نصب پنل
sudo cp 1plusvpn-panel.service /etc/systemd/system/
sudo systemctl enable --now 1plusvpn-panel
```

## 📖 راهنمای استفاده

### ۱. راه‌اندازی اولیه

1. اسکریپت `install.sh` را اجرا کنید
2. به پنل وب بروید: `http://IP:8088`
3. با نام کاربری و رمز عبوری که موقع نصب دادید وارد شوید
4. در تب "ادمین‌ها"، ادمین‌ها را اضافه کنید:
   - نام ادمین (username)
   - کلید API (از پنل Rebecca)
   - توکن بات تلگرام (اختیاری)
   - آیدی تلگرام (برای دریافت اعلان‌ها)
   - شماره کارت بانکی
5. در تب "فروشگاه"، پکیج‌ها و کارت‌ها را تنظیم کنید

### ۲. تنظیم دامنه فروشگاه

1. در پنل وب، به تب "Nginx & دامنه" بروید
2. در بخش "تنظیم دامنه فروشگاه"، دامنه خود را وارد کنید (مثلاً `shop.yourdomain.com`)
3. دکمه "⚙️ تنظیم" را بزنید
4. DNS دامنه را به IP سرور اشاره دهید
5. Certbot را نصب کنید (اگر نصب نیست)
6. SSL را فعال کنید:
   ```bash
   sudo certbot --nginx -d shop.yourdomain.com
   ```

### ۳. تنظیم صفحه سابسکریپشن (Frontend)

در فایل `index.html` سابسکریپشن:

```javascript
EMERGENCY_API_BASE: 'https://shop.yourdomain.com',
// یا اگر دامنه ندارید:
EMERGENCY_API_BASE: 'https://IP:9443',
```

### ۴. استفاده از ربات تلگرام

#### برای ادمین:
1. بات را با توکنی که در تنظیمات ادمین دادید استارت کنید
2. دستور `/start` را بزنید
3. از منوها استفاده کنید

#### برای کاربر:
1. لینک سابسکریپشن خود را به بات بفرستید
2. از منوها استفاده کنید

## 🔧 دستورات مفید

```bash
# وضعیت سرویس‌ها
sudo systemctl status emergency-backend
sudo systemctl status 1plusvpn-panel
sudo systemctl status nginx

# لاگ‌ها
sudo journalctl -u emergency-backend -f
sudo journalctl -u 1plusvpn-panel -f

# ری‌استارت
sudo systemctl restart emergency-backend
sudo systemctl restart 1plusvpn-panel
sudo systemctl restart nginx

# ویرایش تنظیمات
sudo nano /opt/emergency-backend/.env

# ویرایش تنظیمات ادمین‌ها
sudo nano /opt/emergency-backend/admins.json

# فعال‌سازی SSL
sudo certbot --nginx -d yourdomain.com

# بکاپ دستی
cd /opt/emergency-backend
sudo ./venv/bin/python backup.py
```

## 📁 ساختار فایل‌ها

```
/opt/emergency-backend/
├── app.py                    # Backend اصلی (FastAPI)
├── panel.py                  # پنل مدیریت وب (8088)
├── bot.py                    # ربات تلگرام (ادمین)
├── bot_user.py               # ربات تلگرام (کاربر)
├── bot_settings.py           # تنظیمات ربات
├── shop.py                   # فروشگاه آنلاین
├── shop.html                 # صفحه فروشگاه
├── renew_page.html           # صفحه تمدید
├── panel.html                # پنل مدیریت
├── user_registry.py          # ثبت‌نام کاربران
├── referrals.py              # سیستم دعوت
├── backup.py                 # بکاپ و بازیابی
├── notifier.py               # اعلان‌ها
├── panel_api.py              # API پنل Rebecca
├── .env                      # تنظیمات (محرمانه)
├── admins.json               # تنظیمات ادمین‌ها
├── emergency.db              # دیتابیس SQLite
├── requirements.txt          # وابستگی‌های Python
├── emergency-backend.service # سرویس backend
├── 1plusvpn-panel.service    # سرویس پنل
└── install.sh                # اسکریپت نصب
```

## 🔒 امنیت

- تمام API ها از طریق HTTPS در دسترس هستند
- کلید API پنل Rebecca فقط در سمت سرور ذخیره می‌شود
- رمز عبور پنل وب با PBKDF2 هش می‌شود
- CORS فقط برای دامنه‌های مجاز فعال است
- فایل‌های `.env` و `admins.json` با مجوز 600 ذخیره می‌شوند
- بکاپ‌ها شامل metadata برای اعتبارسنجی هستند

## 🐛 عیب‌یابی

### ربات کار نمی‌کند
```bash
# بررسی لاگ
sudo journalctl -u emergency-backend -n 50

# بررسی تنظیمات
sudo nano /opt/emergency-backend/.env

# ری‌استارت
sudo systemctl restart emergency-backend
```

### فروشگاه باز نمی‌شود
```bash
# بررسی nginx
sudo nginx -t
sudo systemctl status nginx

# بررسی DNS
dig shop.yourdomain.com

# بررسی SSL
sudo certbot certificates
```

### صفحه تمدید کار نمی‌کند
- بررسی کنید `EMERGENCY_API_BASE` در `index.html` درست تنظیم شده باشد
- بررسی کنید CORS در `.env` دامنه صحیح را دارد
- لاگ backend را بررسی کنید

## 📝 یادداشت‌ها

- حداقل نسخه Python: 3.8
- دیتابیس: SQLite (به صورت پیش‌فرض در `emergency.db`)
- بکاپ خودکار: هر 12 ساعت (قابل تنظیم)
- پورت backend: 9443 (HTTPS)
- پورت پنل: 8088 (HTTP)

## 📄 لایسنس

این پروژه برای استفاده داخلی 1PlusVPN توسعه داده شده است.

---

**نسخه:** 1.0.0  
**آخرین بروزرسانی:** 2026-07-31  
**توسعه‌دهنده:** 1PlusVPN Team
