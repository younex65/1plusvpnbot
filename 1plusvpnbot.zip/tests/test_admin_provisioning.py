"""Offline regressions for admin credentials and provisioning.

Run: python tests/test_admin_provisioning.py
"""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from contextlib import ExitStack
from unittest.mock import patch

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app
import bot
import bot_settings
import panel_api


class AdminProvisioningTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.tmp = self.stack.enter_context(tempfile.TemporaryDirectory())
        bot_settings.init(str(Path(self.tmp) / "settings.db"))
        bot_settings.set_setting("first", "shop_prefix", "YN")
        bot_settings.set_setting("second", "shop_prefix", "AB")
        self.admins = {
            "first": {"api_key": "first-key", "bot_token": "first-bot", "admin_ids": ["42"]},
            "second": {"api_key": "second-key", "bot_token": "second-bot", "admin_ids": ["42"]},
            "no-key": {"bot_token": "no-key-bot", "admin_ids": ["42"]},
        }
        self.users = {
            "first-key": {n: {} for n in ("YN9", "yn331", "YN999X", "AB999")},
            "second-key": {"AB77": {}, "YN1000": {}},
        }
        self.users["first-key"]["yn331"] = {
            "status": "active", "subscription_url": "/sub/secret1?a=1&b=2",
            "links": ["vless://secret@fake.invalid?x=y&z=w#<test>", "trojan://secret@fake.invalid"],
        }
        self.requests = []
        self.posts = []
        self.collide = set()
        self.services = [{"id": 7, "name": "test service"}]
        self.fail_get_list = False
        self.v2_failure = None

        # Attach a per-instance auth header, as the real pool would do per API key.
        self.clients = {}
        for key in self.users:
            self.clients[key] = self.stack.enter_context(httpx.Client(
                transport=httpx.MockTransport(self.panel), headers={"Authorization": f"Bearer {key}"}))
        self.stack.enter_context(patch.object(panel_api, "_get_client", side_effect=self.clients.__getitem__))
        self.stack.enter_context(patch.object(app, "_load_admins_config", return_value=self.admins))
        self.stack.enter_context(patch.object(app, "ADMIN_API_KEY", "sudo-key"))
        self.stack.enter_context(patch.object(bot, "CONV", bot.Conv()))
        self.stack.enter_context(patch.object(bot, "_resolve_admin_cfg", app._telegram_admin_cfg))
        self.stack.enter_context(patch.object(bot, "_admin_username_for_token", app._admin_username_for_token))
        self.stack.enter_context(patch.object(bot, "_subscription_base_url", "https://subscriptions.invalid"))
        self.stack.enter_context(patch.object(bot, "now_epoch", return_value=1_800_000_000))
        self.tg = self.stack.enter_context(patch.object(bot, "tg", return_value={"ok": True}))
        self.document = self.stack.enter_context(patch.object(bot, "_send_document", return_value=True))

    def panel(self, request):
        key = request.headers["authorization"].removeprefix("Bearer ")
        method, path = request.method, request.url.path
        self.requests.append((key, method, path))
        users = self.users[key]
        if path == "/api/users" and method == "GET":
            if self.fail_get_list:
                return httpx.Response(503, json={"detail": "temporary failure"})
            return httpx.Response(200, json={"users": [{"username": n} for n in users]})
        if path == "/api/v2/services" and method == "GET":
            return httpx.Response(200, json=self.services)
        if path in ("/api/v2/users", "/api/user") and method == "POST":
            payload = json.loads(request.content)
            self.posts.append((key, path, payload))
            if self.v2_failure and path == "/api/v2/users":
                return httpx.Response(self.v2_failure, json={"detail": "v2 returned an error"})
            if payload["status"] == "on_hold" and (payload.get("expire", 0) or
                                                    payload.get("on_hold_expire_duration", 0) <= 0):
                return httpx.Response(400, json={"detail": "invalid on_hold payload"})
            uname = payload["username"]
            if uname in users or uname in self.collide:
                return httpx.Response(409, json={"detail": "User username already exists"})
            users[uname] = {**payload, "subscription_url": f"/sub/{uname}-new"}
            return httpx.Response(201, json={"username": uname})
        if path.startswith("/api/user/") and method == "GET":
            uname = path.rsplit("/", 1)[-1]
            if uname in users:
                return httpx.Response(200, json={"username": uname, **users[uname]})
            return httpx.Response(403, json={"detail": "not your user"})
        self.fail(f"Unexpected panel request: {method} {path}")

    def cb(self, data, token="first-bot", chat=42, sender=42):
        bot.handle_callback({"callback_query": {"id": "cb", "data": data, "from": {"id": sender},
                                                "message": {"chat": {"id": chat}, "message_id": 8}}}, token)

    def msg(self, text, token="first-bot", chat=42, sender=42):
        bot.handle_message({"message": {"chat": {"id": chat}, "from": {"id": sender}, "text": text}}, token)

    def sent(self):
        return [c.kwargs["text"] for c in self.tg.call_args_list if c.args[0] == "sendMessage"]

    def test_open_card_and_fetch_credentials_with_same_key(self):
        self.cb("m:users")
        self.msg("yn331")
        self.cb("open:yn331")
        edit = next(c for c in reversed(self.tg.call_args_list) if c.args[0] == "editMessageText")
        actions = edit.kwargs["reply_markup"]
        for action in ("sub", "cfgs", "revoke"):
            self.assertIn(f"u:{action}:yn331", actions)
        self.cb("u:sub:yn331")
        self.cb("u:cfgs:yn331")
        self.assertIn("https://subscriptions.invalid/sub/secret1?a=1&amp;b=2", self.sent()[-2])
        self.assertIn("z=w#&lt;test&gt;", self.sent()[-1])
        self.assertIn("trojan://", self.sent()[-1])
        self.assertTrue(all(key == "first-key" and method == "GET" for key, method, _ in self.requests))

    def test_credentials_are_private_and_do_not_cross_admins(self):
        self.cb("u:sub:yn331", sender=7)
        self.cb("u:cfgs:yn331", chat=-100)
        self.cb("u:sub:yn331", token="no-key-bot")
        self.assertEqual(self.requests, [])
        self.cb("u:sub:yn331", token="second-bot")
        self.assertEqual(self.requests, [("second-key", "GET", "/api/user/yn331")])
        self.assertEqual(self.sent(), [])

    def test_long_configs_use_document(self):
        links = ["vless://" + "x" * 4100, "trojan://fake.invalid"]
        self.users["first-key"]["yn331"]["links"] = links
        self.cb("u:cfgs:yn331")
        self.assertEqual(self.document.call_args.args[3].decode().splitlines(), links)

    def test_manual_on_hold_rejects_zero_and_creates_after_positive_days(self):
        self.msg("/create")
        self.cb("create:onhold")
        self.msg("my_custom_name")
        self.msg("1.5")
        for invalid in ("0", "-1", "1.5", "inf"):
            self.msg(invalid)
            self.assertIn("صحیح مثبت", self.sent()[-1])
        self.assertFalse(self.posts)
        self.msg("۳۰")
        self.cb("csvc:7")
        key, path, payload = self.posts[0]
        self.assertEqual((key, path), ("first-key", "/api/v2/users"))
        self.assertEqual(payload, {"username": "my_custom_name", "status": "on_hold", "expire": 0,
                                   "on_hold_expire_duration": 2592000, "data_limit": 1610612736,
                                   "service_id": 7, "service_ids": [7]})
        self.assertIn("30 روز پس از فعال‌سازی", self.sent()[-1])
        self.assertIn("/sub/my_custom_name-new", self.sent()[-1])
        self.cb("open:my_custom_name")
        self.assertIn("30 روز پس از فعال‌سازی", self.tg.call_args.kwargs["text"])

    def test_auto_naming_uses_latest_state_and_separate_prefixes_for_same_chat(self):
        self.cb("create:onhold", "first-bot")
        self.cb("create:auto:onhold", "first-bot")
        self.cb("create:normal", "second-bot")
        self.cb("create:auto:normal", "second-bot")
        self.msg("5", "second-bot")
        self.msg("0", "first-bot")
        self.msg("0", "second-bot")
        self.msg("30", "first-bot")
        self.users["first-key"]["YN332"] = {}  # created elsewhere before submission
        self.collide.add("YN333")  # a simultaneous create won this name after the scan
        self.cb("csvc:7", "first-bot")
        self.cb("csvc:7", "second-bot")
        self.assertEqual([(k, p["username"]) for k, _, p in self.posts],
                         [("first-key", "YN333"), ("first-key", "YN334"), ("second-key", "AB78")])
        self.assertEqual(self.posts[1][2]["status"], "on_hold")
        active = self.posts[2][2]
        self.assertEqual((active["status"], active["expire"], active["data_limit"]),
                         ("active", 0, 5 * 1024**3))
        self.assertNotIn("on_hold_expire_duration", active)

    def test_failed_scan_never_provisions_prefix_one(self):
        self.fail_get_list = True
        self.services = []
        self.cb("create:normal")
        self.cb("create:auto:normal")
        self.msg("10")
        self.msg("2")
        self.assertFalse(self.posts)
        self.assertIn("خطا در ساخت", self.sent()[-1])

    def test_legacy_fallback_preserves_hold_duration(self):
        self.v2_failure = 405
        self.cb("create:onhold")
        self.msg("hold_legacy")
        self.msg("0")
        self.msg("1")
        self.cb("csvc:7")
        self.assertEqual([path for _, path, _ in self.posts], ["/api/v2/users", "/api/user"])
        self.assertEqual(self.posts[0][2], self.posts[1][2])
        self.assertEqual(self.posts[1][2]["on_hold_expire_duration"], 86400)

    def test_validation_conflict_and_timeout_do_not_fallback_on_manual_create(self):
        for status in (400, 409, 502):
            with self.subTest(status=status):
                self.posts.clear()
                self.v2_failure = status
                self.cb("create:normal")
                self.msg("named_user")
                self.msg("3")
                self.msg("7")
                self.cb("csvc:7")
                self.assertEqual(len(self.posts), 1)
                self.assertEqual(self.posts[0][2]["expire"], 1_800_000_000 + 7 * 86400)

    def test_no_service_uses_legacy_and_auto_starts_at_one(self):
        self.services = []
        self.users["first-key"].clear()
        self.cb("create:normal")
        self.cb("create:auto:normal")
        self.msg("1")
        self.msg("7")
        self.assertEqual(self.posts[0][1], "/api/user")
        self.assertEqual(self.posts[0][2]["username"], "YN1")
        self.assertNotIn("service_id", self.posts[0][2])


if __name__ == "__main__":
    unittest.main(verbosity=2)
