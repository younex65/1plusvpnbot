import os, sys
"""Focused test: the "🔧 تنظیمات سیستم" (m:sys_settings) button and its sys:* flow."""
import json, os, sys, tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
d = tempfile.mkdtemp()

import bot_settings as settings
settings.init(os.path.join(d, "sys.db"))

import bot
calls = []

# capture every telegram call instead of hitting the network
bot.tg = lambda method, token, **kw: calls.append((method, kw)) or {"ok": True, "result": {"message_id": 100}}

bot.configure(
    resolve_admin_cfg=lambda a: {"admin_ids": ["555", "666"], "api_key": "fake-key"},
    admin_username_for_token=lambda t: "1plus",
    sales_stats=lambda a: {"orders": 0, "toman": 0},
    list_orders=lambda a, n: [],
    is_sudo=lambda t, i: str(i) == "555",
)

TOKEN = "TESTTOKEN"
ADMIN = "1plus"

def cb(data, from_id="555", message_id=9):
    update = {"callback_query": {"id": f"cb{from_id}{data}", "from": {"id": from_id},
                                 "data": data,
                                 "message": {"message_id": message_id, "chat": {"id": int(from_id)}}}}
    bot.handle_callback(update, TOKEN)

def msg(text, from_id="555"):
    update = {"message": {"message_id": 1, "chat": {"id": int(from_id)}, "from": {"id": from_id}, "text": text}}
    bot.handle_message(update, TOKEN)

def texts(chat_id):
    return [(m, k.get("text", "")) for m, k in calls if k.get("chat_id") == chat_id]

fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  ({extra})" if extra and not cond else ""))
    if not cond:
        fails.append(name)

# 1) sudo admin presses the button -> menu shows up
cb("m:sys_settings")
t = texts(555)
check("sudo: m:sys_settings shows the system settings menu",
      any(m == "editMessageText" and "تنظیمات سیستم" in txt for m, txt in t), str(t))
menu_kb = [k.get("reply_markup") for m, k in calls if k.get("chat_id") == 555 and k.get("reply_markup")]
check("menu has sys:* buttons",
      any("sys:shop_domain" in (r or "") and "sys:admin_bot_theme" in (r or "") and "sys:min_gb" in (r or "") for r in menu_kb),
      str(menu_kb))

# 2) non-sudo admin presses it -> rejected
calls.clear()
cb("m:sys_settings", from_id="666")
a = [k for m, k in calls if m == "answerCallbackQuery"]
check("non-sudo: rejected with alert",
      any(k.get("show_alert") and "سودو" in (k.get("text") or "") for k in a), str(a))
check("non-sudo: no menu shown",
      not any(m == "editMessageText" and "تنظیمات سیستم" in k.get("text", "") for m, k in calls if k.get("chat_id") == 666))

# 3) edit admin theme: dark
calls.clear()
cb("sys:admin_bot_theme")
check("prompt for theme sent", any("gradient" in txt for _, txt in texts(555)))
msg("dark")
check("theme saved", settings.get_setting(ADMIN, "admin_bot_theme") == "dark",
      str(settings.get_setting(ADMIN, "admin_bot_theme")))
check("confirmation sent", any("dark" in txt for _, txt in texts(555)))

# 4) invalid theme rejected
calls.clear()
cb("sys:user_bot_theme")
msg("pink")
check("invalid theme rejected", settings.get_setting(ADMIN, "user_bot_theme") is None
      and any("نامعتبر" in txt for _, txt in texts(555)))

# 5) min/max GB (stored as str, effective config coerces to int — what the shop reads)
calls.clear()
cb("sys:min_gb"); msg("10")
check("minGB saved", settings.get_effective_config(ADMIN, {}).get("minGB") == 10)
cb("sys:max_gb"); msg("1000")
check("maxGB saved", settings.get_effective_config(ADMIN, {}).get("maxGB") == 1000)

# 6) shop domain: bare host gets https://, slash stripped
calls.clear()
cb("sys:shop_domain"); msg("1plusnet.ir")
check("domain normalized to https", settings.get_setting(ADMIN, "shop_domain") == "https://1plusnet.ir",
      str(settings.get_setting(ADMIN, "shop_domain")))
# 7) shop domain: 0 clears it
calls.clear()
cb("sys:shop_domain"); msg("0")
check("domain cleared with 0", settings.get_setting(ADMIN, "shop_domain") == "")

# 8) the button in the main menu still renders for sudo only
main = bot.main_menu(is_sudo=True, shop_enabled=False)
wsudo = json.dumps(main, ensure_ascii=False)
wplain = json.dumps(bot.main_menu(is_sudo=False, shop_enabled=False), ensure_ascii=False)
check("button only for sudo in main menu", "m:sys_settings" in wsudo and "m:sys_settings" not in wplain)

# 9) end-to-end: sudo sees values rendered in the menu
calls.clear()
cb("m:sys_settings")
check("menu renders saved values",
      any(m == "editMessageText" and "dark" in txt and "https://1plusnet.ir" not in txt for m, txt in texts(555))
      or any(m == "editMessageText" and "dark" in txt for m, txt in texts(555)),
      str(texts(555)))

print()
if fails:
    print("FAILED:", fails)
    sys.exit(1)
print("All sys_settings checks passed.")
