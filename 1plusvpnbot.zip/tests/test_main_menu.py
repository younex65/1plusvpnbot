import os, sys
"""Focused test: "منوی اصلی" button must work from EVERY section.

Covers:
  A) customer reply-keyboard "🏠 منوی اصلی" mid uu_* conversation (was swallowed
     as user input: referral username / redeem code / GB value)
  B) admin inline m:home (edit silently fails: deleted message / not modified /
     no message context)
  C) customer inline uu:home (same failure class)
  D) admin reply-keyboard mid conversation (regression guard)
"""
import os, sys, tempfile, json
from urllib.parse import urlsplit

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
d = tempfile.mkdtemp()

import bot_settings, user_registry, referrals, shop
for m in (bot_settings, user_registry, referrals, shop):
    m.init(os.path.join(d, "t.db"))

import bot

EDIT_RESULT = {"ok": True, "result": {"message_id": 1}}
DENY_WEBAPP = False
ADMIN_CFG = {"admin_ids": ["555"], "api_key": "fake-key", "shop_enabled": True}
calls = []

def fake_tg(method, token, **kw):
    calls.append((method, kw))
    if method in ("sendMessage", "editMessageText"):
        if kw.get("chat_id") is None:
            return {"ok": False, "description": "Bad Request: chat_id is empty"}
        for row in json.loads(kw.get("reply_markup") or "{}").get("inline_keyboard", []):
            for button in row:
                if "web_app" in button:
                    url = urlsplit(button["web_app"]["url"])
                    if DENY_WEBAPP or url.scheme != "https" or not url.hostname or kw["chat_id"] < 0:
                        return {"ok": False, "description": "Bad Request: BUTTON_TYPE_INVALID"}
    if method in ("editMessageText", "editMessageCaption"):
        return dict(EDIT_RESULT)
    return {"ok": True, "result": {"message_id": len(calls)}}

bot.tg = fake_tg

bot.configure(
    resolve_admin_cfg=lambda a: dict(ADMIN_CFG),
    admin_username_for_token=lambda t: "1plus",
    sales_stats=lambda a: {"orders": 0, "toman": 0},
    list_orders=lambda a, n: [],
    is_sudo=lambda t, i: str(i) == "555",
)

import bot_user
bot_user.configure(
    resolve_username=lambda sub: "cust1",
    account_from_sub=lambda sub: {"username": "cust1", "admin_username": "1plus"},
    effective_cfg=lambda a: {"prices": {30: 8000, 60: 8800, 90: 9600}, "plans": [30, 60, 90],
                             "minGB": 10, "maxGB": 1000, "card_number": "6219861903371283",
                             "card_holder": "x", "card_bank": "b",
                             "referral_enabled": True, "referral_percent": 10,
                             "referral_text": "ref text", "pay_card_enabled": True,
                             "shop_enabled": True, "renewal_enabled": True},
    admin_username_for=lambda sub: "1plus",
    fetch_configs=lambda name: [],
    create_order=lambda *a, **k: {"order_id": "ST1"},
    notify_admin_receipt=lambda *a, **k: None,
)

fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  ({extra})" if extra and not cond else ""))
    if not cond:
        fails.append(name)

def reset():
    calls.clear()

def cust_msg(text, chat_id=777):
    u = {"message": {"message_id": 1, "chat": {"id": chat_id}, "from": {"id": chat_id}, "text": text}}
    bot_user.handle_message(u, "TOKEN")

def sent_texts(chat_id=777):
    return [k.get("text", "") for m, k in calls if k.get("chat_id") == chat_id]

def menu_shown(chat_id=777):
    return any("یکی از گزینه‌ها را انتخاب کنید" in t for t in sent_texts(chat_id))

user_registry.register(777, "cust1", "1plus", "https://panel/sub/cust1")
user_registry.register(555, "admin1", "1plus", "https://panel/sub/admin1")

# ===========================================================================
# A) customer keyboard button mid-conversation
# ===========================================================================
for state in ("uu_gb", "uu_ref", "uu_redeem", "uu_gift", "uu_buy_gb", "uu_waiting_link"):
    bot_user._conv().set(777, state, {"username": "cust1", "admin": "1plus",
                                       "days": 30, "ppg": 8000, "min_gb": 10})
    reset()
    cust_msg("🏠 منوی اصلی")
    check(f"A) keyboard home works from {state}",
          menu_shown() and bot_user._conv().get(777) is None,
          str(sent_texts()))

# the corruption cases: referral label must NOT be stored, redeem must NOT be tried
check("A) no garbage referral saved",
      referrals.discount_percent_for("cust1") == 0,
      str(referrals.discount_percent_for("cust1")))

# control: pressing it OUTSIDE a conversation still works
reset()
cust_msg("🏠 منوی اصلی")
check("A) keyboard home works outside conversation", menu_shown())

# ===========================================================================
# B) admin inline m:home
# ===========================================================================
def admin_cb(data, message_id=9, chat_id=555, from_id="555"):
    u = {"callback_query": {"id": "cb", "from": {"id": from_id}, "data": data,
                            "message": {"message_id": message_id, "chat": {"id": chat_id}}}}
    bot.handle_callback(u, "TOKEN")

# B1 normal edit
reset()
EDIT_RESULT = {"ok": True, "result": {"message_id": 1}}
admin_cb("m:home")
check("B1) normal: edit used, no duplicate send",
      any(m == "editMessageText" for m, _ in calls) and not any(m == "sendMessage" for m, _ in calls),
      str([m for m, _ in calls]))

# B2 message already shows the menu -> "not modified" -> GUARANTEED visible
# response: a fresh main-menu message is sent (the button never goes silent)
reset()
EDIT_RESULT = {"ok": False, "error_code": 400, "description": "Bad Request: message is not modified"}
admin_cb("m:home")
check("B2) 'not modified': guaranteed visible fresh menu",
      any(m == "sendMessage" and "پنل مدیریت" in k.get("text", "") for m, k in calls),
      str([m for m, _ in calls]))

# B3 message deleted -> fall back to a fresh message
reset()
EDIT_RESULT = {"ok": False, "error_code": 400, "description": "Bad Request: message to edit not found"}
admin_cb("m:home")
check("B3) deleted message: fresh main menu sent",
      any(m == "sendMessage" and "پنل مدیریت" in k.get("text", "") for m, k in calls),
      str([m for m, _ in calls]))

# B4 no message context at all -> fresh message
reset()
EDIT_RESULT = {"ok": True, "result": {"message_id": 1}}
u = {"callback_query": {"id": "cb", "from": {"id": 555}, "data": "m:home"}}
bot.handle_callback(u, "TOKEN")
check("B4) no message context: fresh main menu sent",
      any(m == "sendMessage" and k.get("chat_id") == 555 and "پنل مدیریت" in k.get("text", "")
          for m, k in calls), str(calls))

# ===========================================================================
# C) customer inline uu:home
# ===========================================================================
def cust_cb(data, mid=5, chat_id=777):
    u = {"callback_query": {"id": "cb", "from": {"id": chat_id}, "data": data,
                            "message": {"message_id": mid, "chat": {"id": chat_id}}}}
    bot_user.handle_callback(u, "TOKEN")

# C1 normal
reset()
EDIT_RESULT = {"ok": True, "result": {"message_id": 1}}
cust_cb("uu:home")
check("C1) normal: edit used, no duplicate send",
      any(m == "editMessageText" for m, _ in calls) and not any(m == "sendMessage" for m, _ in calls),
      str([m for m, _ in calls]))

# C2 not modified -> guaranteed visible fresh menu
reset()
EDIT_RESULT = {"ok": False, "error_code": 400, "description": "Bad Request: message is not modified"}
cust_cb("uu:home")
check("C2) 'not modified': guaranteed visible fresh menu",
      any(m == "sendMessage" and "یکی از گزینه‌ها را انتخاب کنید" in k.get("text", "") for m, k in calls),
      str([m for m, _ in calls]))

# C3 deleted -> fresh message
reset()
EDIT_RESULT = {"ok": False, "error_code": 400, "description": "Bad Request: message to edit not found"}
cust_cb("uu:home")
check("C3) deleted message: fresh user menu sent",
      any(m == "sendMessage" and "یکی از گزینه‌ها را انتخاب کنید" in k.get("text", "") for m, k in calls),
      str([m for m, _ in calls]))

# C4 no message context -> fresh message
reset()
EDIT_RESULT = {"ok": True, "result": {"message_id": 1}}
u = {"callback_query": {"id": "cb", "from": {"id": 777}, "data": "uu:home"}}
bot_user.handle_callback(u, "TOKEN")
check("C4) no message context: fresh user menu sent",
      any(m == "sendMessage" and k.get("chat_id") == 777 and "uu:stats" in k.get("reply_markup", "")
          for m, k in calls), str(calls))

# ===========================================================================
# D) admin reply-keyboard mid-conversation (regression guard)
# ===========================================================================
reset()
with bot.CONV.admin_scope("TOKEN", "1plus", 555):
    bot.CONV.set(555, "set_card_number", {})
u = {"message": {"message_id": 1, "chat": {"id": 555}, "from": {"id": 555}, "text": "🏠 منوی اصلی"}}
bot.handle_message(u, "TOKEN")
with bot.CONV.admin_scope("TOKEN", "1plus", 555):
    cleared = bot.CONV.get(555) is None
check("D) admin keyboard home works mid set_* conversation",
      any(m == "sendMessage" and "پنل مدیریت" in k.get("text", "") for m, k in calls)
      and cleared, str([m for m, _ in calls]))


# E) Telegram validates the reply markup on both edit and send.
with bot.CONV.admin_scope("TOKEN", "1plus", 555):
    bot.CONV.set(555, "create_days", {})
for domain in (None, "", "http://shop.test", "/relative", "https://shop.test:broken"):
    reset()
    ADMIN_CFG["shop_domain"] = domain
    admin_cb("m:home")
    edits = [k for m, k in calls if m == "editMessageText"]
    check(f"E) unset/invalid Web App domain {domain!r} leaves a working menu",
          len(edits) == 1 and "web_app" not in edits[0]["reply_markup"]
          and all(key in edits[0]["reply_markup"] for key in ("m:users", "m:shop", "m:sys_settings")), str(calls))
with bot.CONV.admin_scope("TOKEN", "1plus", 555):
    check("E) inline home clears admin conversation", bot.CONV.get(555) is None)

ADMIN_CFG["shop_domain"] = "https://shop.test/"
reset()
admin_cb("m:home")
check("E) configured Web App stays in private admin chat",
      any(m == "editMessageText" and "https://shop.test/webapp/1plus/admin?theme=gradient" in k["reply_markup"]
          for m, k in calls), str(calls))
reset()
admin_cb("m:home", chat_id=-100)
check("E) group markup never contains a Web App button",
      any(m == "editMessageText" and "web_app" not in k["reply_markup"] for m, k in calls), str(calls))

reset()
DENY_WEBAPP = True
admin_cb("m:home")
check("E) rejected Web App falls back to a plain edit",
      ["web_app" in k["reply_markup"] for m, k in calls if m == "editMessageText"] == [True, False], str(calls))
reset()
EDIT_RESULT = {"ok": False, "error_code": 400, "description": "Bad Request: message to edit not found"}
admin_cb("m:home")
check("E) rejected Web App plus uneditable message falls back to plain send",
      any(m == "sendMessage" and k.get("chat_id") == 555
          and "m:users" in k["reply_markup"] and "web_app" not in k["reply_markup"] for m, k in calls), str(calls))

print()
if fails:
    print("FAILED:", fails)
    sys.exit(1)
print("All main-menu-button checks passed.")
