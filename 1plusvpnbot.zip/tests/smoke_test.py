"""
smoke_test.py — verifies the fixes actually work (and measures them).

Run:  python smoke_test.py
No network access to Telegram or the panel is required; a local fake Telegram
API is spun up and tg_client is pointed at it.
"""
from __future__ import annotations

import os
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

DB = os.path.join(tempfile.mkdtemp(), "smoke.db")
os.environ["DB_PATH"] = DB

FAILURES = []


def check(name, ok, extra=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}{'  ' + extra if extra else ''}")
    if not ok:
        FAILURES.append(name)


# --------------------------------------------------------------------------
# 1. SQLite layer: WAL, parallel reads, no "database is locked"
# --------------------------------------------------------------------------
def test_db():
    import dbx
    import user_registry
    import bot_settings

    user_registry.init(DB)
    bot_settings.init(DB)

    mode = dbx.get(DB).execute("PRAGMA journal_mode").fetchone()[0]
    check("sqlite is in WAL mode", mode.lower() == "wal", f"(got {mode})")

    busy = dbx.get(DB).execute("PRAGMA busy_timeout").fetchone()[0]
    check("busy_timeout is set", int(busy) >= 5000, f"(got {busy} ms)")

    # Hammer it from many threads: reads + writes at the same time.
    errors = []

    def worker(i):
        try:
            for n in range(40):
                user_registry.register(f"chat{i}-{n}", f"user{i}-{n}", "adm", f"https://x/sub/{i}-{n}")
                user_registry.get_user_by_chat(f"chat{i}-{n}")
                bot_settings.set_setting("adm", f"k{i}", str(n))
                bot_settings.get_setting("adm", f"k{i}")
        except Exception as exc:  # noqa: BLE001
            errors.append(repr(exc))

    t0 = time.time()
    with ThreadPoolExecutor(max_workers=16) as pool:
        list(pool.map(worker, range(16)))
    dt = time.time() - t0
    check("16 threads x 40 mixed read/write ops without errors",
          not errors, f"({dt:.2f}s)" if not errors else str(errors[:2]))

    total = user_registry.get_user_stats("adm")["total"]
    check("all writes landed", total == 640, f"(rows={total})")


# --------------------------------------------------------------------------
# 2. _find_user is an indexed lookup, not a full-table scan
# --------------------------------------------------------------------------
def test_find_user():
    import bot_user
    import user_registry

    bot_user._invalidate_user_cache()

    scanned = {"n": 0}
    real_all = user_registry.all_registered

    def spy():
        scanned["n"] += 1
        return real_all()

    user_registry.all_registered = spy
    try:
        for i in range(200):
            bot_user._find_user(f"chat3-{i % 40}")
        bot_user._find_user("definitely-not-registered")
        bot_user._find_user("definitely-not-registered")
    finally:
        user_registry.all_registered = real_all

    check("_find_user never scans the whole table", scanned["n"] == 0,
          f"(scans={scanned['n']})")

    row = bot_user._find_user("chat3-7")
    check("_find_user returns the right row",
          row is not None and row["username"] == "user3-7")

    t0 = time.time()
    for _ in range(20000):
        bot_user._find_user("chat3-7")
    check("20k cached lookups are fast", time.time() - t0 < 1.0,
          f"({time.time() - t0:.3f}s)")


# --------------------------------------------------------------------------
# 3. tg_client reuses ONE connection instead of handshaking per call
# --------------------------------------------------------------------------
class _FakeTG(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"   # enable keep-alive so pooling is observable
    connections = set()
    calls = 0

    def _respond(self):
        # Drain the request body, otherwise keep-alive framing breaks.
        n = int(self.headers.get("Content-Length") or 0)
        if n:
            self.rfile.read(n)
        _FakeTG.connections.add(id(self.connection))
        _FakeTG.calls += 1
        body = b'{"ok":true,"result":{"message_id":1}}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    do_POST = _respond
    do_GET = _respond

    def log_message(self, *a):
        pass


def test_tg_pooling():
    import tg_client

    server = ThreadingHTTPServer(("127.0.0.1", 0), _FakeTG)
    port = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()

    tg_client.close_all()
    tg_client.TG_API = "http://127.0.0.1:%d/bot{token}/{method}" % port

    for i in range(50):
        tg_client.call("sendMessage", "TOKEN", chat_id=1, text=f"hi {i}")

    check("50 API calls were served", _FakeTG.calls == 50, f"(calls={_FakeTG.calls})")
    check("connection is reused (keep-alive), not one per call",
          len(_FakeTG.connections) <= 2,
          f"(distinct connections={len(_FakeTG.connections)})")

    # None-valued params must be dropped, not sent as JSON null.
    sent = {}
    orig = tg_client._client(  # noqa: SLF001
        "TOKEN").post

    def spy_post(url, **kw):
        sent.update(kw.get("json") or {})
        return orig(url, **kw)

    tg_client._client("TOKEN").post = spy_post  # noqa: SLF001
    tg_client.call("sendMessage", "TOKEN", chat_id=1, text="x", reply_markup=None)
    check("None params are stripped from the payload", "reply_markup" not in sent)
    tg_client._client("TOKEN").post = orig  # noqa: SLF001

    server.shutdown()


# --------------------------------------------------------------------------
# 4. Per-chat ordering in the dispatcher pool
# --------------------------------------------------------------------------
def test_chat_ordering():
    import app

    seen = {"a": [], "b": []}
    done = threading.Event()
    pool = app._ChatSerialPool(max_workers=8)  # noqa: SLF001

    def job(chat, n):
        # Make the first job slow: without serialisation #2 finishes first.
        time.sleep(0.05 if n == 0 else 0.0)
        seen[chat].append(n)
        if len(seen["a"]) == 5 and len(seen["b"]) == 5:
            done.set()

    for n in range(5):
        pool.submit("a", job, "a", n)
        pool.submit("b", job, "b", n)
    done.wait(10)

    check("updates from one chat stay in order",
          seen["a"] == [0, 1, 2, 3, 4] and seen["b"] == [0, 1, 2, 3, 4],
          f"({seen})")


# --------------------------------------------------------------------------
# 5. Admin auth fails CLOSED when no admin_ids are configured
# --------------------------------------------------------------------------
def test_auth_fail_closed():
    import bot

    bot._resolve_admin_cfg = lambda a: {"admin_ids": [], "api_key": "k"}  # noqa: SLF001
    bot._admin_username_for_token = lambda t: "adm"  # noqa: SLF001
    check("no admin_ids configured => nobody is admin",
          bot._ctx("tok", "999")[0] is None)  # noqa: SLF001

    bot._resolve_admin_cfg = lambda a: {"admin_ids": ["123"], "api_key": "k"}  # noqa: SLF001
    check("a stranger is rejected", bot._ctx("tok", "999")[0] is None)  # noqa: SLF001
    check("the configured admin is accepted", bot._ctx("tok", "123")[0] == "adm")  # noqa: SLF001


# --------------------------------------------------------------------------
# 6. setMyCommands is sent once, not on every /start
# --------------------------------------------------------------------------
def test_set_commands_once():
    import bot

    calls = []
    orig = bot.tg
    bot.tg = lambda m, t, **kw: calls.append(m)
    try:
        for _ in range(25):
            bot.set_bot_commands("token-x", is_user=True)
    finally:
        bot.tg = orig
    check("setMyCommands sent once per token", calls.count("setMyCommands") == 1,
          f"(sent {calls.count('setMyCommands')}x)")


# --------------------------------------------------------------------------
# 7. Sub-token -> username resolution is memoised
# --------------------------------------------------------------------------
def test_sub_cache():
    import app

    hits = {"n": 0}

    class FakeResp:
        status_code = 200

        @staticmethod
        def json():
            return {"user": {"username": "bob"}}

    class FakeClient:
        def get(self, url, **kw):
            hits["n"] += 1
            return FakeResp()

    app._sub_client_instance = FakeClient()  # noqa: SLF001
    app._SUB_NAME_CACHE.clear()  # noqa: SLF001
    for _ in range(30):
        name = app._resolve_username("https://p.example/sub/TOKEN123")  # noqa: SLF001
    check("sub link resolves correctly", name == "bob")
    check("sub->username is resolved over HTTP only once", hits["n"] == 1,
          f"(http calls={hits['n']})")


# --------------------------------------------------------------------------
# 8. Partial PUT payloads (no more echoing the whole user object back)
# --------------------------------------------------------------------------
def test_partial_put():
    import bot
    from panel_api import PanelAPI

    captured = {}

    class FakeAPI(PanelAPI):
        def __init__(self):
            self.api_key = "k"

        def get_user(self, username):
            return {"username": username, "data_limit": 10 * 1024 ** 3,
                    "used_traffic": 5 * 1024 ** 3, "expire": 0,
                    "online_at": "2026-01-01", "links": ["x"], "admin": "root"}

        def update_user(self, username, payload):
            captured["payload"] = payload
            return {}

        def reset_usage(self, username):
            captured["reset"] = True
            return {}

    sent = []
    orig = bot.send
    bot.send = lambda *a, **k: sent.append(a) or {"ok": True}
    try:
        bot._apply_user_number("tok", 1, FakeAPI(), "adddata", "bob", 5)  # noqa: SLF001
    finally:
        bot.send = orig

    p = captured.get("payload", {})
    check("PUT sends only the changed field", set(p) == {"data_limit"}, f"(sent {sorted(p)})")
    check("PUT never echoes server-owned fields back",
          not ({"used_traffic", "online_at", "links", "admin"} & set(p)))


def main():
    test_db()
    test_find_user()
    test_tg_pooling()
    test_chat_ordering()
    test_auth_fail_closed()
    test_set_commands_once()
    test_sub_cache()
    test_partial_put()
    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILED: {FAILURES}")
        return 1
    print("All checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
