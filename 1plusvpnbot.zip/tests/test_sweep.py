import os, sys
"""Sweep test: EVERY admin + customer section, pressing back / main-menu buttons.

The fake Telegram emulates REAL Telegram edit semantics:
  * editing a deleted message      -> ok=False "message to edit not found"
  * editing to identical content   -> ok=False "message is not modified"
  * otherwise                      -> ok

A button "dies silently" when after pressing it: the current message content
didn't change AND no new message was sent AND no answer toast was shown.
That is exactly the production symptom: spinner dies, nothing happens.
"""
import os, sys, tempfile, json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
d = tempfile.mkdtemp()

import bot_settings, user_registry, referrals, shop
for m in (bot_settings, user_registry, referrals, shop):
    m.init(os.path.join(d, "t.db"))

settings = bot_settings
settings.set_setting("1plus", "shop_enabled", "1")

import bot

# ---------------------------------------------------------------- fake TG ---
class FakeTG:
    def __init__(self):
        self.msgs = {}          # (chat, mid) -> {"text","kb"}
        self.next_id = 0
        self.toasts = []        # answerCallbackQuery texts
        self.last = {}          # chat -> mid of most recently touched message
        self.edit_fail = 0      # next N editMessageText calls -> None (429 exhausted)

    def call(self, method, token, **kw):
        if method == "editMessageText" and self.edit_fail > 0:
            self.edit_fail -= 1
            return None
        if method == "sendMessage":
            self.next_id += 1
            mid = self.next_id
            self.msgs[(kw["chat_id"], mid)] = {"text": kw.get("text", ""),
                                               "kb": kw.get("reply_markup") or ""}
            self.last[kw["chat_id"]] = mid
            return {"ok": True, "result": {"message_id": mid}}
        if method == "editMessageText":
            key = (kw["chat_id"], kw["message_id"])
            m = self.msgs.get(key)
            if m is None:
                return {"ok": False, "description": "Bad Request: message to edit not found"}
            if m["text"] == kw.get("text", "") and m["kb"] == (kw.get("reply_markup") or ""):
                return {"ok": False, "description": "Bad Request: message is not modified"}
            m["text"] = kw.get("text", "")
            m["kb"] = kw.get("reply_markup") or ""
            self.last[kw["chat_id"]] = kw["message_id"]
            return {"ok": True, "result": {}}
        if method == "answerCallbackQuery":
            if kw.get("text"):
                self.toasts.append(kw["text"])
            return {"ok": True}
        return {"ok": True, "result": {"message_id": 1}}

    def delete(self, chat, mid):
        self.msgs.pop((chat, mid), None)

fake = FakeTG()
bot.tg = lambda method, token, **kw: fake.call(method, token, **kw)

# ------------------------------------------------------------- fake panel ---
FAKE_USER = {"username": "u1", "status": "active", "data_limit": 50 * 1024 ** 3,
             "used_traffic": 5 * 1024 ** 3, "expire": 0, "note": "",
             "admin_username": "1plus"}

class FakePanel:
    def __init__(self, key):
        self.key = key
    def iter_all_users(self, *a, **k):
        return iter([FAKE_USER])
    def count_users(self, *a, **k):
        return 1
    def list_users(self, *a, **k):
        return {"users": []}
    def get_user(self, name):
        return dict(FAKE_USER, username=name)
    def list_services(self):
        return []
    def update_user(self, name, fields):
        return {}
    def reset_usage(self, name):
        return {}

bot.PanelAPI = FakePanel
bot.configure(
    resolve_admin_cfg=lambda a: {"admin_ids": ["555"], "api_key": "fake-key", "shop_enabled": True},
    admin_username_for_token=lambda t: "1plus",
    sales_stats=lambda a: {"today_amount": 0, "today_count": 0, "month_amount": 0,
                           "month_count": 0, "total_amount": 0, "total_count": 0},
    list_orders=lambda a, n: [],
    is_sudo=lambda t, i: str(i) == "555",
)

import bot_user
ACC = {"username": "cust1", "status": "active", "used_traffic": 1 * 1024 ** 3,
       "data_limit": 10 * 1024 ** 3, "expire_epoch": 9999999999,
       "admin_username": "1plus"}
bot_user.configure(
    resolve_username=lambda sub: "cust1",
    account_from_sub=lambda sub: dict(ACC),
    effective_cfg=lambda a: settings.get_effective_config("1plus", {}),
    admin_username_for=lambda sub: "1plus",
    fetch_configs=lambda name: [],
    create_order=lambda *a, **k: {"order_id": "ST1"},
    notify_admin_receipt=lambda *a, **k: None,
)

user_registry.register(777, "cust1", "1plus", "https://panel/sub/cust1")
user_registry.register(555, "admin1", "1plus", "https://panel/sub/admin1")

# ---------------------------------------------------------------- driver ----
fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  ({extra})" if extra and not cond else ""))
    if not cond:
        fails.append(name)

def latest(chat):
    mid = fake.last.get(chat)
    m = fake.msgs.get((chat, mid))
    return dict(m) if m else {"text": "", "kb": ""}

def press_admin(data, chat=555):
    mid = fake.last.get(chat)
    before = latest(chat)
    fake.toasts.clear()
    u = {"callback_query": {"id": "cb", "from": {"id": chat}, "data": data,
                            "message": {"message_id": mid, "chat": {"id": chat}}}}
    bot.handle_callback(u, "T")
    after = latest(chat)
    changed = (fake.last.get(chat) != mid) or (after["text"] != before["text"]) or (after["kb"] != before["kb"])
    died = not changed and not fake.toasts
    return died

def press_cust(data, chat=777):
    mid = fake.last.get(chat)
    before = latest(chat)
    fake.toasts.clear()
    u = {"callback_query": {"id": "cb", "from": {"id": chat}, "data": data,
                            "message": {"message_id": mid, "chat": {"id": chat}}}}
    bot_user.handle_callback(u, "T")
    after = latest(chat)
    changed = (fake.last.get(chat) != mid) or (after["text"] != before["text"]) or (after["kb"] != before["kb"])
    died = not changed and not fake.toasts
    return died

def admin_msg(text, chat=555):
    u = {"message": {"message_id": 1, "chat": {"id": chat}, "from": {"id": chat}, "text": text}}
    bot.handle_message(u, "T")

def cust_msg(text, chat=777):
    u = {"message": {"message_id": 1, "chat": {"id": chat}, "from": {"id": chat}, "text": text}}
    bot_user.handle_message(u, "T")

ADMIN_MENU = "پنل مدیریت"
CUST_MENU = "یکی از گزینه‌ها را انتخاب کنید"

def admin_menu_now(chat=555):
    return "m:users" in latest(chat)["kb"]

def cust_menu_now(chat=777):
    m = latest(chat)
    return "uu:stats" in m["kb"] or "uu:reg_link" in m["kb"]

# ============================================================================
# ADMIN SWEEP: section -> press it, check marker, press HOME, check main menu
# ============================================================================
admin_msg("/start")
check("A0 admin main menu after /start", admin_menu_now(), latest(555))

sections = [
    ("m:users",       "جستجو",        "m:home"),
    ("m:create",      "نوع اکانت",    "m:home"),
    ("m:stats",       "آمار شما",     "m:home"),
    ("m:broadcast",   "همگانی",       "m:home"),
    ("m:bulk",        "دسته‌جمعی",    "m:home"),
    ("m:shop",        "فروشگاه",      "m:home"),
    ("m:discounts",   "تخفیف",        "m:home"),
    ("m:gifts",       "هدیه",         "m:home"),
    ("m:trial",       "تست",          "m:home"),
    ("m:ref_reward",  "پاداش",        "m:home"),
    ("m:pay_methods", "پرداخت",      "m:home"),
    ("m:backup",      "بکاپ",         "m:home"),
    ("m:ref",         "دعوت",         "m:home"),
    ("m:bot_users",   "کاربران بات", "m:home"),
    ("m:settings",    "قیمت هر گیگ",  "m:home"),
    ("m:sys_settings","تنظیمات سیستم","m:home"),
]
for data, marker, home in sections:
    died1 = press_admin(data)
    m = latest(555)
    ok1 = (marker in m["text"]) or (marker in m["kb"])
    died2 = press_admin(home)
    ok2 = admin_menu_now()
    check(f"A) {data}: section opens and home works", ok1 and ok2 and not died1 and not died2,
          f"open={ok1} home={ok2} died1={died1} died2={died2} text={latest(555)['text'][:50]!r}")

# back-with-target button ( « تنظیمات on the settings-save confirmation )
press_admin("m:settings")
press_admin("set:card_number")
admin_msg("6219 8619 0337 1283")
check("A) settings save confirmation shows back button",
      "m:settings" in latest(555)["kb"], latest(555)["kb"][:120])
died = press_admin("m:home")
check("A) home from confirmation works", admin_menu_now() and not died)

# ============================================================================
# HOME BUTTON WHEN ALREADY ON THE MENU ("message is not modified") -> must
# still respond VISIBLY (fresh menu message). Never silent.
# ============================================================================
press_admin("m:home")
mid_now = fake.last[555]
died = press_admin("m:home")
check("AH) admin: home pressed while on the menu -> visible fresh menu",
      admin_menu_now() and fake.last[555] != mid_now and not died,
      f"mid {mid_now}->{fake.last[555]} died={died}")

press_cust("uu:home")
mid_now = fake.last[777]
died = press_cust("uu:home")
check("CH) customer: uu:home pressed while on the menu -> visible fresh menu",
      cust_menu_now() and fake.last[777] != mid_now and not died,
      f"mid {mid_now}->{fake.last[777]} died={died}")

# ============================================================================
# REFRESH BUTTON: second press re-renders identical content -> Telegram
# answers "message is not modified". The button must not appear dead.
# ============================================================================
press_admin("m:stats")
died = press_admin("m:stats_force")   # first refresh (cache cold -> new render)
died2 = press_admin("m:stats_force")  # second refresh (identical render)
check("AR) admin refresh twice: no silent death, stats stay visible",
      "آمار شما" in latest(555)["text"] and not died,
      f"died={died} died2={died2} toasts={fake.toasts} text={latest(555)['text'][:50]!r}")

# ============================================================================
# DELETED-MESSAGE SCENARIO: current message deleted, back/home must still work
# ============================================================================
for data in ("m:users", "m:settings", "m:shop", "m:stats"):
    press_admin(data)
    fake.delete(555, fake.last[555])          # admin deletes the on-screen message
    died = press_admin("m:home")
    ok = admin_menu_now()
    check(f"AD) {data} + deleted message: home still lands on main menu", ok and not died,
          f"text={latest(555)['text'][:50]!r}")

# ============================================================================
# FLOOD (429) SCENARIO: tg_client exhausts retries -> edit returns None.
# This is what happens in production while tapping buttons fast. Every button
# must still land on its screen (via the fallback fresh message).
# ============================================================================
press_admin("m:home")
fake.edit_fail = 2
died = press_admin("m:users")
ok1 = "جستجو" in latest(555)["text"]
died2 = press_admin("m:home")
ok2 = admin_menu_now()
check("AF) flood: m:users + m:home still work when edits fail (429)",
      ok1 and ok2 and not died and not died2,
      f"ok1={ok1} ok2={ok2} died={died}/{died2} text={latest(555)['text'][:40]!r}")

press_cust("uu:home")
fake.edit_fail = 2
died = press_cust("uu:stats")
ok1 = "وضعیت اکانت" in latest(777)["text"]
died2 = press_cust("uu:home")
ok2 = cust_menu_now()
check("CF) flood: uu:stats + uu:home still work when edits fail (429)",
      ok1 and ok2 and not died and not died2,
      f"ok1={ok1} ok2={ok2} died={died}/{died2} text={latest(777)['text'][:40]!r}")

# ============================================================================
# CUSTOMER SWEEP
# ============================================================================
cust_msg("/start")
check("C0 customer menu after /start", cust_menu_now(), latest(777)["kb"][:100])

cust_sections = [
    ("uu:stats",  "وضعیت اکانت"),
    ("uu:sub",    "لینک اشتراک"),
    ("uu:cfgs",   "کانفیگ"),
    ("uu:renew",  "پلن"),
    ("uu:buy",    "خرید"),
    ("uu:gift",   "هدیه"),
    ("uu:redeem", "تخفیف"),
    ("uu:ref",    "دعوت"),
    ("uu:my_subs","اشتراک"),
]
for data, marker in cust_sections:
    died1 = press_cust(data)
    m = latest(777)
    ok1 = (marker in m["text"]) or (marker in m["kb"])
    died2 = press_cust("uu:home")
    ok2 = cust_menu_now()
    check(f"C) {data}: section opens and uu:home works", ok1 and ok2 and not died1 and not died2,
          f"open={ok1} home={ok2} died1={died1} died2={died2} text={latest(777)['text'][:50]!r}")

# customer refresh twice (identical account -> "message is not modified")
press_cust("uu:stats")
press_cust("uu:stats")
check("CR) customer refresh twice: no silent death, account screen stays",
      "وضعیت اکانت" in latest(777)["text"],
      f"toasts={fake.toasts} text={latest(777)['text'][:50]!r}")

# keyboard home mid-conversation (re-verify in this harness)
press_cust("uu:renew")
cust_msg("30")            # pick a plan if prompted, or any input
cust_msg("10")            # GB if prompted
cust_msg("🏠 منوی اصلی")  # escape via keyboard
check("C) keyboard home escapes mid renew/buy flow", cust_menu_now(),
      latest(777)["text"][:60])

# deleted-message scenario on the customer side
press_cust("uu:stats")
fake.delete(777, fake.last[777])
died = press_cust("uu:home")
check("CD) deleted stats message: uu:home still lands on menu",
      cust_menu_now() and not died, latest(777)["text"][:50])

print()
if fails:
    print("FAILED:", len(fails))
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("SWEEP OK: every section's back/home button works under real Telegram edit semantics.")
