import os, sys
"""End-to-end: real app.py polling loop against a fake Telegram API."""
import json, os, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
d = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(d, "e2e.db")
os.environ["TELEGRAM_BOT_TOKEN"] = "TESTTOKEN"
os.environ["TELEGRAM_ADMIN_IDS"] = "555"
os.environ["ADMIN_API_KEY"] = "key"
os.environ["ADMINS_CONFIG_PATH"] = os.path.join(d, "admins.json")

sent = []
served = {"getUpdates": 0}
conns = set()
UPDATES = [
  {"update_id":1,"message":{"message_id":1,"chat":{"id":555},"from":{"id":555},"text":"/start"}},
  {"update_id":2,"message":{"message_id":2,"chat":{"id":777},"from":{"id":777},"text":"/start"}},
  {"update_id":3,"callback_query":{"id":"cb1","from":{"id":555},"data":"m:home",
     "message":{"message_id":9,"chat":{"id":555}}}},
]

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}
    def _send(self, obj):
        b = json.dumps(obj).encode()
        self.send_response(200); self.send_header("Content-Type","application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        conns.add(id(self.connection))
        m = self.path.split("/")[-1].split("?")[0]
        if m == "getUpdates":
            served["getUpdates"] += 1
            if served["getUpdates"] == 1:
                self._send({"ok": True, "result": UPDATES})
            else:
                time.sleep(0.3); self._send({"ok": True, "result": []})
            return
        self._send({"ok": True, "result": {}})
    def do_POST(self):
        conns.add(id(self.connection))
        body = self._body()
        m = self.path.split("/")[-1]
        sent.append((m, body))
        self._send({"ok": True, "result": {"message_id": len(sent)}})
    def log_message(self,*a): pass

srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

import tg_client
tg_client.TG_API = "http://127.0.0.1:%d/bot{token}/{method}" % port
import app
app._init_db()
import bot_settings, user_registry, referrals, shop
for m in (bot_settings, user_registry, referrals, shop): m.init(app.DB_PATH)
app._startup()
app._tg_poll_loop()
time.sleep(3.0)
srv.shutdown()

methods = [m for m, _ in sent]
print("telegram methods called:", methods)
print("distinct TCP connections used:", len(conns))
admin_msgs = [b.get("text","")[:40] for m,b in sent if b.get("chat_id")==555]
user_msgs  = [b.get("text","")[:40] for m,b in sent if b.get("chat_id")==777]
print("-> admin 555 got:", admin_msgs)
print("-> customer 777 got:", user_msgs)
assert "deleteWebhook" in methods, methods
assert any("پنل مدیریت" in t for t in admin_msgs), admin_msgs
assert any("خوش آمدید" in t or "ثبت لینک" in t for t in user_msgs), user_msgs
assert "answerCallbackQuery" in methods
assert len(conns) <= 4, len(conns)
print("\nE2E OK: admin routed to admin panel, non-admin routed to the shop side,")
print("        callback answered, and the whole session reused a handful of sockets.")
