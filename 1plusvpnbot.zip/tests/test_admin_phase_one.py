"""Offline tests: per-admin backup, onboarding, and shared config."""
import io
import json
from pathlib import Path
import stat
import sys
import tempfile
import threading
import unittest
from contextlib import ExitStack
from unittest.mock import Mock, patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import admin_config
import app
import backup_schedule
import bot
import bot_settings
import dbx
import panel
import panel_api
import shop
import user_registry
from fastapi import HTTPException

TOKEN = '12345:' + 'a' * 35
KEY = 'rk_local-fixture'


class PhaseOne(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.db = str(self.root / 'data.db')
        self.admins = str(self.root / 'admins.json')
        self.stack.callback(dbx.close_thread)
        for module in (app, bot_settings, shop, user_registry):
            self.stack.enter_context(patch.object(module, 'DB_PATH' if module is app else '_DB_PATH', self.db))
        self.stack.enter_context(patch.object(app, 'ADMINS_CONFIG_PATH', self.admins))
        self.stack.enter_context(patch.object(panel, 'ADMINS_PATH', self.admins))
        app._invalidate_admins_cache()
        bot_settings.invalidate_settings_cache()
        self.stack.callback(app._invalidate_admins_cache)
        self.stack.callback(bot_settings.invalidate_settings_cache)
        app._init_db()
        for module in (shop, user_registry, bot_settings, backup_schedule):
            module.init(self.db)

    def archive(self, admin):
        content = shop.create_admin_backup(admin)
        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            return content, json.loads(zf.read('backup.json')), zf.read('signature.txt')

    @staticmethod
    def pack(data, signature=None):
        output = io.BytesIO()
        with zipfile.ZipFile(output, 'w') as zf:
            zf.writestr('backup.json', json.dumps(data))
            if signature:
                zf.writestr('signature.txt', signature)
        return output.getvalue()

    def seed(self):
        c = dbx.get(self.db)
        for i, admin in enumerate(('one', 'two'), 1):
            bot_settings.set_setting(admin, 'shop_prefix', admin.upper())
            c.execute('INSERT INTO bot_users(chat_id,username,admin_username,sub) VALUES (?,?,?,?)',
                      (str(i), 'same_name', admin, f'sub-{i}'))
            c.execute('INSERT INTO shop_users(id,admin_username,username,password_hash) VALUES (?,?,?,?)',
                      (i, admin, 'store_user', f'hash-{i}'))
            c.execute('INSERT INTO shop_vpn(shop_user_id,vpn_username,sub) VALUES (?,?,?)',
                      (i, 'same_name', f'sub-{i}'))
            c.execute('''INSERT INTO shop_orders(id,shop_user_id,admin_username,type,plan_days,gb,price,status)
                        VALUES (?,?,?,'buy',30,1,100,'approved')''', (i, i, admin))
            c.execute('''INSERT INTO renewal_orders(id,username,admin_username,sub,plan_days,gb,price,status,created_at)
                        VALUES (?,'same_name',?,'sub',30,1,100,'approved',1)''', (i, admin))
        return c

    def test_round_trip_restores_orders_and_users_without_touching_second_admin(self):
        c = self.seed()
        raw, rows, _ = self.archive('one')
        self.assertEqual([rows[t][0]['admin_username'] for t in ('shop_users','bot_users','renewal_orders','shop_orders')], ['one'] * 4)
        self.assertEqual([r['id'] for r in rows['renewal_orders']], [1])
        self.assertNotIn('admin_backup_signing', rows)
        second_raw = self.archive('two')[1]
        for table in ('admin_settings', 'bot_users', 'shop_orders', 'renewal_orders', 'shop_users'):
            c.execute(f"DELETE FROM {table} WHERE admin_username='one'")
        c.execute('DELETE FROM shop_vpn WHERE shop_user_id=1')
        result = shop.restore_admin_backup('one', raw)
        self.assertTrue(result['ok'], result)
        one_now = self.archive('one')[1]
        second_now = self.archive('two')[1]
        for table in shop._BACKUP_TABLES:
            self.assertEqual(rows[table], one_now[table])
            self.assertEqual(second_raw[table], second_now[table])

    def test_tampered_or_wrong_owner_archive_is_rejected(self):
        self.seed()
        raw, rows, signature = self.archive('one')
        self.assertEqual(shop.restore_admin_backup('two', raw)['error'], 'backup_belongs_to_different_admin')
        rows['renewal_orders'][0]['username'] = 'tampered'
        self.assertEqual(shop.restore_admin_backup('one', self.pack(rows, signature))['error'], 'backup_signature_invalid')

    def test_conflicting_id_rolls_back_all_sections(self):
        c = self.seed()
        raw, _, _ = self.archive('one')
        c.execute("UPDATE bot_users SET admin_username='two' WHERE chat_id='1'")
        c.execute("UPDATE admin_settings SET value='do not wipe' WHERE admin_username='one'")
        self.assertEqual(shop.restore_admin_backup('one', raw)['error'], 'backup_scope_conflict')
        self.assertEqual(c.execute("SELECT value FROM admin_settings WHERE admin_username='one'").fetchone()[0], 'do not wipe')
        self.assertEqual(c.execute("SELECT admin_username FROM bot_users WHERE chat_id='1'").fetchone()[0], 'two')

    def test_legacy_restores_settings_but_never_replaces_orders(self):
        c = self.seed()
        data = {'metadata': {'version':'1.0','type':'admin_backup','admin_username':'one'},
                'admin_settings': [{'key':'shop_prefix','value':'legacy'}], 'shop_orders': []}
        result = shop.restore_admin_backup('one', self.pack(data))
        self.assertTrue(result['legacy'])
        self.assertEqual(c.execute("SELECT value FROM admin_settings WHERE admin_username='one'").fetchone()[0], 'legacy')
        self.assertEqual(c.execute('SELECT COUNT(*) FROM shop_orders').fetchone()[0], 2)

    def test_pending_from_archive_is_not_reopened(self):
        c = self.seed()
        c.execute("UPDATE shop_orders SET status='pending' WHERE id=1")
        c.execute("UPDATE renewal_orders SET status='pending' WHERE id=1")
        raw, _, _ = self.archive('one')
        c.execute("UPDATE shop_orders SET status='approved' WHERE id=1")
        c.execute('DELETE FROM renewal_orders WHERE id=1')
        self.assertTrue(shop.restore_admin_backup('one', raw)['ok'])
        self.assertEqual(c.execute('SELECT status FROM shop_orders WHERE id=1').fetchone()[0], 'approved')
        self.assertEqual(c.execute('SELECT status FROM renewal_orders WHERE id=1').fetchone()[0], 'rejected')

    def test_schedule_is_persistent_and_retries_only_failed_recipient(self):
        jobs = {'one': (10800, 'token1', ['42','43']), 'two': (7200, 'token2', ['44'])}
        create = Mock(side_effect=lambda admin: admin.encode())
        failures = {'43'}
        sent = []
        def send(token, cid, admin, content):
            sent.append((token, cid, admin, content))
            return cid not in failures
        backup_schedule.tick(self.db, jobs, create, send, now=100)
        self.assertFalse(sent)
        dbx.close_thread()  # restart-surviving schedule is stored in SQLite
        backup_schedule.tick(self.db, jobs, create, send, now=10900)
        self.assertCountEqual(sent, [('token1','42','one',b'one'), ('token1','43','one',b'one'), ('token2','44','two',b'two')])
        self.assertEqual(create.call_count, 2)
        sent.clear()
        failures.clear()
        backup_schedule.tick(self.db, jobs, create, send, now=11200)
        self.assertEqual(sent, [('token1','43','one',b'one')])
        backup_schedule.reset(self.db, 'one')
        backup_schedule.tick(self.db, {'one': (3600, 'token1', ['42'])}, create, send, now=11300)
        self.assertEqual([tuple(row) for row in dbx.get(self.db).execute('SELECT * FROM admin_backup_schedule')],
                         [('one','42',3600,14900)])

    def test_jobs_dont_depend_on_sudo_interval_or_inherit_recipients(self):
        Path(self.admins).write_text(json.dumps({'_comment':'info', 'one': {'bot_token':'own','admin_ids':['42','-1']},
                                                'two': {'bot_token':'two-token'}}))
        for name in ('','one','two'):
            bot_settings.set_setting(name,'backup_auto_enabled','1')
            bot_settings.set_setting(name,'backup_interval_hours',3)
        with patch.object(app,'BACKUP_INTERVAL_HOURS',0), patch.object(app,'TELEGRAM_ADMIN_IDS',['11']), \
                patch.object(app,'TELEGRAM_BOT_TOKEN','primary'):
            self.assertEqual(app._admin_backup_jobs(), {'': (10800,'primary',['11']), 'one': (10800,'own',['42'])})

    def test_web_panel_stale_edit_cannot_erase_bot_admin(self):
        with patch.object(panel, '_require'):
            before = panel.get_admins(None)
            admin_config.add(self.admins, 'one', {'api_key': KEY,'bot_token': TOKEN,'admin_ids':['42']})
            with self.assertRaises(HTTPException) as ctx:
                panel.set_admins(panel.AdminsBody(admins={}, revision=before['revision']), None)
            self.assertEqual(ctx.exception.status_code, 409)
            current = panel.get_admins(None)
            self.assertIn('one', current['admins'])
            self.assertEqual(stat.S_IMODE(Path(self.admins).stat().st_mode), 0o600)
            current['admins']['one']['admin_ids'] = ['11']
            updated = panel.set_admins(panel.AdminsBody(**current), None)
            self.assertEqual(updated['revision'], panel.get_admins(None)['revision'])

    def test_register_checks_key_owner_privilege_and_bot_before_saving(self):
        identity = {'username':'one', 'role':'reseller'}
        def telegram(method, _):
            return {'ok':True,'result':{'is_bot':True} if method == 'getMe' else {'url':''}}
        with patch.object(panel_api.PanelAPI, 'current_admin', side_effect=lambda: identity), \
             patch.object(app.tg_client,'call',side_effect=telegram), patch.object(app,'TELEGRAM_BOT_TOKEN','primary'):
            self.assertTrue(app._register_telegram_admin('wrong',KEY,TOKEN,['42']))
            identity['role'] = 'full_access'
            self.assertTrue(app._register_telegram_admin('one',KEY,TOKEN,['42']))
            self.assertFalse(Path(self.admins).exists())
            identity['role'] = 'reseller'
            self.assertEqual(app._register_telegram_admin('one',KEY,TOKEN,['42']), '')
            self.assertTrue(app._register_telegram_admin('one',KEY,TOKEN,['42']))
            self.assertEqual(app._admin_username_for_token(TOKEN), 'one')

    def test_onboarding_is_private_primary_only_and_does_not_echo_secrets(self):
        with patch.object(bot, 'CONV', bot.Conv()), patch.object(bot,'_ctx',return_value=('',{},None)), \
             patch.object(bot,'_can_add_admin',side_effect=lambda token, cid: token == 'primary' and cid == '42'), \
             patch.object(bot,'tg',return_value={'ok':True}) as tg, patch.object(bot,'_add_admin',return_value='') as add, \
             patch.object(bot,'_admin_username_for_token',return_value=''), \
             patch.object(app,'_BOT_MODULE',bot), patch.object(app,'_handle_reject_reason_text',return_value=True) as reject:
            def cb(chat, token):
                bot.handle_callback({'callback_query':{'id':'c','data':'onboard:add','from':{'id':42},
                                                        'message':{'chat':{'id':chat},'message_id':1}}},token)
            def messages(chat, token):
                for txt in ('one','42',KEY,TOKEN):
                    app._dispatch_update({'message':{'chat':{'id':chat},'from':{'id':42},'message_id':9,'text':txt}},token)
            cb(-12,'primary'); messages(-12,'primary')
            cb(42,'not-primary'); messages(42,'not-primary')
            add.assert_not_called()
            reject.reset_mock()
            cb(42,'primary'); messages(42,'primary')
            reject.assert_not_called()
            add.assert_called_once_with('one',KEY,TOKEN,['42'])
            self.assertEqual([c.args[0] for c in tg.call_args_list].count('deleteMessage'),2)
            self.assertNotIn(KEY,repr(tg.call_args_list))
            self.assertNotIn(TOKEN,repr(tg.call_args_list))

    def test_reconcile_starts_new_bot_without_starting_old_one_again(self):
        desired = ['primary']
        started = []
        release = threading.Event()
        def worker(token, stop):
            started.append((token, stop))
            release.wait(2)
        with patch.object(app,'_pollers', {}), patch.object(app,'_all_bot_tokens',side_effect=lambda: desired), \
             patch.object(app,'_run_tg_poller',side_effect=worker):
            try:
                app._tg_poll_loop()
                desired.append(TOKEN)
                app._tg_poll_loop()
                app._tg_poll_loop()
                self.assertCountEqual([token for token, _ in started], ['primary',TOKEN])
                desired.remove(TOKEN)
                app._tg_poll_loop()
                self.assertTrue(app._pollers[TOKEN][1].is_set())
                self.assertFalse(app._pollers['primary'][1].is_set())
            finally:
                release.set()
                for thread, _ in app._pollers.values():
                    thread.join(2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
