"""
tg_client.py — a single, shared, pooled HTTP client for the Telegram Bot API.
============================================================================

WHY THIS FILE EXISTS (this was the #1 cause of the bot feeling "heavy/slow")
---------------------------------------------------------------------------
The old code did this for EVERY single Telegram call (sendMessage, editMessage,
answerCallbackQuery, sendChatAction, getChatMember, getUpdates, ...):

    with httpx.Client(timeout=30.0) as c:
        r = c.post(url, json=kw)

Creating an httpx.Client per call means a brand new TCP connection + a brand
new TLS handshake to api.telegram.org on every call, and then throwing it away.
From a server in Iran that is roughly 3 round trips (~0.4s – 1.5s) of pure
overhead per call. A single button press costs 2–3 calls
(answerCallbackQuery + editMessageText [+ sendChatAction]), so the user waited
1.5–4 seconds for every tap even when the business logic took 5 ms.

Now: one persistent client per bot token, with keep-alive connections, HTTP/2
disabled (Telegram is HTTP/1.1 friendly and h2 adds latency here), sane
per-operation timeouts, automatic retry on transient network errors, and
correct handling of Telegram's 429 (retry_after) flood control.

Everything (bot.py, bot_user.py, app.py, notifier.py) routes through here, so
the whole process shares one warm connection pool per token.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any, Optional

import httpx

log = logging.getLogger("tg")

TG_API = "https://api.telegram.org/bot{token}/{method}"
TG_FILE = "https://api.telegram.org/file/bot{token}/{path}"

# Optional outbound proxy for servers that cannot reach Telegram directly.
TG_PROXY = os.environ.get("TELEGRAM_PROXY", "").strip() or None

# Timeouts: connect must be short (fail fast + retry), read must cover
# long-polling. Separate clients are used for polling vs. normal calls so a
# 50 second getUpdates never occupies a connection needed to answer a button.
_CALL_TIMEOUT = httpx.Timeout(connect=8.0, read=25.0, write=25.0, pool=10.0)
_POLL_TIMEOUT = httpx.Timeout(connect=8.0, read=75.0, write=25.0, pool=10.0)

_LIMITS = httpx.Limits(
    max_keepalive_connections=int(os.environ.get("TG_POOL_KEEPALIVE", "20")),
    max_connections=int(os.environ.get("TG_POOL_MAX", "60")),
    keepalive_expiry=90.0,
)

_lock = threading.Lock()
_clients: dict[tuple[str, bool], httpx.Client] = {}

# Telegram flood-control state: per chat_id, the epoch until which we must wait.
_flood_until: dict[str, float] = {}
_flood_lock = threading.Lock()


def _client(token: str, polling: bool = False) -> httpx.Client:
    """Return the shared, keep-alive client for this token."""
    key = (token or "", polling)
    client = _clients.get(key)
    if client is not None:
        return client
    with _lock:
        client = _clients.get(key)
        if client is None:
            client = httpx.Client(
                timeout=_POLL_TIMEOUT if polling else _CALL_TIMEOUT,
                limits=_LIMITS,
                proxy=TG_PROXY,
                http2=False,
                headers={"Connection": "keep-alive"},
            )
            _clients[key] = client
        return client


def close_all() -> None:
    """Close every pooled client (used on shutdown)."""
    with _lock:
        for c in _clients.values():
            try:
                c.close()
            except Exception:
                pass
        _clients.clear()


def _sleep_for_flood(chat_id: Any) -> None:
    if chat_id is None:
        return
    key = str(chat_id)
    with _flood_lock:
        until = _flood_until.get(key, 0.0)
    delay = until - time.time()
    if delay > 0:
        time.sleep(min(delay, 30.0))


def _mark_flood(chat_id: Any, retry_after: float) -> None:
    if chat_id is None:
        return
    key = str(chat_id)
    with _flood_lock:
        _flood_until[key] = time.time() + retry_after


def call(method: str, token: str, *, _files=None, _retries: int = 2,
         **params) -> Optional[dict]:
    """
    Call a Telegram Bot API method over the shared pooled connection.

    Returns the decoded JSON dict, or None when the call could not be made.
    Handles: transient network errors (retried), HTTP 429 flood control
    (honours retry_after and retries once), and 5xx (retried).
    """
    token = (token or "").strip()
    if not token:
        return None

    # Drop None values — Telegram rejects nulls for several optional fields
    # (the old code sent reply_markup=None and silently lost keyboards).
    payload = {k: v for k, v in params.items() if v is not None}
    chat_id = payload.get("chat_id")
    url = TG_API.format(token=token, method=method)
    client = _client(token)

    attempt = 0
    while True:
        _sleep_for_flood(chat_id)
        try:
            if _files:
                r = client.post(url, data=payload, files=_files)
            else:
                r = client.post(url, json=payload)
        except httpx.HTTPError as exc:
            attempt += 1
            if attempt > _retries:
                log.warning("tg_call_failed method=%s error=%s", method, type(exc).__name__)
                return None
            time.sleep(0.25 * attempt)
            continue

        if r.status_code == 429:
            try:
                retry_after = float(r.json().get("parameters", {}).get("retry_after", 1))
            except Exception:
                retry_after = 1.0
            _mark_flood(chat_id, retry_after)
            attempt += 1
            if attempt > _retries:
                return None
            time.sleep(min(retry_after, 30.0))
            continue

        if r.status_code >= 500:
            attempt += 1
            if attempt > _retries:
                return None
            time.sleep(0.4 * attempt)
            continue

        try:
            return r.json()
        except Exception:
            return None


def get_updates(token: str, offset: Optional[int], timeout: int = 50,
                allowed_updates=("message", "callback_query", "my_chat_member")):
    """
    One long-poll cycle on the dedicated polling client.

    `allowed_updates` is important: without it Telegram also streams
    edited_message / channel_post / poll / chat_member updates that this bot
    throws away — wasted bandwidth and wasted dispatcher work on every cycle.
    """
    token = (token or "").strip()
    if not token:
        return None
    params: dict[str, Any] = {"timeout": timeout}
    if offset is not None:
        params["offset"] = offset
    if allowed_updates:
        import json as _json
        params["allowed_updates"] = _json.dumps(list(allowed_updates))
    url = TG_API.format(token=token, method="getUpdates")
    try:
        r = _client(token, polling=True).get(url, params=params)
    except httpx.HTTPError:
        return None
    try:
        return r.json()
    except Exception:
        return None


def download_file(token: str, file_id: str) -> Optional[bytes]:
    """getFile + fetch, over the shared pool."""
    info = call("getFile", token, file_id=file_id)
    if not info or not info.get("ok"):
        return None
    path = (info.get("result") or {}).get("file_path")
    if not path:
        return None
    try:
        r = _client(token).get(TG_FILE.format(token=token, path=path), timeout=60.0)
        if r.status_code != 200:
            return None
        return r.content
    except httpx.HTTPError:
        return None
